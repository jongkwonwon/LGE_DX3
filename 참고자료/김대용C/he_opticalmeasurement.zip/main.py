
########################################################################
## IMPORTS
########################################################################
import sys
import numpy as np
from PIL import ImageGrab
from PySide2.QtCore import *
from functools import partial
########################################################################
# IMPORT GUI FILE
from ui_interface import *
# from modules.pattern import *
# from modules.color_name import *
########################################################################

########################################################################
# IMPORT SERIALTOOLS
import serial.tools.list_ports
import time
from datetime import datetime
import serial
ser = serial.Serial()
########################################################################

########################################################################
# IMPORT Function FILE
#######################################################################

########################################################################
# IMPORT Custom widgets
from Custom_Widgets.Widgets import *
# INITIALIZE APP SETTINGS
settings = QSettings()

########################################################################
#test

########################################################################
## MAIN WINDOW CLASS
########################################################################
class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        # self.dui = Ui_Dialog()
        # APPLY JSON STYLESHEET
        ########################################################################
        loadJsonStyle(self, self.ui, jsonFiles={
            "json/style_main.json"
        })
        ########################################################################

        # SHOW WINDOW
        #######################################################################
        self.ui.mainPages.setCurrentIndex(0)
        self.show()
        ########################################################################
        # UPDATE APP SETTINGS LOADED FROM JSON STYLESHEET
        # ITS IMPORTANT TO RUN THIS AFTER SHOWING THE WINDOW
        # THIS PROCESS WILL RUN ON A SEPARATE THREAD WHEN GENERATING NEW ICONS
        # TO PREVENT THE WINDOW FROM BEING UNRESPONSIVE
        ########################################################################
        #QAppSettings.updateAppSettings(self) #set Commented on 23/11/06 by shook.lee because don't know the function....

        # # CHANGE THE THEME NAME IN SETTINGS
        # # Use one of the app themes from your JSON file
        # settings = QSettings()
        # settings.setValue("THEME", "Default-Dark")

        # # RE APPLY THE NEW SETINGS
        # # CompileStyleSheet might also work
        # # CompileStyleSheet.applyCompiledSass(self)
        # QAppSettings.updateAppSettings(self)

        ########################################################################
        # MAIN FUNCTION SETTING - CONNECT LEVEL1 BUTTON and SUBPAGE
        ########################################################################
        self.ui.btn_home.clicked.connect(partial(self.ui.mainPages.setCurrentIndex,0))
        self.ui.btn_measure.clicked.connect(partial(self.ui.mainPages.setCurrentIndex,1))
        self.ui.btn_control.clicked.connect(partial(self.ui.mainPages.setCurrentIndex,2))
        self.ui.btn_serial.clicked.connect(partial(self.ui.mainPages.setCurrentIndex,3))
        self.ui.btn_help.clicked.connect(partial(self.ui.mainPages.setCurrentIndex,4))
        self.ui.btn_setup.clicked.connect(partial(self.ui.mainPages.setCurrentIndex,5))


## EXECUTE APP
########################################################################
if __name__ == "__main__":
    app = QApplication(sys.argv)
    ########################################################################
    ## 
    ########################################################################
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
########################################################################
## END===>
########################################################################  
