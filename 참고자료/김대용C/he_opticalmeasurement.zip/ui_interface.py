# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'interface.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from Custom_Widgets.Widgets import QCustomSlideMenu
from Custom_Widgets.Widgets import QCustomStackedWidget
from subpages.subpage_TVcontrol import Widget_TVcontrol
from subpages.subpage_measure import Widget_measure
from subpages.subpage_serial import Widget_serial
from subpages.subpage_help import Widget_help
from subpages.subpage_setup import Widget_setup
from subpages.subpage_home import Widget_home

import QSS_Resources_rc
import picture_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1920, 1034)
        MainWindow.setMinimumSize(QSize(0, 0))
        MainWindow.setMaximumSize(QSize(1920, 1080))
        MainWindow.setStyleSheet(u"*{\n"
"    border: none;\n"
"	background-color: transparent;\n"
"	background: transparent;\n"
"	padding: 0;\n"
"	margin: 0;\n"
"	color: #fff;\n"
"}\n"
"#centralwidget,  #mainBodyContent{\n"
"	background-color: #1b1b27;\n"
"}\n"
"\n"
"QLineEdit, QTextEdit{\n"
"    background-color: white;\n"
"	color : black;\n"
"    border : 1px solid rgb(192, 192, 192);\n"
"}\n"
"\n"
"QLineEdit:hover{\n"
"    color : black;\n"
"}\n"
"\n"
"\n"
"#header, #mainBody, #footer {\n"
"    background-color: #27263c;\n"
"}\n"
"\n"
"#topMenu QPushButton{\n"
"	background-color: transparent;\n"
"}\n"
"\n"
"#topMenu QPushButton:hover{\n"
"	background-color: #1b1b27\n"
"}\n"
"\n"
"#pushButton{\n"
"    border : 1px solid #cc5bce;\n"
"    border-radius: 13px;\n"
"    text-align:center;\n"
"}\n"
"\n"
"#leftMenu QPushButton{\n"
"	text-align:left;\n"
"	padding: 10px 20px;\n"
"    border-top-left-radius : 10px;\n"
"    border-bottom-left-radius : 10px;\n"
"    border-top-right-radius : 0;\n"
"    border-bottom-right-radius : 0;\n"
"    background-"
                        "color: transparent;\n"
"}\n"
"\n"
"#leftMenu QPushButton:hover{\n"
"   background-color: #cc5bce;\n"
"}\n"
"\n"
"")
        MainWindow.setToolButtonStyle(Qt.ToolButtonIconOnly)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setSpacing(10)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.header = QWidget(self.centralwidget)
        self.header.setObjectName(u"header")
        self.horizontalLayout_4 = QHBoxLayout(self.header)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.frame_2 = QFrame(self.header)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.horizontalLayout = QHBoxLayout(self.frame_2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.menuBtn = QPushButton(self.frame_2)
        self.menuBtn.setObjectName(u"menuBtn")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.menuBtn.sizePolicy().hasHeightForWidth())
        self.menuBtn.setSizePolicy(sizePolicy)
        self.menuBtn.setMinimumSize(QSize(54, 50))
        self.menuBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon = QIcon()
        icon.addFile(u":/icons/Icons/align-justify.png", QSize(), QIcon.Normal, QIcon.Off)
        self.menuBtn.setIcon(icon)
        self.menuBtn.setIconSize(QSize(30, 30))

        self.horizontalLayout.addWidget(self.menuBtn)

        self.label_5 = QLabel(self.frame_2)
        self.label_5.setObjectName(u"label_5")
        sizePolicy.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy)
        self.label_5.setMinimumSize(QSize(50, 50))
        self.label_5.setMaximumSize(QSize(50, 50))
        self.label_5.setFrameShape(QFrame.NoFrame)
        self.label_5.setPixmap(QPixmap(u":/etc/rgb.png"))
        self.label_5.setScaledContents(True)
        self.label_5.setWordWrap(False)

        self.horizontalLayout.addWidget(self.label_5)

        self.btn_home = QPushButton(self.frame_2)
        self.btn_home.setObjectName(u"btn_home")
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.btn_home.setFont(font)

        self.horizontalLayout.addWidget(self.btn_home)


        self.horizontalLayout_4.addWidget(self.frame_2, 0, Qt.AlignLeft|Qt.AlignVCenter)

        self.topMenu = QFrame(self.header)
        self.topMenu.setObjectName(u"topMenu")
        self.topMenu.setFrameShape(QFrame.StyledPanel)
        self.topMenu.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.topMenu)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.pushButton_4 = QPushButton(self.topMenu)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setCursor(QCursor(Qt.PointingHandCursor))
        icon1 = QIcon()
        icon1.addFile(u":/icons/Icons/search.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_4.setIcon(icon1)
        self.pushButton_4.setIconSize(QSize(25, 25))

        self.horizontalLayout_3.addWidget(self.pushButton_4)

        self.pushButton_2 = QPushButton(self.topMenu)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setCursor(QCursor(Qt.PointingHandCursor))
        icon2 = QIcon()
        icon2.addFile(u":/icons/Icons/activity.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_2.setIcon(icon2)
        self.pushButton_2.setIconSize(QSize(25, 25))

        self.horizontalLayout_3.addWidget(self.pushButton_2)

        self.pushButton_3 = QPushButton(self.topMenu)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setCursor(QCursor(Qt.PointingHandCursor))
        icon3 = QIcon()
        icon3.addFile(u":/icons/Icons/bell.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_3.setIcon(icon3)
        self.pushButton_3.setIconSize(QSize(25, 25))

        self.horizontalLayout_3.addWidget(self.pushButton_3)

        self.pushButton = QPushButton(self.topMenu)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setMinimumSize(QSize(31, 31))
        self.pushButton.setMaximumSize(QSize(31, 31))
        self.pushButton.setCursor(QCursor(Qt.PointingHandCursor))
        icon4 = QIcon()
        icon4.addFile(u":/icons/Icons/user.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton.setIcon(icon4)
        self.pushButton.setIconSize(QSize(25, 25))

        self.horizontalLayout_3.addWidget(self.pushButton)


        self.horizontalLayout_4.addWidget(self.topMenu, 0, Qt.AlignRight|Qt.AlignVCenter)

        self.topMenu.raise_()
        self.frame_2.raise_()

        self.verticalLayout.addWidget(self.header)

        self.mainBody = QWidget(self.centralwidget)
        self.mainBody.setObjectName(u"mainBody")
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.mainBody.sizePolicy().hasHeightForWidth())
        self.mainBody.setSizePolicy(sizePolicy1)
        self.mainBody.setMinimumSize(QSize(1327, 785))
        self.horizontalLayout_2 = QHBoxLayout(self.mainBody)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, -1, 0, 0)
        self.leftMenu = QCustomSlideMenu(self.mainBody)
        self.leftMenu.setObjectName(u"leftMenu")
        self.leftMenu.setMinimumSize(QSize(200, 0))
        self.leftMenu.setMaximumSize(QSize(0, 16777215))
        self.verticalLayout_3 = QVBoxLayout(self.leftMenu)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 20)
        self.widget = QWidget(self.leftMenu)
        self.widget.setObjectName(u"widget")
        self.widget.setMinimumSize(QSize(200, 756))
        self.verticalLayout_4 = QVBoxLayout(self.widget)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(10, 0, 0, 0)
        self.frame_3 = QFrame(self.widget)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.frame_3)
        self.verticalLayout_5.setSpacing(10)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.btn_measure = QPushButton(self.frame_3)
        self.btn_measure.setObjectName(u"btn_measure")
        font1 = QFont()
        font1.setFamily(u"Segoe UI")
        font1.setPointSize(13)
        font1.setBold(True)
        font1.setWeight(75)
        self.btn_measure.setFont(font1)
        self.btn_measure.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_measure.setStyleSheet(u"")
        icon5 = QIcon()
        icon5.addFile(u":/icons/Icons/star.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_measure.setIcon(icon5)
        self.btn_measure.setIconSize(QSize(24, 24))
        self.btn_measure.setAutoDefault(False)

        self.verticalLayout_5.addWidget(self.btn_measure)

        self.btn_control = QPushButton(self.frame_3)
        self.btn_control.setObjectName(u"btn_control")
        font2 = QFont()
        font2.setFamily(u"Segoe UI")
        font2.setPointSize(13)
        font2.setBold(True)
        font2.setItalic(False)
        font2.setWeight(75)
        self.btn_control.setFont(font2)
        self.btn_control.setCursor(QCursor(Qt.PointingHandCursor))
        icon6 = QIcon()
        icon6.addFile(u":/icons/Icons/monitor.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_control.setIcon(icon6)
        self.btn_control.setIconSize(QSize(24, 24))

        self.verticalLayout_5.addWidget(self.btn_control)

        self.btn_serial = QPushButton(self.frame_3)
        self.btn_serial.setObjectName(u"btn_serial")
        self.btn_serial.setFont(font2)
        self.btn_serial.setCursor(QCursor(Qt.PointingHandCursor))
        icon7 = QIcon()
        icon7.addFile(u":/icons/Icons/link.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_serial.setIcon(icon7)
        self.btn_serial.setIconSize(QSize(24, 24))

        self.verticalLayout_5.addWidget(self.btn_serial)


        self.verticalLayout_4.addWidget(self.frame_3)

        self.verticalSpacer = QSpacerItem(20, 400, QSizePolicy.Minimum, QSizePolicy.Fixed)

        self.verticalLayout_4.addItem(self.verticalSpacer)

        self.frame_4 = QFrame(self.widget)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.frame_4)
        self.verticalLayout_6.setSpacing(10)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.btn_setup = QPushButton(self.frame_4)
        self.btn_setup.setObjectName(u"btn_setup")
        self.btn_setup.setFont(font2)
        self.btn_setup.setCursor(QCursor(Qt.PointingHandCursor))
        icon8 = QIcon()
        icon8.addFile(u":/icons/Icons/settings.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_setup.setIcon(icon8)
        self.btn_setup.setIconSize(QSize(24, 24))

        self.verticalLayout_6.addWidget(self.btn_setup)

        self.btn_help = QPushButton(self.frame_4)
        self.btn_help.setObjectName(u"btn_help")
        self.btn_help.setFont(font2)
        self.btn_help.setCursor(QCursor(Qt.PointingHandCursor))
        icon9 = QIcon()
        icon9.addFile(u":/icons/Icons/help-circle.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_help.setIcon(icon9)
        self.btn_help.setIconSize(QSize(24, 24))

        self.verticalLayout_6.addWidget(self.btn_help)

        self.btn_exit = QPushButton(self.frame_4)
        self.btn_exit.setObjectName(u"btn_exit")
        self.btn_exit.setFont(font2)
        self.btn_exit.setCursor(QCursor(Qt.PointingHandCursor))
        icon10 = QIcon()
        icon10.addFile(u":/icons/Icons/log-out.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btn_exit.setIcon(icon10)
        self.btn_exit.setIconSize(QSize(24, 24))

        self.verticalLayout_6.addWidget(self.btn_exit)


        self.verticalLayout_4.addWidget(self.frame_4)


        self.verticalLayout_3.addWidget(self.widget)


        self.horizontalLayout_2.addWidget(self.leftMenu)

        self.mainBodyContent = QWidget(self.mainBody)
        self.mainBodyContent.setObjectName(u"mainBodyContent")
        self.verticalLayout_2 = QVBoxLayout(self.mainBodyContent)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.mainPages = QCustomStackedWidget(self.mainBodyContent)
        self.mainPages.setObjectName(u"mainPages")
        self.homePage = Widget_home()
        self.homePage.setObjectName(u"homePage")
        self.mainPages.addWidget(self.homePage)
        self.measurePage = Widget_measure()
        self.measurePage.setObjectName(u"measurePage")
        self.gridLayout_4 = QGridLayout(self.measurePage)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.mainPages.addWidget(self.measurePage)
        self.controlPage = Widget_TVcontrol()
        self.controlPage.setObjectName(u"controlPage")
        self.mainPages.addWidget(self.controlPage)
        self.serialPage = Widget_serial()
        self.serialPage.setObjectName(u"serialPage")
        self.mainPages.addWidget(self.serialPage)
        self.helpPage = Widget_help()
        self.helpPage.setObjectName(u"helpPage")
        self.mainPages.addWidget(self.helpPage)
        self.setupPage = Widget_setup()
        self.setupPage.setObjectName(u"setupPage")
        self.mainPages.addWidget(self.setupPage)

        self.verticalLayout_2.addWidget(self.mainPages)


        self.horizontalLayout_2.addWidget(self.mainBodyContent)

        self.rightMenu = QCustomSlideMenu(self.mainBody)
        self.rightMenu.setObjectName(u"rightMenu")
        self.rightMenu.setEnabled(True)
        sizePolicy.setHeightForWidth(self.rightMenu.sizePolicy().hasHeightForWidth())
        self.rightMenu.setSizePolicy(sizePolicy)
        self.rightMenu.setMinimumSize(QSize(0, 300))
        self.verticalLayout_10 = QVBoxLayout(self.rightMenu)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.widget_2 = QWidget(self.rightMenu)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setMinimumSize(QSize(0, 0))
        self.label_2 = QLabel(self.widget_2)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(60, 0, 70, 70))
        self.label_2.setMinimumSize(QSize(70, 70))
        self.label_2.setMaximumSize(QSize(70, 70))
        font3 = QFont()
        font3.setKerning(True)
        self.label_2.setFont(font3)
        self.label_2.setPixmap(QPixmap(u":/icons/Icons/edit.png"))
        self.label_2.setScaledContents(True)
        self.layoutWidget = QWidget(self.widget_2)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(26, 90, 131, 116))
        self.verticalLayout_7 = QVBoxLayout(self.layoutWidget)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.lineEdit = QLineEdit(self.layoutWidget)
        self.lineEdit.setObjectName(u"lineEdit")
        sizePolicy2 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.lineEdit.sizePolicy().hasHeightForWidth())
        self.lineEdit.setSizePolicy(sizePolicy2)
        self.lineEdit.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.lineEdit)

        self.lineEdit_2 = QLineEdit(self.layoutWidget)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        sizePolicy2.setHeightForWidth(self.lineEdit_2.sizePolicy().hasHeightForWidth())
        self.lineEdit_2.setSizePolicy(sizePolicy2)
        self.lineEdit_2.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.lineEdit_2)

        self.lineEdit_6 = QLineEdit(self.layoutWidget)
        self.lineEdit_6.setObjectName(u"lineEdit_6")
        sizePolicy2.setHeightForWidth(self.lineEdit_6.sizePolicy().hasHeightForWidth())
        self.lineEdit_6.setSizePolicy(sizePolicy2)
        self.lineEdit_6.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.lineEdit_6)

        self.addBtn = QPushButton(self.widget_2)
        self.addBtn.setObjectName(u"addBtn")
        self.addBtn.setGeometry(QRect(40, 210, 101, 31))
        sizePolicy.setHeightForWidth(self.addBtn.sizePolicy().hasHeightForWidth())
        self.addBtn.setSizePolicy(sizePolicy)
        self.addBtn.setMinimumSize(QSize(0, 30))
        font4 = QFont()
        font4.setFamily(u"Segoe UI")
        font4.setPointSize(12)
        font4.setBold(True)
        font4.setItalic(False)
        font4.setUnderline(False)
        font4.setWeight(75)
        self.addBtn.setFont(font4)
        self.addBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon11 = QIcon()
        icon11.addFile(u":/icons/Icons/log-in.png", QSize(), QIcon.Normal, QIcon.Off)
        self.addBtn.setIcon(icon11)
        self.addBtn.setIconSize(QSize(20, 20))

        self.verticalLayout_10.addWidget(self.widget_2)


        self.horizontalLayout_2.addWidget(self.rightMenu)


        self.verticalLayout.addWidget(self.mainBody)

        self.footer = QWidget(self.centralwidget)
        self.footer.setObjectName(u"footer")
        self.horizontalLayout_5 = QHBoxLayout(self.footer)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label_9 = QLabel(self.footer)
        self.label_9.setObjectName(u"label_9")
        font5 = QFont()
        font5.setFamily(u"Segoe UI")
        font5.setPointSize(11)
        font5.setBold(True)
        font5.setWeight(75)
        self.label_9.setFont(font5)

        self.horizontalLayout_5.addWidget(self.label_9, 0, Qt.AlignHCenter)


        self.verticalLayout.addWidget(self.footer)

        MainWindow.setCentralWidget(self.centralwidget)
        self.mainBody.raise_()
        self.footer.raise_()
        self.header.raise_()

        self.retranslateUi(MainWindow)
        self.btn_exit.clicked.connect(MainWindow.close)

        self.mainPages.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.menuBtn.setText("")
        self.label_5.setText("")
        self.btn_home.setText(QCoreApplication.translate("MainWindow", u"HERMES_HE-Optics App", None))
        self.pushButton_4.setText("")
        self.pushButton_2.setText("")
        self.pushButton_3.setText("")
        self.pushButton.setText("")
        self.btn_measure.setText(QCoreApplication.translate("MainWindow", u"Measurement", None))
        self.btn_control.setText(QCoreApplication.translate("MainWindow", u"TV Set Control", None))
        self.btn_serial.setText(QCoreApplication.translate("MainWindow", u"Serial Connect", None))
        self.btn_setup.setText(QCoreApplication.translate("MainWindow", u"Setup", None))
        self.btn_help.setText(QCoreApplication.translate("MainWindow", u"Help", None))
        self.btn_exit.setText(QCoreApplication.translate("MainWindow", u"Exit Program", None))
        self.label_2.setText("")
#if QT_CONFIG(whatsthis)
        self.lineEdit.setWhatsThis("")
#endif // QT_CONFIG(whatsthis)
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Model", None))
        self.lineEdit_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Panel", None))
        self.lineEdit_6.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Panel", None))
        self.addBtn.setText(QCoreApplication.translate("MainWindow", u"Add", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"HERMES @Copyright 2023", None))
    # retranslateUi

