from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton
from PyQt5.QtGui import QColor

class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.button_list = []
        for i in range(1, 11):
            button = QPushButton(str(i), self)
            button.setGeometry(50 + (i-1)*60, 50, 50, 50)
            self.button_list.append(button)

        self.a_button = QPushButton("a", self)
        self.a_button.setGeometry(50, 120, 200, 50)
        self.a_button.clicked.connect(self.change_color)

    def change_color(self):
        for i, button in enumerate(self.button_list):
            if (i+1) % 2 != 0:  # 홀수 번호의 버튼만 배경색을 변경합니다.
                button.setStyleSheet("background-color: red")

if __name__ == "__main__":
    app = QApplication([])
    window = MyWindow()
    window.show()
    app.exec_()