# pykonica
Python package to control Konica Minolta devices.
