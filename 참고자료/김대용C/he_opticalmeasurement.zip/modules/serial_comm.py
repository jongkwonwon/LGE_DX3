import time
import serial
from past.builtins import raw_input

# configure the serial connections (the parameters differs on the device you are connecting to)
ser = serial.Serial(
    port='COM3',
    baudrate=38400,
    parity=serial.PARITY_EVEN,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.SEVENBITS,
    timeout=1
)
ser.isOpen()
# print('Enter your commands below.\r\nInsert "exit" to leave the application.')
input = 1
while 1:
    # get keyboard input
    input = raw_input(">> ")
    if input == 'exit':
        ser.close()
        exit()
    else:
        # send the character to the device
        # (note that I happend a \r\n carriage return and line feed to the characters - this is requested by my device)
        ser.write((input+"\r\n").encode())
        out = ''
        # let's wait one second before reading output (let's give device time to answer)
        time.sleep(0)
        out = ser.readline().decode()
        print(">> " + out)
