import os, path
from ldap3 import Connection, Server, Tls, ALL, SUBTREE,core
import ssl

 #from myPC, get username and domainname
username=os.environ.get('USERNAME')
# environKeyList=os.environ.keys()
domain=os.environ.get('USERDOMAIN')
print(username)
print(domain)
# check all environ Key and values of myPC
# print(environKeyList)

SIMPLE_BIND_ID='addhost'
SIMPLE_BIND_PW='1qaz2wsx'
# SIMPLE_BIND_ID='shook.lee@lge.com'
# SIMPLE_BIND_PW='ilove113!!'

username="anta.an"
username = "user"   #없는 사람

def login_check(SIMPLE_BIND_ID,SIMPLE_BIND_PW,searchID):
    AUTH_LDAP_BASE_DN = "OU=LGE Users,dc=LGE,dc=NET"
    AUTH_LDAP_SEARCH_BASE = "dc=lge,dc=net"
    LDAP_PORT = 636 # secure LDAP : 636 or 3269

    tls_conf = Tls(
                    validate=ssl.CERT_REQUIRED,
                    ciphers='DEFAULT:@SECLEVEL=1'
                )
    
    # both query works
    query = f"(sAMAccountName={username})"
    query = f"(cn={username})"
    server = Server('ldaps://lgesaads01.lge.net',port=LDAP_PORT, tls=tls_conf, get_info=ALL)

    i=0

    try:
        with Connection(server, user=SIMPLE_BIND_ID, password=SIMPLE_BIND_PW, auto_bind=True,auto_encode=False) as conn:
            print(repr(conn))
            
            conn.search(AUTH_LDAP_BASE_DN, query, attributes=('CN'))
            if conn.entries:
                print(f'ID: {conn.entries[0].cn}')
            result = conn.extend.standard.paged_search(search_base=AUTH_LDAP_SEARCH_BASE,
                    search_filter=query,
                    search_scope=SUBTREE,
                    #attributes=["*"], #
                    attributes=['name','department','displayName'],
                    get_operational_attributes=False)
            for r in result:
                print(i)
                print(r)
                # if i==6:
                if 'attributes' in r.keys():
                    output_name=r['attributes']['name']
                    output_department=r['attributes']['department']
                    output_displayName=r['attributes']['displayName']
                    print(output_name)
                    print(output_department)
                    print(output_displayName)
                    #IMPORTANT!!!!!
                    #한글이 꺠져서 나오는 경우, attribute.key의 타입이 bytes인 경우, utf-8로 인코딩이 필요하다...
                    #그런데 한번 인코딩 하면, 그 다음부터는 인코딩할 필요없이 제대로 한글이 나온다. 즉, 초기 1회만 인코딩하면, 더이상 인코딩 할 필요없음.
                    # print(type(r['raw_attributes']['department'][0]))  --> 'bytes'
                    # print(output_name.encode('utf-8'))
                    # print(output_department.encode('utf-8'))
    except core.exceptions.LDAPBindError:  #Error Case1. ID/PW Matching NG
        print("Check ID and Password")
        result = False
        output_name=[]
        output_department=[]
        output_displayName=[]

    if output_displayName==[]:
        print("Check your ID")
        result=False
        output_name=[]
        output_department=[]
        output_displayName=[]

    else : result = True

    return result,output_name,output_department,output_displayName
#from myPC, get username and domainname

loginResult,userID,userDepartment,userInfo=login_check(SIMPLE_BIND_ID,SIMPLE_BIND_PW,username)

if loginResult== True :
    print(userInfo)
elif loginResult==False : 
    print("NGNGNG")