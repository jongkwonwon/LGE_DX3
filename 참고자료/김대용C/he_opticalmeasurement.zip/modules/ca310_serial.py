import time
import serial
from past.builtins import raw_input

# configure the serial connections (the parameters differs on the device you are connecting to)
ser = serial.Serial(
    port='COM3',
    baudrate=38400,
    parity=serial.PARITY_EVEN,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.SEVENBITS,
    timeout=None
)
ser.isOpen()
# print('Enter your commands below.\r\nInsert "exit" to leave the application.')
input = 1
while 1:
    # get keyboard input
    input = raw_input(">> ")
    if input == 'exit':
        ser.close()
        exit()
    else:
        ser.write((input+"\r\n").encode())
        out = ser.read_until(b'\r')
        print(out)

