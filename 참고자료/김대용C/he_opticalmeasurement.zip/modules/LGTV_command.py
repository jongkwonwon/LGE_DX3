#show commands for TV remote control
# Bypass조건	
#   1. White Balance - 현재 값 read
#    - 192/192/192 setting
#  	2. Instart > Dimming/dynamic contrast Ratio off
#  	3.Input Label PC -> HDMI로 변경
#  	4. PSM ,Sports로 변경
#  	5.AI Service - Brightness Settings 등 off
#  	6. Energy Saving - off
#  	7. Picture setting : 100/100/50/0/50
#  	8. Pitcture Setting : enhance all off
#  	---측정 실행
#  	9. Picture Setting : reset
#  	10.5/6 다시 reset
#  	11. 2. reset
#  	12. White balance read한값으로 원복

class Const(object, metaclass=MetaConst):
    def __getattr__(self, name):
        return self[name]

    def __setattr__(self, name, value):
        raise TypeError


class TVCommand_production(Const):
    #Commands for White Balance
    WHITE="wb 00 3a"
    RED = "wb 00 4a"
    GREEN = "wb 00 5a"
    BLUE = "wb 00 6a"
    WB_START="wb 00 00"
    WB_END = "wb 00 ff"
    WHITE_204 = "wb 01 00"
    WB_MEDIUM_R_GAIN = "ja 00 "
    WB_MEDIUM_G_GAIN = "jb 00 "
    WB_MEDIUM_B_GAIN = "jc 00 "
    WB_WARM_R_GAIN = "jd 00 "
    WB_WARM_G_GAIN = "je 00 "
    WB_WARM_B_GAIN = "jf 00 "
    WB_COOL_R_GAIN = "jg 00 "
    WB_COOL_G_GAIN = "jh 00 "
    WB_COOL_B_GAIN = "ji 00 "
    READ_WB_GAINS = "jm 00 ff ff ff ff ff ff ff ff ff"
    WRITE_WB_GAINS = "jm 00"
    WRITE_WB_COOL_GAIN = "ku 00 00"
    WRITE_WB_MEDIUM_GAIN = "ku 00 01"
    WRITE_WB_WARM_GAIN = "ku 00 02"

    #Common Function
    READ_HR_TIME = "ld 00 00"
    READ_SET_SERIALNUMBER = ""
    REMOTELOCK = "km 00 "
    TV_POWER_OFF = "ka 00 00"
    TV_POWER_ON = "ka 00 01"
    RC_ASPECTRATIO = "mc 00 79"
    RC_TVPC = "mc 00 9B"   #이 기능 뭐지?
    RC_INSTOP = "mc 00 fa"
    RC_INSTART = "mc 00 fb"
    RC_ADJUST = "mc 00 ff"
       
    #PQ SETTINGS    
    ENERGY_SAVING = "jq 00 "
    BACKLIGHT = "mg 00 "
    CONTRAST = "kg 00 "
    BRIGHTNESS = "kh 00 "
    COLOUR = "kj 00 "
    TINT = "ki 00 "
    SHARPNESS = "kk 00 "
    CCT = "ku 00 "

    #REMOTE CONTROL
    RC_POWERONLY = "mc 00 fe"
    RC_EXIT = "mc 00 5b"
    RC_POWER_OFF = "mc 00 08"
    RC_CH_UP = "mc 00 00"
    RC_CH_DN = "mc 00 01"
    RC_VOL_UP = "mc 00 02"
    RC_VOL_DN = "mc 00 03"
    RC_ARROWKEY_RIGHT = "mc 00 06"
    RC_ARROWKEY_LEFT = "mc 00 07"
    RC_ARROWKEY_UP = "mc 00 40"
    RC_ARROWKEY_DN = "mc 00 41"
    RC_INPUT = "mc 00 0b"
    RC_BACK = "mc 00 28"
    RC_MENU = "mc 00 43"
    RC_OK = "mc 00 44"
    RC_PSM = "mc 00 4d"
    RC_YELLOW = "mc 00 63"

class TVCommand_luna(Const):
    