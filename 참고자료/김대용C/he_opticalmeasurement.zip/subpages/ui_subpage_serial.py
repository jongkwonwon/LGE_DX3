# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'subpage_serial.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import QSS_Resources_rc
import picture_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1107, 832)
        Form.setStyleSheet(u"*{\n"
"    border: none;\n"
"	background-color: transparent;\n"
"	background: transparent;\n"
"	padding: 0;\n"
"	margin: 0;\n"
"	color: #fff;\n"
"}\n"
"\n"
"#sendBtn, #clearBtn{\n"
"    border : 2px outset rgb(128, 128, 128);\n"
"	background-color : rgb(192,192,192);\n"
"	color : black;\n"
"}\n"
"\n"
"QLineEdit, QTextEdit{\n"
"    background-color: white;\n"
"	color : black;\n"
"    border : 1px solid rgb(192, 192, 192);\n"
"}\n"
"\n"
"#serialframe{\n"
"   background-color: #27263c;\n"
"   border-left:1px solid #cc5bce;\n"
"   border-top-left-radius : 20px;\n"
"   border-bottom-left-radius : 20px;\n"
"   border-top-right-radius : 20px;\n"
"   border-bottom-right-radius : 20px;\n"
"}\n"
"\n"
"QComboBox{\n"
"	 background-color: rgb(224,224,224);\n"
"     color : black;\n"
"}\n"
"\n"
"#serialcntBtn{\n"
"	color: white;\n"
"    border-image: url(\":/etc/gradient.png\");\n"
"	border-radius: 15px;\n"
"    text-align:center;\n"
"}\n"
"\n"
"#serialDiscntBtn{\n"
"	color: white;\n"
"    border-image: url(\":/etc/black.pn"
                        "g\");\n"
"	border-radius: 15px;\n"
"    text-align:center;\n"
"}")
        self.serialframe = QFrame(Form)
        self.serialframe.setObjectName(u"serialframe")
        self.serialframe.setGeometry(QRect(290, 50, 461, 701))
        self.serialframe.setFrameShape(QFrame.StyledPanel)
        self.serialframe.setFrameShadow(QFrame.Raised)
        self.gridLayout_7 = QGridLayout(self.serialframe)
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.serialGrid = QGridLayout()
        self.serialGrid.setObjectName(u"serialGrid")
        self.serialGrid.setHorizontalSpacing(10)
        self.serialGrid.setVerticalSpacing(15)
        self.serialGrid.setContentsMargins(10, 10, 10, 10)
        self.paritycombo = QComboBox(self.serialframe)
        self.paritycombo.addItem("")
        self.paritycombo.addItem("")
        self.paritycombo.addItem("")
        self.paritycombo.setObjectName(u"paritycombo")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.paritycombo.sizePolicy().hasHeightForWidth())
        self.paritycombo.setSizePolicy(sizePolicy)
        self.paritycombo.setMaximumSize(QSize(16777215, 30))
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(12)
        self.paritycombo.setFont(font)
        self.paritycombo.setInsertPolicy(QComboBox.InsertAlphabetically)

        self.serialGrid.addWidget(self.paritycombo, 2, 1, 1, 1)

        self.label_53 = QLabel(self.serialframe)
        self.label_53.setObjectName(u"label_53")
        sizePolicy.setHeightForWidth(self.label_53.sizePolicy().hasHeightForWidth())
        self.label_53.setSizePolicy(sizePolicy)
        font1 = QFont()
        font1.setFamily(u"Segoe UI")
        font1.setPointSize(12)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_53.setFont(font1)
        self.label_53.setAlignment(Qt.AlignCenter)

        self.serialGrid.addWidget(self.label_53, 3, 0, 1, 1)

        self.label_51 = QLabel(self.serialframe)
        self.label_51.setObjectName(u"label_51")
        sizePolicy.setHeightForWidth(self.label_51.sizePolicy().hasHeightForWidth())
        self.label_51.setSizePolicy(sizePolicy)
        self.label_51.setFont(font1)
        self.label_51.setAlignment(Qt.AlignCenter)

        self.serialGrid.addWidget(self.label_51, 1, 0, 1, 1)

        self.label_52 = QLabel(self.serialframe)
        self.label_52.setObjectName(u"label_52")
        sizePolicy.setHeightForWidth(self.label_52.sizePolicy().hasHeightForWidth())
        self.label_52.setSizePolicy(sizePolicy)
        self.label_52.setFont(font1)
        self.label_52.setAlignment(Qt.AlignCenter)

        self.serialGrid.addWidget(self.label_52, 2, 0, 1, 1)

        self.clearBtn = QPushButton(self.serialframe)
        self.clearBtn.setObjectName(u"clearBtn")
        sizePolicy.setHeightForWidth(self.clearBtn.sizePolicy().hasHeightForWidth())
        self.clearBtn.setSizePolicy(sizePolicy)
        font2 = QFont()
        font2.setFamily(u"Segoe UI")
        font2.setPointSize(12)
        font2.setBold(False)
        font2.setWeight(50)
        self.clearBtn.setFont(font2)
        self.clearBtn.setCursor(QCursor(Qt.PointingHandCursor))

        self.serialGrid.addWidget(self.clearBtn, 5, 3, 1, 1)

        self.label_50 = QLabel(self.serialframe)
        self.label_50.setObjectName(u"label_50")
        sizePolicy.setHeightForWidth(self.label_50.sizePolicy().hasHeightForWidth())
        self.label_50.setSizePolicy(sizePolicy)
        self.label_50.setFont(font1)
        self.label_50.setAlignment(Qt.AlignCenter)

        self.serialGrid.addWidget(self.label_50, 0, 0, 1, 1)

        self.label_59 = QLabel(self.serialframe)
        self.label_59.setObjectName(u"label_59")
        self.label_59.setFont(font1)
        self.label_59.setAlignment(Qt.AlignCenter)

        self.serialGrid.addWidget(self.label_59, 4, 0, 1, 1)

        self.stopcombo = QComboBox(self.serialframe)
        self.stopcombo.addItem("")
        self.stopcombo.addItem("")
        self.stopcombo.setObjectName(u"stopcombo")
        sizePolicy.setHeightForWidth(self.stopcombo.sizePolicy().hasHeightForWidth())
        self.stopcombo.setSizePolicy(sizePolicy)
        self.stopcombo.setMaximumSize(QSize(16777215, 30))
        self.stopcombo.setFont(font)
        self.stopcombo.setInsertPolicy(QComboBox.InsertAlphabetically)

        self.serialGrid.addWidget(self.stopcombo, 3, 1, 1, 1)

        self.bytecombo = QComboBox(self.serialframe)
        self.bytecombo.addItem("")
        self.bytecombo.addItem("")
        self.bytecombo.setObjectName(u"bytecombo")
        sizePolicy.setHeightForWidth(self.bytecombo.sizePolicy().hasHeightForWidth())
        self.bytecombo.setSizePolicy(sizePolicy)
        self.bytecombo.setMaximumSize(QSize(16777215, 30))
        self.bytecombo.setFont(font)
        self.bytecombo.setInsertPolicy(QComboBox.InsertAlphabetically)

        self.serialGrid.addWidget(self.bytecombo, 4, 1, 1, 1)

        self.portcombo = QComboBox(self.serialframe)
        self.portcombo.setObjectName(u"portcombo")
        sizePolicy.setHeightForWidth(self.portcombo.sizePolicy().hasHeightForWidth())
        self.portcombo.setSizePolicy(sizePolicy)
        self.portcombo.setMaximumSize(QSize(16777215, 30))
        self.portcombo.setFont(font)
        self.portcombo.setInsertPolicy(QComboBox.InsertAlphabetically)

        self.serialGrid.addWidget(self.portcombo, 0, 1, 1, 1)

        self.baudcombo = QComboBox(self.serialframe)
        self.baudcombo.addItem("")
        self.baudcombo.addItem("")
        self.baudcombo.addItem("")
        self.baudcombo.addItem("")
        self.baudcombo.addItem("")
        self.baudcombo.setObjectName(u"baudcombo")
        sizePolicy.setHeightForWidth(self.baudcombo.sizePolicy().hasHeightForWidth())
        self.baudcombo.setSizePolicy(sizePolicy)
        self.baudcombo.setMaximumSize(QSize(16777215, 30))
        self.baudcombo.setFont(font)
        self.baudcombo.setInsertPolicy(QComboBox.InsertAlphabetically)

        self.serialGrid.addWidget(self.baudcombo, 1, 1, 1, 1)

        self.serialcommstatus = QTextEdit(self.serialframe)
        self.serialcommstatus.setObjectName(u"serialcommstatus")

        self.serialGrid.addWidget(self.serialcommstatus, 6, 0, 1, 4)

        self.command = QLineEdit(self.serialframe)
        self.command.setObjectName(u"command")
        self.command.setMaximumSize(QSize(16777215, 30))
        self.command.setFont(font)

        self.serialGrid.addWidget(self.command, 5, 0, 1, 2)

        self.sendBtn = QPushButton(self.serialframe)
        self.sendBtn.setObjectName(u"sendBtn")
        sizePolicy.setHeightForWidth(self.sendBtn.sizePolicy().hasHeightForWidth())
        self.sendBtn.setSizePolicy(sizePolicy)
        self.sendBtn.setFont(font2)
        self.sendBtn.setCursor(QCursor(Qt.PointingHandCursor))

        self.serialGrid.addWidget(self.sendBtn, 5, 2, 1, 1)

        self.serialDiscntBtn = QPushButton(self.serialframe)
        self.serialDiscntBtn.setObjectName(u"serialDiscntBtn")
        sizePolicy.setHeightForWidth(self.serialDiscntBtn.sizePolicy().hasHeightForWidth())
        self.serialDiscntBtn.setSizePolicy(sizePolicy)
        font3 = QFont()
        font3.setFamily(u"Segoe UI")
        font3.setPointSize(13)
        font3.setBold(True)
        font3.setWeight(75)
        self.serialDiscntBtn.setFont(font3)
        self.serialDiscntBtn.setCursor(QCursor(Qt.PointingHandCursor))

        self.serialGrid.addWidget(self.serialDiscntBtn, 3, 2, 2, 2)

        self.serialcntBtn = QPushButton(self.serialframe)
        self.serialcntBtn.setObjectName(u"serialcntBtn")
        self.serialcntBtn.setEnabled(True)
        sizePolicy.setHeightForWidth(self.serialcntBtn.sizePolicy().hasHeightForWidth())
        self.serialcntBtn.setSizePolicy(sizePolicy)
        self.serialcntBtn.setFont(font3)
        self.serialcntBtn.setCursor(QCursor(Qt.PointingHandCursor))

        self.serialGrid.addWidget(self.serialcntBtn, 1, 2, 2, 2)

        self.serialGrid.setRowStretch(5, 2)
        self.serialGrid.setColumnStretch(0, 3)
        self.serialGrid.setColumnStretch(1, 2)
        self.serialGrid.setColumnStretch(2, 1)
        self.serialGrid.setColumnStretch(3, 1)

        self.gridLayout_7.addLayout(self.serialGrid, 0, 0, 1, 1)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.paritycombo.setItemText(0, QCoreApplication.translate("Form", u"EVEN", None))
        self.paritycombo.setItemText(1, QCoreApplication.translate("Form", u"ODD", None))
        self.paritycombo.setItemText(2, QCoreApplication.translate("Form", u"NONE", None))

        self.label_53.setText(QCoreApplication.translate("Form", u"Stop Bits", None))
        self.label_51.setText(QCoreApplication.translate("Form", u"Baud Rate", None))
        self.label_52.setText(QCoreApplication.translate("Form", u"Parity", None))
        self.clearBtn.setText(QCoreApplication.translate("Form", u"Clear", None))
        self.label_50.setText(QCoreApplication.translate("Form", u"Serial Port", None))
        self.label_59.setText(QCoreApplication.translate("Form", u"Byte Size", None))
        self.stopcombo.setItemText(0, QCoreApplication.translate("Form", u"2", None))
        self.stopcombo.setItemText(1, QCoreApplication.translate("Form", u"1", None))

        self.bytecombo.setItemText(0, QCoreApplication.translate("Form", u"7", None))
        self.bytecombo.setItemText(1, QCoreApplication.translate("Form", u"8", None))

        self.baudcombo.setItemText(0, QCoreApplication.translate("Form", u"38400", None))
        self.baudcombo.setItemText(1, QCoreApplication.translate("Form", u"115200", None))
        self.baudcombo.setItemText(2, QCoreApplication.translate("Form", u"57600", None))
        self.baudcombo.setItemText(3, QCoreApplication.translate("Form", u"19200", None))
        self.baudcombo.setItemText(4, QCoreApplication.translate("Form", u"9600", None))

        self.command.setText("")
        self.sendBtn.setText(QCoreApplication.translate("Form", u"Send", None))
        self.serialDiscntBtn.setText(QCoreApplication.translate("Form", u"Disconnect", None))
        self.serialcntBtn.setText(QCoreApplication.translate("Form", u"Connect", None))
    # retranslateUi

