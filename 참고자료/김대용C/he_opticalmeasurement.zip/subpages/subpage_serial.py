import os
from PySide2.QtWidgets import QApplication 
import sys
sys.path.insert(0,'subpages')
from ui_subpage_serial import *
########################################################################
# IMPORT SERIALTOOLS
import serial.tools.list_ports
import time
from datetime import datetime
import serial
ser = serial.Serial()
########################################################################

class Widget_serial(QWidget):
    def __init__(self, parent=None):
        #super(self.__class__,self).__init__(parent)
        QWidget.__init__(self)
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.Serial_Scan()
        ########################################################################
        # SERIAL COMM (CLICK EVENT)
        ########################################################################
        self.ui.serialcntBtn.clicked.connect(self.Serial_Connect)
        self.ui.serialDiscntBtn.clicked.connect(self.Serial_DisConnect)
        self.ui.sendBtn.clicked.connect(self._communication)
        self.ui.command.returnPressed.connect(self._communication)
    ########################################################################
    ## SERIAL COMM. STATUS(LIKE TERATERM)
    ########################################################################
    def Serial_Scan(self):
        self.ui.serialcommstatus.setText("Scan")
        ports = serial.tools.list_ports.comports()
        connected = []
        for port in ports :
            connected.append(port.device)
        self.ui.serialcommstatus.setText("Scanned COM ports: " + str(connected)[2:6] + "\r\n")
        if connected :
            self.ui.portcombo.addItems(connected)
        else :
            self.ui.portcombo.addItem("Nothing")
    # Make a connection of Serial comm.
    def Serial_Connect(self):
        if self.ui.portcombo.currentText() == "Nothing":
            self.ui.serialcommstatus.append("The device could not be found." + "\n")
        else:
            ser.port = self.ui.portcombo.currentText()
            ser.baudrate = self.ui.baudcombo.currentText()
            if self.ui.paritycombo.currentText() == 'EVEN':
                ser.parity = serial.PARITY_EVEN
            elif self.ui.paritycombo.currentText() == 'ODD':
                ser.parity = serial.PARITY_ODD
            elif self.ui.paritycombo.currentText() == 'NONE':
                ser.parity = serial.PARITY_NONE

            if self.ui.stopcombo.currentText() == '1':
                ser.stopbits = serial.STOPBITS_ONE
            elif self.ui.stopcombo.currentText() == '2':
                ser.stopbits = serial.STOPBITS_TWO

            if self.ui.bytecombo.currentText() == "7":
                ser.bytesize = serial.SEVENBITS
            elif self.ui.bytecombo.currentText() == "8":
                ser.bytesize = serial.EIGHTBITS
            ser.timeout = None

            if not ser.isOpen():
                ser.open()
                ser.write(("COM,0"+"\r\n").encode())
                out = ser.read_until(b'\r').decode()
                print(out)
                if not out == "":
                    self.ui.serialcommstatus.append("Connected COM ports : " + ser.port + "\n")
                else:
                    self.ui.serialcommstatus.append("Try again\n")
                    ser.close()
            else:
                self.ui.serialcommstatus.append("Already Connected COM ports : " + ser.port + "\n")
    def Serial_DisConnect(self):
        ser.close()
        self.ui.serialcommstatus.append("DisConnected COM ports : " + ser.port + "\r\n")
    def _communication(self):
        ser.write((self.ui.command.text()+'\r\n').encode())
        # let's wait one second before reading output (let's give device time to answer)
        time.sleep(0)
        out = ser.read_until(b'\r').decode()
        self.ui.serialcommstatus.append(">> " + out)
        self.ui.command.clear()

    def printSomeThing(self):
        self.ui.serialcommstatus.setPlainText(self.ui.baudcombo.currentText())  
    
if __name__ == '__main__':
	app = QApplication(sys.argv)
	w = Widget_serial()
	w.show()
	sys.exit(app.exec_())
