# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'subpage_TVcontrolWaPOru.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import QSS_Resources_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1693, 1008)
        font = QFont()
        font.setFamily(u"Arial")
        Form.setFont(font)
        self.horizontalLayoutWidget = QWidget(Form)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(10, 10, 1671, 963))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.btn_TV_serial_hideshow = QPushButton(self.horizontalLayoutWidget)
        self.btn_TV_serial_hideshow.setObjectName(u"btn_TV_serial_hideshow")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_TV_serial_hideshow.sizePolicy().hasHeightForWidth())
        self.btn_TV_serial_hideshow.setSizePolicy(sizePolicy)
        icon = QIcon()
        icon.addFile(u":/icons/Icons/arrow-left-circle_disabled.png", QSize(), QIcon.Selected, QIcon.Off)
        icon.addFile(u":/icons/Icons/arrow-right-circle_disabled.png", QSize(), QIcon.Selected, QIcon.On)
        self.btn_TV_serial_hideshow.setIcon(icon)
        self.btn_TV_serial_hideshow.setIconSize(QSize(30, 30))

        self.verticalLayout_5.addWidget(self.btn_TV_serial_hideshow)

        self.label_4 = QLabel(self.horizontalLayoutWidget)
        self.label_4.setObjectName(u"label_4")
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy1)
        font1 = QFont()
        font1.setFamily(u"Arial")
        font1.setPointSize(15)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_4.setFont(font1)
        self.label_4.setAlignment(Qt.AlignCenter)
        self.label_4.setMargin(15)

        self.verticalLayout_5.addWidget(self.label_4)

        self.verticalSpacer_2 = QSpacerItem(1, 40, QSizePolicy.Minimum, QSizePolicy.Preferred)

        self.verticalLayout_5.addItem(self.verticalSpacer_2)

        self.gridLayout = QGridLayout()
        self.gridLayout.setObjectName(u"gridLayout")
        self.cmb_TV_port = QComboBox(self.horizontalLayoutWidget)
        self.cmb_TV_port.setObjectName(u"cmb_TV_port")
        sizePolicy.setHeightForWidth(self.cmb_TV_port.sizePolicy().hasHeightForWidth())
        self.cmb_TV_port.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.cmb_TV_port, 0, 1, 1, 1)

        self.label_5 = QLabel(self.horizontalLayoutWidget)
        self.label_5.setObjectName(u"label_5")
        sizePolicy1.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy1)
        self.label_5.setAlignment(Qt.AlignCenter)

        self.gridLayout.addWidget(self.label_5, 0, 0, 1, 1)

        self.btn_TV_connect = QPushButton(self.horizontalLayoutWidget)
        self.btn_TV_connect.setObjectName(u"btn_TV_connect")
        sizePolicy.setHeightForWidth(self.btn_TV_connect.sizePolicy().hasHeightForWidth())
        self.btn_TV_connect.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.btn_TV_connect, 1, 1, 1, 1)

        self.btn_TV_disconnect = QPushButton(self.horizontalLayoutWidget)
        self.btn_TV_disconnect.setObjectName(u"btn_TV_disconnect")
        sizePolicy.setHeightForWidth(self.btn_TV_disconnect.sizePolicy().hasHeightForWidth())
        self.btn_TV_disconnect.setSizePolicy(sizePolicy)

        self.gridLayout.addWidget(self.btn_TV_disconnect, 2, 1, 1, 1)

        self.gridLayout.setRowStretch(0, 1)
        self.gridLayout.setRowStretch(1, 1)
        self.gridLayout.setRowStretch(2, 1)
        self.gridLayout.setColumnStretch(0, 1)
        self.gridLayout.setColumnStretch(1, 1)

        self.verticalLayout_5.addLayout(self.gridLayout)

        self.txt_TV_sendMsg = QLineEdit(self.horizontalLayoutWidget)
        self.txt_TV_sendMsg.setObjectName(u"txt_TV_sendMsg")
        sizePolicy.setHeightForWidth(self.txt_TV_sendMsg.sizePolicy().hasHeightForWidth())
        self.txt_TV_sendMsg.setSizePolicy(sizePolicy)

        self.verticalLayout_5.addWidget(self.txt_TV_sendMsg)

        self.btn_TV_sendMsg = QPushButton(self.horizontalLayoutWidget)
        self.btn_TV_sendMsg.setObjectName(u"btn_TV_sendMsg")
        sizePolicy.setHeightForWidth(self.btn_TV_sendMsg.sizePolicy().hasHeightForWidth())
        self.btn_TV_sendMsg.setSizePolicy(sizePolicy)

        self.verticalLayout_5.addWidget(self.btn_TV_sendMsg)

        self.txt_TV_serialStatus = QTextEdit(self.horizontalLayoutWidget)
        self.txt_TV_serialStatus.setObjectName(u"txt_TV_serialStatus")
        sizePolicy1.setHeightForWidth(self.txt_TV_serialStatus.sizePolicy().hasHeightForWidth())
        self.txt_TV_serialStatus.setSizePolicy(sizePolicy1)

        self.verticalLayout_5.addWidget(self.txt_TV_serialStatus)

        self.verticalLayout_5.setStretch(1, 1)
        self.verticalLayout_5.setStretch(2, 1)
        self.verticalLayout_5.setStretch(3, 3)
        self.verticalLayout_5.setStretch(6, 10)

        self.horizontalLayout.addLayout(self.verticalLayout_5)

        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(-1, -1, 10, -1)
        self.label = QLabel(self.horizontalLayoutWidget)
        self.label.setObjectName(u"label")
        self.label.setFont(font1)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setMargin(15)

        self.verticalLayout_3.addWidget(self.label)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer)

        self.frame_3 = QFrame(self.horizontalLayoutWidget)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.label_2 = QLabel(self.frame_3)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(20, 10, 56, 12))
        font2 = QFont()
        font2.setFamily(u"Arial")
        font2.setPointSize(10)
        font2.setBold(True)
        font2.setWeight(75)
        self.label_2.setFont(font2)
        self.cmb_TVinput = QComboBox(self.frame_3)
        self.cmb_TVinput.addItem("")
        self.cmb_TVinput.addItem("")
        self.cmb_TVinput.addItem("")
        self.cmb_TVinput.addItem("")
        self.cmb_TVinput.addItem("")
        self.cmb_TVinput.setObjectName(u"cmb_TVinput")
        self.cmb_TVinput.setGeometry(QRect(80, 0, 161, 27))

        self.verticalLayout_3.addWidget(self.frame_3)

        self.treeWidget_WB = QTreeWidget(self.horizontalLayoutWidget)
        brush = QBrush(QColor(255, 0, 0, 255))
        brush.setStyle(Qt.NoBrush)
        font3 = QFont()
        font3.setKerning(True)
        __qtreewidgetitem = QTreeWidgetItem()
        __qtreewidgetitem.setBackground(3, QColor(0, 0, 255, 100));
        __qtreewidgetitem.setFont(2, font3);
        __qtreewidgetitem.setBackground(2, QColor(0, 255, 0, 100));
        __qtreewidgetitem.setBackground(1, QColor(255, 0, 0, 100));
        __qtreewidgetitem.setForeground(1, brush);
        self.treeWidget_WB.setHeaderItem(__qtreewidgetitem)
        __qtreewidgetitem1 = QTreeWidgetItem(self.treeWidget_WB)
        __qtreewidgetitem1.setCheckState(0, Qt.Checked);
        __qtreewidgetitem2 = QTreeWidgetItem(self.treeWidget_WB)
        __qtreewidgetitem2.setCheckState(0, Qt.Checked);
        __qtreewidgetitem3 = QTreeWidgetItem(self.treeWidget_WB)
        __qtreewidgetitem3.setCheckState(0, Qt.Checked);
        self.treeWidget_WB.setObjectName(u"treeWidget_WB")
        self.treeWidget_WB.setAlternatingRowColors(True)
        self.treeWidget_WB.setAnimated(True)
        self.treeWidget_WB.setAllColumnsShowFocus(True)
        self.treeWidget_WB.header().setDefaultSectionSize(130)

        self.verticalLayout_3.addWidget(self.treeWidget_WB)

        self.treeWidget_Picture = QTreeWidget(self.horizontalLayoutWidget)
        __qtreewidgetitem4 = QTreeWidgetItem()
        __qtreewidgetitem4.setFont(0, font3);
        self.treeWidget_Picture.setHeaderItem(__qtreewidgetitem4)
        __qtreewidgetitem5 = QTreeWidgetItem(self.treeWidget_Picture)
        __qtreewidgetitem6 = QTreeWidgetItem(__qtreewidgetitem5)
        __qtreewidgetitem6.setCheckState(0, Qt.Checked);
        __qtreewidgetitem7 = QTreeWidgetItem(__qtreewidgetitem5)
        __qtreewidgetitem7.setCheckState(0, Qt.Checked);
        __qtreewidgetitem8 = QTreeWidgetItem(self.treeWidget_Picture)
        __qtreewidgetitem9 = QTreeWidgetItem(__qtreewidgetitem8)
        __qtreewidgetitem9.setCheckState(0, Qt.Checked);
        __qtreewidgetitem10 = QTreeWidgetItem(__qtreewidgetitem8)
        __qtreewidgetitem10.setCheckState(0, Qt.Checked);
        __qtreewidgetitem11 = QTreeWidgetItem(self.treeWidget_Picture)
        __qtreewidgetitem12 = QTreeWidgetItem(__qtreewidgetitem11)
        __qtreewidgetitem12.setFlags(Qt.ItemIsSelectable|Qt.ItemIsDragEnabled|Qt.ItemIsDropEnabled|Qt.ItemIsUserCheckable|Qt.ItemIsEnabled|Qt.ItemIsTristate);
        __qtreewidgetitem12.setCheckState(0, Qt.Checked);
        __qtreewidgetitem13 = QTreeWidgetItem(__qtreewidgetitem11)
        __qtreewidgetitem13.setCheckState(0, Qt.Checked);
        __qtreewidgetitem14 = QTreeWidgetItem(__qtreewidgetitem11)
        __qtreewidgetitem14.setFlags(Qt.ItemIsSelectable|Qt.ItemIsUserCheckable|Qt.ItemIsEnabled);
        __qtreewidgetitem15 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem15.setCheckState(0, Qt.Checked);
        __qtreewidgetitem16 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem16.setCheckState(0, Qt.Checked);
        __qtreewidgetitem17 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem17.setCheckState(0, Qt.Checked);
        __qtreewidgetitem18 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem18.setCheckState(0, Qt.Checked);
        __qtreewidgetitem19 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem19.setCheckState(0, Qt.Checked);
        __qtreewidgetitem20 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem20.setCheckState(0, Qt.Checked);
        __qtreewidgetitem21 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem21.setCheckState(0, Qt.Checked);
        __qtreewidgetitem22 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem22.setCheckState(0, Qt.Checked);
        __qtreewidgetitem23 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem23.setCheckState(0, Qt.Checked);
        __qtreewidgetitem24 = QTreeWidgetItem(__qtreewidgetitem14)
        __qtreewidgetitem24.setCheckState(0, Qt.Checked);
        __qtreewidgetitem25 = QTreeWidgetItem(__qtreewidgetitem11)
        __qtreewidgetitem26 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem26.setCheckState(0, Qt.Checked);
        __qtreewidgetitem27 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem27.setCheckState(0, Qt.Checked);
        __qtreewidgetitem28 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem28.setCheckState(0, Qt.Checked);
        __qtreewidgetitem29 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem29.setCheckState(0, Qt.Checked);
        __qtreewidgetitem30 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem30.setCheckState(0, Qt.Checked);
        __qtreewidgetitem31 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem31.setCheckState(0, Qt.Checked);
        __qtreewidgetitem32 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem32.setCheckState(0, Qt.Checked);
        __qtreewidgetitem33 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem33.setCheckState(0, Qt.Checked);
        __qtreewidgetitem34 = QTreeWidgetItem(__qtreewidgetitem25)
        __qtreewidgetitem34.setFlags(Qt.ItemIsDragEnabled|Qt.ItemIsDropEnabled|Qt.ItemIsUserCheckable);
        __qtreewidgetitem34.setCheckState(0, Qt.Unchecked);
        self.treeWidget_Picture.setObjectName(u"treeWidget_Picture")
        font4 = QFont()
        font4.setFamily(u"Arial")
        font4.setPointSize(10)
        font4.setKerning(True)
        self.treeWidget_Picture.setFont(font4)
        self.treeWidget_Picture.setFrameShadow(QFrame.Sunken)
        self.treeWidget_Picture.setAutoScrollMargin(16)
        self.treeWidget_Picture.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.treeWidget_Picture.setAlternatingRowColors(True)
        self.treeWidget_Picture.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.treeWidget_Picture.setIconSize(QSize(20, 20))
        self.treeWidget_Picture.setIndentation(25)
        self.treeWidget_Picture.setUniformRowHeights(False)
        self.treeWidget_Picture.setItemsExpandable(True)
        self.treeWidget_Picture.setSortingEnabled(False)
        self.treeWidget_Picture.setAnimated(True)
        self.treeWidget_Picture.setAllColumnsShowFocus(True)
        self.treeWidget_Picture.setHeaderHidden(False)
        self.treeWidget_Picture.setExpandsOnDoubleClick(True)
        self.treeWidget_Picture.setColumnCount(2)
        self.treeWidget_Picture.header().setCascadingSectionResizes(False)
        self.treeWidget_Picture.header().setMinimumSectionSize(50)
        self.treeWidget_Picture.header().setDefaultSectionSize(300)
        self.treeWidget_Picture.header().setHighlightSections(False)
        self.treeWidget_Picture.header().setProperty("showSortIndicator", False)

        self.verticalLayout_3.addWidget(self.treeWidget_Picture)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(10, 1, 10, 1)
        self.btn_TV_read_all = QPushButton(self.horizontalLayoutWidget)
        self.btn_TV_read_all.setObjectName(u"btn_TV_read_all")
        sizePolicy2 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.btn_TV_read_all.sizePolicy().hasHeightForWidth())
        self.btn_TV_read_all.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.btn_TV_read_all)

        self.btn_TV_read_selected = QPushButton(self.horizontalLayoutWidget)
        self.btn_TV_read_selected.setObjectName(u"btn_TV_read_selected")
        sizePolicy2.setHeightForWidth(self.btn_TV_read_selected.sizePolicy().hasHeightForWidth())
        self.btn_TV_read_selected.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.btn_TV_read_selected)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer)

        self.btn_TVtree_expand = QPushButton(self.horizontalLayoutWidget)
        self.btn_TVtree_expand.setObjectName(u"btn_TVtree_expand")
        sizePolicy2.setHeightForWidth(self.btn_TVtree_expand.sizePolicy().hasHeightForWidth())
        self.btn_TVtree_expand.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.btn_TVtree_expand)

        self.btn_TVtree_collapse = QPushButton(self.horizontalLayoutWidget)
        self.btn_TVtree_collapse.setObjectName(u"btn_TVtree_collapse")
        sizePolicy3 = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.btn_TVtree_collapse.sizePolicy().hasHeightForWidth())
        self.btn_TVtree_collapse.setSizePolicy(sizePolicy3)

        self.horizontalLayout_2.addWidget(self.btn_TVtree_collapse)


        self.verticalLayout_3.addLayout(self.horizontalLayout_2)

        self.verticalLayout_3.setStretch(1, 1)
        self.verticalLayout_3.setStretch(2, 1)
        self.verticalLayout_3.setStretch(3, 3)
        self.verticalLayout_3.setStretch(4, 18)
        self.verticalLayout_3.setStretch(5, 2)

        self.horizontalLayout.addLayout(self.verticalLayout_3)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")

        self.horizontalLayout.addLayout(self.verticalLayout_2)

        self.horizontalLayout.setStretch(0, 2)
        self.horizontalLayout.setStretch(1, 10)
        self.horizontalLayout.setStretch(2, 10)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.btn_TV_serial_hideshow.setText(QCoreApplication.translate("Form", u"\ucd95\uc18c", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"TV Connection", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"COM Port", None))
        self.btn_TV_connect.setText(QCoreApplication.translate("Form", u"Connect", None))
        self.btn_TV_disconnect.setText(QCoreApplication.translate("Form", u"Disconnect", None))
        self.btn_TV_sendMsg.setText(QCoreApplication.translate("Form", u"Send", None))
        self.label.setText(QCoreApplication.translate("Form", u"Read Current Value", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"Input", None))
        self.cmb_TVinput.setItemText(0, QCoreApplication.translate("Form", u"HDMI1", None))
        self.cmb_TVinput.setItemText(1, QCoreApplication.translate("Form", u"HDMI2", None))
        self.cmb_TVinput.setItemText(2, QCoreApplication.translate("Form", u"HDMI3", None))
        self.cmb_TVinput.setItemText(3, QCoreApplication.translate("Form", u"HDMI4", None))
        self.cmb_TVinput.setItemText(4, QCoreApplication.translate("Form", u"USB", None))

        ___qtreewidgetitem = self.treeWidget_WB.headerItem()
        ___qtreewidgetitem.setText(3, QCoreApplication.translate("Form", u"Blue", None));
        ___qtreewidgetitem.setText(2, QCoreApplication.translate("Form", u"Green", None));
        ___qtreewidgetitem.setText(1, QCoreApplication.translate("Form", u"Red", None));
        ___qtreewidgetitem.setText(0, QCoreApplication.translate("Form", u"White Balance", None));

        __sortingEnabled = self.treeWidget_WB.isSortingEnabled()
        self.treeWidget_WB.setSortingEnabled(False)
        ___qtreewidgetitem1 = self.treeWidget_WB.topLevelItem(0)
        ___qtreewidgetitem1.setText(0, QCoreApplication.translate("Form", u"Cool", None));
        ___qtreewidgetitem2 = self.treeWidget_WB.topLevelItem(1)
        ___qtreewidgetitem2.setText(0, QCoreApplication.translate("Form", u"Medium", None));
        ___qtreewidgetitem3 = self.treeWidget_WB.topLevelItem(2)
        ___qtreewidgetitem3.setText(0, QCoreApplication.translate("Form", u"Warm", None));
        self.treeWidget_WB.setSortingEnabled(__sortingEnabled)

        ___qtreewidgetitem4 = self.treeWidget_Picture.headerItem()
        ___qtreewidgetitem4.setText(1, QCoreApplication.translate("Form", u"Read Value", None));
        ___qtreewidgetitem4.setText(0, QCoreApplication.translate("Form", u"Category1", None));

        __sortingEnabled1 = self.treeWidget_Picture.isSortingEnabled()
        self.treeWidget_Picture.setSortingEnabled(False)
        ___qtreewidgetitem5 = self.treeWidget_Picture.topLevelItem(0)
        ___qtreewidgetitem5.setText(0, QCoreApplication.translate("Form", u"InStart", None));
        ___qtreewidgetitem6 = ___qtreewidgetitem5.child(0)
        ___qtreewidgetitem6.setText(0, QCoreApplication.translate("Form", u"Dimming", None));
        ___qtreewidgetitem7 = ___qtreewidgetitem5.child(1)
        ___qtreewidgetitem7.setText(0, QCoreApplication.translate("Form", u"Dynamic Costrast", None));
        ___qtreewidgetitem8 = self.treeWidget_Picture.topLevelItem(1)
        ___qtreewidgetitem8.setText(0, QCoreApplication.translate("Form", u"AI Service", None));
        ___qtreewidgetitem9 = ___qtreewidgetitem8.child(0)
        ___qtreewidgetitem9.setText(0, QCoreApplication.translate("Form", u"AI Picture", None));
        ___qtreewidgetitem10 = ___qtreewidgetitem8.child(1)
        ___qtreewidgetitem10.setText(0, QCoreApplication.translate("Form", u"AI Brightness", None));
        ___qtreewidgetitem11 = self.treeWidget_Picture.topLevelItem(2)
        ___qtreewidgetitem11.setText(0, QCoreApplication.translate("Form", u"Picture Settings", None));
        ___qtreewidgetitem12 = ___qtreewidgetitem11.child(0)
        ___qtreewidgetitem12.setText(0, QCoreApplication.translate("Form", u"PSM", None));
        ___qtreewidgetitem13 = ___qtreewidgetitem11.child(1)
        ___qtreewidgetitem13.setText(0, QCoreApplication.translate("Form", u"Energy Saving", None));
        ___qtreewidgetitem14 = ___qtreewidgetitem11.child(2)
        ___qtreewidgetitem14.setText(0, QCoreApplication.translate("Form", u"Picture Settings", None));
        ___qtreewidgetitem15 = ___qtreewidgetitem14.child(0)
        ___qtreewidgetitem15.setText(0, QCoreApplication.translate("Form", u"Backlight", None));
        ___qtreewidgetitem16 = ___qtreewidgetitem14.child(1)
        ___qtreewidgetitem16.setText(0, QCoreApplication.translate("Form", u"Brightness", None));
        ___qtreewidgetitem17 = ___qtreewidgetitem14.child(2)
        ___qtreewidgetitem17.setText(0, QCoreApplication.translate("Form", u"Costrast", None));
        ___qtreewidgetitem18 = ___qtreewidgetitem14.child(3)
        ___qtreewidgetitem18.setText(0, QCoreApplication.translate("Form", u"Gamma", None));
        ___qtreewidgetitem19 = ___qtreewidgetitem14.child(4)
        ___qtreewidgetitem19.setText(0, QCoreApplication.translate("Form", u"Color Depth", None));
        ___qtreewidgetitem20 = ___qtreewidgetitem14.child(5)
        ___qtreewidgetitem20.setText(0, QCoreApplication.translate("Form", u"Tint", None));
        ___qtreewidgetitem21 = ___qtreewidgetitem14.child(6)
        ___qtreewidgetitem21.setText(0, QCoreApplication.translate("Form", u"Color Gamut", None));
        ___qtreewidgetitem22 = ___qtreewidgetitem14.child(7)
        ___qtreewidgetitem22.setText(0, QCoreApplication.translate("Form", u"Color Temperature", None));
        ___qtreewidgetitem23 = ___qtreewidgetitem14.child(8)
        ___qtreewidgetitem23.setText(0, QCoreApplication.translate("Form", u"Sharpness", None));
        ___qtreewidgetitem24 = ___qtreewidgetitem14.child(9)
        ___qtreewidgetitem24.setText(0, QCoreApplication.translate("Form", u"Video Range", None));
        ___qtreewidgetitem25 = ___qtreewidgetitem11.child(3)
        ___qtreewidgetitem25.setText(0, QCoreApplication.translate("Form", u"Picture Enhances", None));
        ___qtreewidgetitem26 = ___qtreewidgetitem25.child(0)
        ___qtreewidgetitem26.setText(0, QCoreApplication.translate("Form", u"Dynamic Constrast", None));
        ___qtreewidgetitem27 = ___qtreewidgetitem25.child(1)
        ___qtreewidgetitem27.setText(0, QCoreApplication.translate("Form", u"Motion Eye Care", None));
        ___qtreewidgetitem28 = ___qtreewidgetitem25.child(2)
        ___qtreewidgetitem28.setText(0, QCoreApplication.translate("Form", u"Dynamic Color", None));
        ___qtreewidgetitem29 = ___qtreewidgetitem25.child(3)
        ___qtreewidgetitem29.setText(0, QCoreApplication.translate("Form", u"Resolution", None));
        ___qtreewidgetitem30 = ___qtreewidgetitem25.child(4)
        ___qtreewidgetitem30.setText(0, QCoreApplication.translate("Form", u"Smooth Gradation", None));
        ___qtreewidgetitem31 = ___qtreewidgetitem25.child(5)
        ___qtreewidgetitem31.setText(0, QCoreApplication.translate("Form", u"Real Cinema", None));
        ___qtreewidgetitem32 = ___qtreewidgetitem25.child(6)
        ___qtreewidgetitem32.setText(0, QCoreApplication.translate("Form", u"Noise Reduction", None));
        ___qtreewidgetitem33 = ___qtreewidgetitem25.child(7)
        ___qtreewidgetitem33.setText(0, QCoreApplication.translate("Form", u"MPEG Noise Reduction", None));
        ___qtreewidgetitem34 = ___qtreewidgetitem25.child(8)
        ___qtreewidgetitem34.setText(0, QCoreApplication.translate("Form", u"TryMotion", None));
        self.treeWidget_Picture.setSortingEnabled(__sortingEnabled1)

        self.btn_TV_read_all.setText(QCoreApplication.translate("Form", u"Read All", None))
        self.btn_TV_read_selected.setText(QCoreApplication.translate("Form", u"Read Selected", None))
        self.btn_TVtree_expand.setText(QCoreApplication.translate("Form", u"+Expand", None))
        self.btn_TVtree_collapse.setText(QCoreApplication.translate("Form", u"-Collapse", None))
    # retranslateUi

