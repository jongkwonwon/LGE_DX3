import os
import sys 
from PySide2.QtWidgets import QApplication 
from datetime import datetime
sys.path.insert(0,'subpages')
sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
from ui_subpage_TVcontrol import *
########################################################################
# IMPORT SERIALTOOLS
import serial.tools.list_ports
import time
from datetime import datetime
import serial
ser = serial.Serial()
prefixForSerial = ""
########################################################################
class Widget_TVcontrol(QWidget):
    def __init__(self, parent=None):
        #super(self.__class__,self).__init__(parent)
        QWidget.__init__(self)
        
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.ui.treeWidget_Picture.expandAll()
        self.ui.txt_TV_serialStatus.setReadOnly(True)
        self.Serial_Scan()
        
        #self.show()
        ########################################################################
        #UI Control Action
        ########################################################################
        
        self.ui.btn_TV_connect.clicked.connect(self.Serial_Connect)
        self.ui.btn_TV_disconnect.clicked.connect(self.Serial_DisConnect)
        self.ui.btn_TV_sendMsg.clicked.connect(self._communication)
        self.ui.txt_TV_sendMsg.returnPressed.connect(self._communication)
        self.ui.btn_TVtree_expand.clicked.connect(self.ui.treeWidget_Picture.expandAll)
        self.ui.btn_TVtree_collapse.clicked.connect(self.ui.treeWidget_Picture.collapseAll)
        self.ui.btn_TV_serial_hideshow.clicked.connect(self.layout_change)

        # BoxLayout::setStretch(int index, int stretch)
    def layout_change(self):
        if self.ui.btn_TV_serial_hideshow.text() =="축소":
            self.ui.horizontalLayout.setStretch(0,2)
            self.ui.btn_TV_serial_hideshow.setText("확대")
        else:
            self.ui.horizontalLayout.setStretch(0,10)
            self.ui.btn_TV_serial_hideshow.setText("축소")
        
        # self.ui.btn_TVcontrol.clicked.connect(self.printSomeThing)
# ser.write((self.ui.command.text()+'\r\n').encode())
     ########################################################################
    ## SERIAL COMM. STATUS(LIKE TERATERM)
    ########################################################################
    def Serial_Scan(self):
        self.ui.txt_TV_serialStatus.setText("Scan")
        ports = serial.tools.list_ports.comports()
        connected = []
        for port in ports :
            connected.append(port.device)
        self.ui.txt_TV_serialStatus.setText("Scanned COM ports: " + str(connected)[2:6] + "\r\n")
        if connected :
            self.ui.cmb_TV_port.addItems(connected)
        else :
            self.ui.cmb_TV_port.addItem("Nothing")
    # Make a connection of Serial comm.

    def Serial_Connect(self):
        if self.ui.cmb_TV_port.currentText() == "Nothing":
            self.ui.txt_TV_serialStatus.append("The device could not be found." + "\n")
        else:
            ser.port = self.ui.cmb_TV_port.currentText()
            ser.baudrate = '115200'
            ser.parity = serial.PARITY_NONE
            ser.stopbits = serial.STOPBITS_ONE
            ser.bytesize = serial.EIGHTBITS
            ser.timeout = None

            if not ser.isOpen():
                ser.open()
                self.ui.txt_TV_serialStatus.append("Connected COM ports : " + ser.port + "\n")
            else:
                self.ui.txt_TV_serialStatus.append("Already Connected COM ports : " + ser.port + "\n")

    def Serial_DisConnect(self):
        ser.close()
        self.ui.txt_TV_serialStatus.append("DisConnected COM ports : " + ser.port + "\r\n")

    def _communication(self):
        sendMsg = self.ui.txt_TV_sendMsg.text()
        print(sendMsg)
        self.ui.txt_TV_sendMsg.clear()
        self.ui.txt_TV_serialStatus.append("<<"+sendMsg)

        ser.write((sendMsg+'\r\n').encode())
        time.sleep(0.1)
        out = ser.read_all().decode()
        self.ui.txt_TV_serialStatus.append(out)

        self.ui.txt_TV_serialStatus.verticalScrollBar().setValue(self.ui.txt_TV_serialStatus.verticalScrollBar().maximum())

    
if __name__ == '__main__':
	app = QApplication(sys.argv)
	w = Widget_TVcontrol()
	w.show()
	sys.exit(app.exec_())
