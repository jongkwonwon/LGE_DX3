# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'subpage_measure.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from Custom_Widgets.Widgets import QCustomStackedWidget

import QSS_Resources_rc
import picture_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1693, 962)
        Form.setStyleSheet(u"*{\n"
"    border: none;\n"
"	background-color: transparent;\n"
"	background: transparent;\n"
"	paddfog: 0;\n"
"	margin: 0;\n"
"	color: #fff;\n"
"}\n"
"\n"
"QLineEdit, QTextEdit{\n"
"    background-color: white;\n"
"	color : black;\n"
"    border : 1px solid rgb(192, 192, 192);\n"
"}\n"
"\n"
"#ammeasurepage{\n"
"	background-color: #1b1b27;\n"
"}\n"
"\n"
"#autoBtn, #manualBtn{\n"
"    border-top-left-radius : 10px;\n"
"    border-top-right-radius : 10px;\n"
"}\n"
"\n"
"#autoBtn{\n"
"	border-top:2px solid #cc5bce;\n"
"	font-weight:bold;\n"
"}\n"
"\n"
"#manualBtn{\n"
"   background-color: #27263c;\n"
"}\n"
"\n"
"#autoBtn:hover, #manualBtn:hover{\n"
"	border-top:2px solid #cc5bce;\n"
"	font-weight:bold;\n"
"}\n"
"\n"
"QComboBox{\n"
"	 background-color: rgb(224,224,224);\n"
"     color : black;\n"
"}\n"
"\n"
"QListView{\n"
"	color : white;\n"
"}\n"
"\n"
"#widget_5, #widget_4, #widget_6, #pqmeasure, #mesWidget, #reportWidget{\n"
"   background-color: #27263c;\n"
"   border-left:1px solid #cc5bce;\n"
"   border-top-l"
                        "eft-radius : 20px;\n"
"   border-bottom-left-radius : 20px;\n"
"   border-top-right-radius : 20px;\n"
"   border-bottom-right-radius : 20px;\n"
"}\n"
"\n"
"#ca310connBtn, #connectBtn_2, #connectBtn_3, #connectBtn_4, #connectBtn_5,\n"
"#showwindowBtn, #ptnchangeBtn, #ptnchangeBtn_2, #addBtn, #allMeasureBtn,\n"
"#meas_cr, #meas_gamut, #meas_color, #serialcntBtn, #procress_mea, #btn_gmaStart{\n"
"	color: white;\n"
"    border-image: url(\":/etc/gradient.png\");\n"
"	border-radius: 15px;\n"
"    text-align:center;\n"
"}\n"
"\n"
"#ca310discBtn, #disconnectBtn_2, #disconnectBtn_3, #disconnectBtn_4, #disconnectBtn_5, #serialDiscntBtn{\n"
"	color: white;\n"
"    border-image: url(\":/etc/black.png\");\n"
"	border-radius: 15px;\n"
"    text-align:center;\n"
"}\n"
"\n"
"#allStopBtn, #btn_gmaStop{\n"
"	color: white;\n"
"    border-image: url(\":/etc/stop.png\");\n"
"	border-radius: 15px;\n"
"    text-align:center;\n"
"}\n"
"\n"
"#uploadBtn, #btn_report{\n"
"    background-color: orange;\n"
"    border : 2px outset rgb(12"
                        "8, 128, 128);\n"
"	border-radius: 10px;\n"
"    text-align:mid;\n"
"}\n"
"\n"
"#ca310connBtn:hover, #connectBtn_2:hover, #connectBtn_3:hover, #connectBtn_4:hover, #connectBtn_5:hover,\n"
"#showwindowBtn:hover, #ptnchangeBtn:hover, #ptnchangeBtn_2:hover, #addBtn:hover, #allMeasureBtn:hover,\n"
"#meas_cr:hover, #meas_gamut:hover, #meas_color:hover, #serialcntBtn:hover, #ca310discBtn:hover, #disconnectBtn_2:hover,\n"
"#disconnectBtn_3:hover, #disconnectBtn_4:hover, #disconnectBtn_5:hover, #serialDiscntBtn:hover, #allStopBtn:hover, #uploadBtn:hover,\n"
"#win_black:hover, #win_black_2:hover, #win_white:hover, #win_white_2:hover, #win_yellow:hover, #win_yellow_2:hover,\n"
"#win_magen:hover, #win_magen_2:hover, #win_cyan:hover, #win_cyan_2:hover, #win_blue:hover, #win_blue_2:hover,\n"
"#win_green:hover, #win_green_2:hover, #win_red:hover, #win_red_2:hover, #win_all:hover, #win_all_2:hover, #sendBtn:hover, #clearBtn:hover,\n"
"#procress_mea:hover, #gray_0:hover, #gray_8:hover, #gray_16:hover, #gray_24:hover, #gray_32:"
                        "hover, #gray_40:hover, #gray_48:hover, #gray_56:hover\n"
"#gray_64:hover, #gray_72:hover, #gray_80:hover, #gray_88:hover, #gray_96:hover, #gray_104:hover, #gray_112:hover, #gray_120:hover, #gray_128:hover\n"
"#gray_136:hover, #gray_144:hover, #gray_152:hover, #gray_160:hover, #gray_168:hover, #gray_176:hover, #gray_184:hover, #gray_192:hover, #gray_200:hover\n"
"#gray_208:hover, #gray_216:hover, #gray_224:hover, #gray_232:hover, #gray_240:hover, #gray_248:hover, #gray_255:hover,  #btn_gmaStart:hover, #btn_gmaStop:hover\n"
"{\n"
"	border : 2px inset transparent;\n"
"}\n"
"#gray_136:hover, #gray_144:hover, #gray_152:hover, #gray_160:hover, #gray_168:hover, #gray_176:hover, #gray_184:hover, #gray_192:hover,\n"
"#gray_200:hover, #gray_204:hover, #gray_208:hover, #gray_216:hover, #gray_224:hover, #gray_232:hover, #gray_240:hover, #gray_248:hover, #gray_255:hover\n"
"{\n"
"	border : 2px ridge rgb(128,128,128);\n"
"}\n"
"\n"
"#frame_5, #frame_6, #frame_7{\n"
"	  border : 1px solid gray;\n"
"      border-top-left-radi"
                        "us : 20px;\n"
" 	  border-bottom-left-radius : 20px;\n"
" 	  border-top-right-radius : 20px;\n"
"	   border-bottom-right-radius : 20px;\n"
"}\n"
"\n"
"\n"
"#win_all, #win_all_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : rgb(230, 230, 230);\n"
"	  color : black;\n"
"      text-align:center;\n"
"\n"
"}\n"
"#win_red, #win_red_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : red;\n"
"      text-align:center;\n"
"}\n"
"#win_green, #win_green_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : green;\n"
"      text-align:center;\n"
"}\n"
"#win_blue, #win_blue_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : blue;\n"
"      text-align:center;\n"
"}\n"
"\n"
"#win_cyan, #win_cyan_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : cyan;\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#win_magen, #win_magen_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
" "
                        "     background-color : magenta;\n"
"      text-align:center;\n"
"}\n"
"\n"
"#win_yellow, #win_yellow_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : yellow;\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#win_white, #win_white_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : white;\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#win_black, #win_black_2{\n"
"	  border : 2px outset rgb(128, 128, 128);\n"
"      background-color : black;\n"
"      text-align:center;\n"
"}\n"
"\n"
"\n"
"#lineEdit_3, #lineEdit_4, #lineEdit_5, #sizeEdit, #lineEdit_7, #lineEdit_8, #lineEdit_9, #serialcommstatus{\n"
"	 background-color :  rgb(232, 232, 232);\n"
"\n"
"}\n"
"\n"
"#sizeEdit{\n"
"	 background-color :  rgb(255, 255, 255);\n"
"}\n"
"\n"
"#sizelabel, #result, #label_36{\n"
"	color : yellow;\n"
"}\n"
"\n"
"#backcolor, #totalbackcolor{\n"
"	 background-color :  rgb(0, 0, 0);\n"
"}\n"
"\n"
"#wincolor, #totalwincolor{\n"
"	 background-color"
                        " :  white;\n"
"}\n"
"\n"
"QCheckBox::indicator{\n"
"	width : 18px;\n"
"	height : 18px;\n"
"}\n"
"QCheckBox::indicator:checked{\n"
"    border-image: url(\":/icons/Icons/checkbox_checked.png\");\n"
"}\n"
"QCheckBox::indicator:unchecked{\n"
"    border-image: url(\":/icons/Icons/checkbox_unchecked.png\");\n"
"}\n"
"QCheckBox::indicator:hover{\n"
"	width : 20px;\n"
"	height : 20px;\n"
"}\n"
"\n"
"QRadioButton{\n"
"	spacing : 2 px;\n"
"}\n"
"\n"
"#radioButton_All,#radioButton_Gray{\n"
"	background-color : white;\n"
"	color : black;\n"
"}\n"
"#radioButton_Red{\n"
"	background-color : red;\n"
"}\n"
"#radioButton_Green{\n"
"	background-color : Green;\n"
"}\n"
"#radioButton_Blue{\n"
"	background-color : Blue;\n"
"}\n"
"#radioButton_Magenta{\n"
"	background-color : Magenta;\n"
"}\n"
"#radioButton_Cyan{\n"
"	background-color : Cyan;\n"
"}\n"
"#radioButton_Yellow{\n"
"	background-color : Yellow;\n"
"}\n"
"\n"
"#radioButton_Gray::indicator, #radioButton_Red::indicator, #radioButton_Green::indicator, #radioButton_Blue::ind"
                        "icator,\n"
"#radioButton_Cyan::indicator, #radioButton_Magenta::indicator, #radioButton_Yellow::indicator{\n"
"	width : 19px;\n"
"	height : 19px;\n"
"}\n"
"\n"
"QtableWidget{\n"
"	color : #fff;\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: rgb(128, 128, 128);\n"
"}\n"
"\n"
"QTableCornerButton::section {\n"
"    background:rgb(128, 128, 128);\n"
"    border: 1px rgb(128, 128, 128);\n"
"}\n"
"#gray_0{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(0, 0, 0);\n"
"      text-align:center;\n"
"}\n"
"#gray_8{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(8, 8, 8);\n"
"      text-align:center;\n"
"}\n"
"#gray_16{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(16, 16, 16);\n"
"      text-align:center;\n"
"}\n"
"#gray_24{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(24, 24, 24);\n"
"      text-align:center;\n"
"}\n"
"#gray_32{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
""
                        "      background-color : rgb(32,32,32);\n"
"      text-align:center;\n"
"}\n"
"#gray_40{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(40,40,40);\n"
"      text-align:center;\n"
"}\n"
"#gray_48{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(48,48,48);\n"
"      text-align:center;\n"
"}\n"
"#gray_56{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(56,56,56);\n"
"      text-align:center;\n"
"}\n"
"#gray_64{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(64,64,64);\n"
"      text-align:center;\n"
"}\n"
"#gray_72{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(72,72,72);\n"
"      text-align:center;\n"
"}\n"
"#gray_80{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(80,80,80);\n"
"      text-align:center;\n"
"}\n"
"#gray_88{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(88,88,88);\n"
" "
                        "     text-align:center;\n"
"}\n"
"#gray_96{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(96,96,96);\n"
"      text-align:center;\n"
"}\n"
"#gray_104{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(104,104,104);\n"
"      text-align:center;\n"
"}\n"
"#gray_112{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(112,112,112);\n"
"      text-align:center;\n"
"}\n"
"#gray_120{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(120,120,120);\n"
"      text-align:center;\n"
"}\n"
"#gray_128{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(120,120,120);\n"
"      text-align:center;\n"
"}\n"
"#gray_136{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(136,136,136);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_144{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(144,144,144);\n"
""
                        "	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_152{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(152,152,152);\n"
"	  color : black;\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_160{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(160,160,160);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_168{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(168,168,168);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_176{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(176,176,176);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_184{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(184,184,184);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_192{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(192,192,192);\n"
"	  colo"
                        "r : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_200{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(200,200,200);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"\n"
"#gray_204{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(204,204,204);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_208{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(208,208,208);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_216{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(216,216,216);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_224{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(224,224,224);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_232{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(232,232,232);\n"
"	  color : black;\n"
"      tex"
                        "t-align:center;\n"
"}\n"
"#gray_240{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(240,240,240);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_248{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(248,248,248);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_255{\n"
"	  border : 1px outset rgb(128, 128, 128);\n"
"      background-color : rgb(255,255,255);\n"
"	  color : black;\n"
"      text-align:center;\n"
"}\n"
"#gray_256{\n"
"	color : #1b1b27;\n"
"}")
        self.widget_3 = QWidget(Form)
        self.widget_3.setObjectName(u"widget_3")
        self.widget_3.setGeometry(QRect(10, 10, 1666, 941))
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.widget_3.sizePolicy().hasHeightForWidth())
        self.widget_3.setSizePolicy(sizePolicy)
        self.widget_5 = QWidget(self.widget_3)
        self.widget_5.setObjectName(u"widget_5")
        self.widget_5.setGeometry(QRect(2, 2, 1008, 141))
        sizePolicy.setHeightForWidth(self.widget_5.sizePolicy().hasHeightForWidth())
        self.widget_5.setSizePolicy(sizePolicy)
        self.widget_5.setMinimumSize(QSize(0, 0))
        self.layoutWidget = QWidget(self.widget_5)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(18, 54, 971, 31))
        self.horizontalLayout_6 = QHBoxLayout(self.layoutWidget)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(3, 3, 3, 3)
        self.label_11 = QLabel(self.layoutWidget)
        self.label_11.setObjectName(u"label_11")
        sizePolicy.setHeightForWidth(self.label_11.sizePolicy().hasHeightForWidth())
        self.label_11.setSizePolicy(sizePolicy)
        self.label_11.setMinimumSize(QSize(100, 0))
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(11)
        font.setBold(True)
        font.setUnderline(True)
        font.setWeight(75)
        self.label_11.setFont(font)
        self.label_11.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_11)

        self.label_12 = QLabel(self.layoutWidget)
        self.label_12.setObjectName(u"label_12")
        sizePolicy.setHeightForWidth(self.label_12.sizePolicy().hasHeightForWidth())
        self.label_12.setSizePolicy(sizePolicy)
        self.label_12.setMinimumSize(QSize(100, 0))
        self.label_12.setFont(font)
        self.label_12.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_12)

        self.label_14 = QLabel(self.layoutWidget)
        self.label_14.setObjectName(u"label_14")
        sizePolicy.setHeightForWidth(self.label_14.sizePolicy().hasHeightForWidth())
        self.label_14.setSizePolicy(sizePolicy)
        self.label_14.setMinimumSize(QSize(100, 0))
        self.label_14.setFont(font)
        self.label_14.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_14)

        self.label_18 = QLabel(self.layoutWidget)
        self.label_18.setObjectName(u"label_18")
        sizePolicy.setHeightForWidth(self.label_18.sizePolicy().hasHeightForWidth())
        self.label_18.setSizePolicy(sizePolicy)
        self.label_18.setMinimumSize(QSize(100, 0))
        self.label_18.setFont(font)
        self.label_18.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_18)

        self.label_19 = QLabel(self.layoutWidget)
        self.label_19.setObjectName(u"label_19")
        sizePolicy.setHeightForWidth(self.label_19.sizePolicy().hasHeightForWidth())
        self.label_19.setSizePolicy(sizePolicy)
        self.label_19.setMinimumSize(QSize(100, 0))
        self.label_19.setFont(font)
        self.label_19.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_19)

        self.label_10 = QLabel(self.layoutWidget)
        self.label_10.setObjectName(u"label_10")
        sizePolicy.setHeightForWidth(self.label_10.sizePolicy().hasHeightForWidth())
        self.label_10.setSizePolicy(sizePolicy)
        self.label_10.setMinimumSize(QSize(100, 0))
        self.label_10.setFont(font)
        self.label_10.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_10)

        self.label_16 = QLabel(self.layoutWidget)
        self.label_16.setObjectName(u"label_16")
        sizePolicy.setHeightForWidth(self.label_16.sizePolicy().hasHeightForWidth())
        self.label_16.setSizePolicy(sizePolicy)
        self.label_16.setMinimumSize(QSize(100, 0))
        self.label_16.setFont(font)
        self.label_16.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_16)

        self.label_13 = QLabel(self.layoutWidget)
        self.label_13.setObjectName(u"label_13")
        sizePolicy.setHeightForWidth(self.label_13.sizePolicy().hasHeightForWidth())
        self.label_13.setSizePolicy(sizePolicy)
        self.label_13.setMinimumSize(QSize(100, 0))
        self.label_13.setFont(font)
        self.label_13.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_6.addWidget(self.label_13)

        self.layoutWidget_2 = QWidget(self.widget_5)
        self.layoutWidget_2.setObjectName(u"layoutWidget_2")
        self.layoutWidget_2.setGeometry(QRect(18, 94, 971, 31))
        self.horizontalLayout_7 = QHBoxLayout(self.layoutWidget_2)
        self.horizontalLayout_7.setSpacing(15)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(3, 3, 3, 3)
        self.comboBox_2 = QComboBox(self.layoutWidget_2)
        self.comboBox_2.addItem("")
        self.comboBox_2.setObjectName(u"comboBox_2")
        sizePolicy.setHeightForWidth(self.comboBox_2.sizePolicy().hasHeightForWidth())
        self.comboBox_2.setSizePolicy(sizePolicy)
        self.comboBox_2.setMinimumSize(QSize(0, 0))
        font1 = QFont()
        font1.setFamily(u"Segoe UI")
        font1.setPointSize(10)
        font1.setBold(False)
        font1.setWeight(50)
        self.comboBox_2.setFont(font1)
        self.comboBox_2.setAutoFillBackground(False)
        self.comboBox_2.setEditable(True)

        self.horizontalLayout_7.addWidget(self.comboBox_2)

        self.comboBox_3 = QComboBox(self.layoutWidget_2)
        self.comboBox_3.addItem("")
        self.comboBox_3.setObjectName(u"comboBox_3")
        sizePolicy.setHeightForWidth(self.comboBox_3.sizePolicy().hasHeightForWidth())
        self.comboBox_3.setSizePolicy(sizePolicy)
        self.comboBox_3.setMinimumSize(QSize(0, 0))
        font2 = QFont()
        font2.setFamily(u"Segoe UI")
        font2.setPointSize(10)
        self.comboBox_3.setFont(font2)
        self.comboBox_3.setEditable(True)

        self.horizontalLayout_7.addWidget(self.comboBox_3)

        self.comboBox_5 = QComboBox(self.layoutWidget_2)
        self.comboBox_5.addItem("")
        self.comboBox_5.setObjectName(u"comboBox_5")
        sizePolicy.setHeightForWidth(self.comboBox_5.sizePolicy().hasHeightForWidth())
        self.comboBox_5.setSizePolicy(sizePolicy)
        self.comboBox_5.setMinimumSize(QSize(0, 0))
        self.comboBox_5.setFont(font2)
        self.comboBox_5.setEditable(True)

        self.horizontalLayout_7.addWidget(self.comboBox_5)

        self.comboBox_9 = QComboBox(self.layoutWidget_2)
        self.comboBox_9.addItem("")
        self.comboBox_9.setObjectName(u"comboBox_9")
        sizePolicy.setHeightForWidth(self.comboBox_9.sizePolicy().hasHeightForWidth())
        self.comboBox_9.setSizePolicy(sizePolicy)
        self.comboBox_9.setMinimumSize(QSize(0, 0))
        self.comboBox_9.setFont(font2)
        self.comboBox_9.setEditable(True)

        self.horizontalLayout_7.addWidget(self.comboBox_9)

        self.comboBox_8 = QComboBox(self.layoutWidget_2)
        self.comboBox_8.addItem("")
        self.comboBox_8.setObjectName(u"comboBox_8")
        sizePolicy.setHeightForWidth(self.comboBox_8.sizePolicy().hasHeightForWidth())
        self.comboBox_8.setSizePolicy(sizePolicy)
        self.comboBox_8.setMinimumSize(QSize(0, 0))
        self.comboBox_8.setFont(font2)
        self.comboBox_8.setEditable(True)

        self.horizontalLayout_7.addWidget(self.comboBox_8)

        self.comboBox = QComboBox(self.layoutWidget_2)
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        sizePolicy.setHeightForWidth(self.comboBox.sizePolicy().hasHeightForWidth())
        self.comboBox.setSizePolicy(sizePolicy)
        self.comboBox.setMinimumSize(QSize(0, 0))
        self.comboBox.setFont(font2)
        self.comboBox.setEditable(True)
        self.comboBox.setCurrentText(u"Model Year")

        self.horizontalLayout_7.addWidget(self.comboBox)

        self.comboBox_6 = QComboBox(self.layoutWidget_2)
        self.comboBox_6.addItem("")
        self.comboBox_6.setObjectName(u"comboBox_6")
        sizePolicy.setHeightForWidth(self.comboBox_6.sizePolicy().hasHeightForWidth())
        self.comboBox_6.setSizePolicy(sizePolicy)
        self.comboBox_6.setMinimumSize(QSize(0, 0))
        self.comboBox_6.setFont(font2)
        self.comboBox_6.setEditable(True)
        self.comboBox_6.setCurrentText(u"C_MO")

        self.horizontalLayout_7.addWidget(self.comboBox_6)

        self.comboBox_4 = QComboBox(self.layoutWidget_2)
        self.comboBox_4.addItem("")
        self.comboBox_4.setObjectName(u"comboBox_4")
        sizePolicy.setHeightForWidth(self.comboBox_4.sizePolicy().hasHeightForWidth())
        self.comboBox_4.setSizePolicy(sizePolicy)
        self.comboBox_4.setMinimumSize(QSize(0, 0))
        self.comboBox_4.setFont(font2)
        self.comboBox_4.setEditable(True)
        self.comboBox_4.setCurrentText(u"Edge/Direct")

        self.horizontalLayout_7.addWidget(self.comboBox_4)

        self.layoutWidget_3 = QWidget(self.widget_5)
        self.layoutWidget_3.setObjectName(u"layoutWidget_3")
        self.layoutWidget_3.setGeometry(QRect(18, 6, 281, 42))
        self.horizontalLayout_8 = QHBoxLayout(self.layoutWidget_3)
        self.horizontalLayout_8.setSpacing(0)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.label_15 = QLabel(self.layoutWidget_3)
        self.label_15.setObjectName(u"label_15")
        sizePolicy.setHeightForWidth(self.label_15.sizePolicy().hasHeightForWidth())
        self.label_15.setSizePolicy(sizePolicy)
        font3 = QFont()
        font3.setFamily(u"Segoe UI")
        font3.setPointSize(15)
        font3.setBold(True)
        font3.setUnderline(True)
        font3.setWeight(75)
        self.label_15.setFont(font3)

        self.horizontalLayout_8.addWidget(self.label_15)

        self.showModelFormBtn = QPushButton(self.layoutWidget_3)
        self.showModelFormBtn.setObjectName(u"showModelFormBtn")
        sizePolicy1 = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.showModelFormBtn.sizePolicy().hasHeightForWidth())
        self.showModelFormBtn.setSizePolicy(sizePolicy1)
        font4 = QFont()
        font4.setFamily(u"Segoe UI")
        font4.setPointSize(11)
        font4.setBold(True)
        font4.setItalic(True)
        font4.setWeight(75)
        self.showModelFormBtn.setFont(font4)
        self.showModelFormBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon = QIcon()
        icon.addFile(u":/icons/Icons/plus-square.png", QSize(), QIcon.Normal, QIcon.Off)
        self.showModelFormBtn.setIcon(icon)
        self.showModelFormBtn.setIconSize(QSize(20, 20))

        self.horizontalLayout_8.addWidget(self.showModelFormBtn)

        self.widget_4 = QWidget(self.widget_3)
        self.widget_4.setObjectName(u"widget_4")
        self.widget_4.setGeometry(QRect(2, 157, 381, 201))
        sizePolicy2 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.widget_4.sizePolicy().hasHeightForWidth())
        self.widget_4.setSizePolicy(sizePolicy2)
        self.tabWidget = QTabWidget(self.widget_4)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(29, 37, 331, 151))
        font5 = QFont()
        font5.setFamily(u"Segoe UI")
        font5.setPointSize(11)
        font5.setBold(True)
        font5.setWeight(75)
        self.tabWidget.setFont(font5)
        self.tabWidget.setAutoFillBackground(False)
        self.tabWidget.setTabPosition(QTabWidget.South)
        self.tabWidget.setTabShape(QTabWidget.Triangular)
        self.tabWidget.setElideMode(Qt.ElideNone)
        self.tabWidget.setUsesScrollButtons(True)
        self.tabWidget.setDocumentMode(True)
        self.tabWidget.setTabsClosable(False)
        self.tabWidget.setMovable(False)
        self.tabWidget.setTabBarAutoHide(False)
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.connectBtn_2 = QPushButton(self.tab_2)
        self.connectBtn_2.setObjectName(u"connectBtn_2")
        self.connectBtn_2.setGeometry(QRect(217, 30, 101, 31))
        font6 = QFont()
        font6.setFamily(u"Segoe UI")
        font6.setPointSize(12)
        font6.setBold(True)
        font6.setWeight(75)
        self.connectBtn_2.setFont(font6)
        self.connectBtn_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.label_20 = QLabel(self.tab_2)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setGeometry(QRect(40, 30, 151, 81))
        self.label_20.setPixmap(QPixmap(u":/etc/ca_410.png"))
        self.label_20.setScaledContents(True)
        self.disconnectBtn_2 = QPushButton(self.tab_2)
        self.disconnectBtn_2.setObjectName(u"disconnectBtn_2")
        self.disconnectBtn_2.setGeometry(QRect(217, 70, 101, 31))
        self.disconnectBtn_2.setFont(font6)
        self.disconnectBtn_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.tabWidget.addTab(self.tab_2, "")
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.ca310connBtn = QPushButton(self.tab)
        self.ca310connBtn.setObjectName(u"ca310connBtn")
        self.ca310connBtn.setGeometry(QRect(217, 30, 101, 31))
        self.ca310connBtn.setFont(font6)
        self.ca310connBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.ca310discBtn = QPushButton(self.tab)
        self.ca310discBtn.setObjectName(u"ca310discBtn")
        self.ca310discBtn.setGeometry(QRect(217, 70, 101, 31))
        self.ca310discBtn.setFont(font6)
        self.ca310discBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.label_8 = QLabel(self.tab)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(40, 20, 151, 81))
        self.label_8.setPixmap(QPixmap(u":/etc/ca_310.PNG"))
        self.label_8.setScaledContents(True)
        self.tabWidget.addTab(self.tab, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.connectBtn_3 = QPushButton(self.tab_3)
        self.connectBtn_3.setObjectName(u"connectBtn_3")
        self.connectBtn_3.setGeometry(QRect(217, 30, 101, 31))
        self.connectBtn_3.setFont(font6)
        self.connectBtn_3.setCursor(QCursor(Qt.PointingHandCursor))
        self.label_21 = QLabel(self.tab_3)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setGeometry(QRect(40, 20, 151, 81))
        self.label_21.setPixmap(QPixmap(u":/etc/CMH.png"))
        self.label_21.setScaledContents(True)
        self.disconnectBtn_3 = QPushButton(self.tab_3)
        self.disconnectBtn_3.setObjectName(u"disconnectBtn_3")
        self.disconnectBtn_3.setGeometry(QRect(217, 70, 101, 31))
        self.disconnectBtn_3.setFont(font6)
        self.disconnectBtn_3.setCursor(QCursor(Qt.PointingHandCursor))
        self.tabWidget.addTab(self.tab_3, "")
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.connectBtn_4 = QPushButton(self.tab_4)
        self.connectBtn_4.setObjectName(u"connectBtn_4")
        self.connectBtn_4.setGeometry(QRect(217, 30, 101, 31))
        self.connectBtn_4.setFont(font6)
        self.connectBtn_4.setCursor(QCursor(Qt.PointingHandCursor))
        self.disconnectBtn_4 = QPushButton(self.tab_4)
        self.disconnectBtn_4.setObjectName(u"disconnectBtn_4")
        self.disconnectBtn_4.setGeometry(QRect(217, 70, 101, 31))
        self.disconnectBtn_4.setFont(font6)
        self.disconnectBtn_4.setCursor(QCursor(Qt.PointingHandCursor))
        self.label_22 = QLabel(self.tab_4)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setGeometry(QRect(70, 30, 111, 71))
        self.label_22.setPixmap(QPixmap(u":/etc/cs2000.png"))
        self.label_22.setScaledContents(True)
        self.tabWidget.addTab(self.tab_4, "")
        self.tab_5 = QWidget()
        self.tab_5.setObjectName(u"tab_5")
        self.disconnectBtn_5 = QPushButton(self.tab_5)
        self.disconnectBtn_5.setObjectName(u"disconnectBtn_5")
        self.disconnectBtn_5.setGeometry(QRect(217, 70, 101, 31))
        self.disconnectBtn_5.setFont(font6)
        self.connectBtn_5 = QPushButton(self.tab_5)
        self.connectBtn_5.setObjectName(u"connectBtn_5")
        self.connectBtn_5.setGeometry(QRect(217, 30, 101, 31))
        self.connectBtn_5.setFont(font6)
        self.tabWidget.addTab(self.tab_5, "")
        self.label_17 = QLabel(self.widget_4)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setGeometry(QRect(23, 2, 371, 36))
        sizePolicy.setHeightForWidth(self.label_17.sizePolicy().hasHeightForWidth())
        self.label_17.setSizePolicy(sizePolicy)
        self.label_17.setFont(font3)
        self.widget_6 = QWidget(self.widget_3)
        self.widget_6.setObjectName(u"widget_6")
        self.widget_6.setGeometry(QRect(2, 378, 381, 471))
        sizePolicy.setHeightForWidth(self.widget_6.sizePolicy().hasHeightForWidth())
        self.widget_6.setSizePolicy(sizePolicy)
        self.label_27 = QLabel(self.widget_6)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setGeometry(QRect(23, 3, 371, 36))
        sizePolicy.setHeightForWidth(self.label_27.sizePolicy().hasHeightForWidth())
        self.label_27.setSizePolicy(sizePolicy)
        self.label_27.setFont(font3)
        self.resolutioncombo = QComboBox(self.widget_6)
        self.resolutioncombo.addItem("")
        self.resolutioncombo.addItem("")
        self.resolutioncombo.addItem("")
        self.resolutioncombo.setObjectName(u"resolutioncombo")
        self.resolutioncombo.setGeometry(QRect(40, 50, 131, 31))
        sizePolicy.setHeightForWidth(self.resolutioncombo.sizePolicy().hasHeightForWidth())
        self.resolutioncombo.setSizePolicy(sizePolicy)
        self.resolutioncombo.setMinimumSize(QSize(0, 0))
        font7 = QFont()
        font7.setFamily(u"Segoe UI")
        font7.setPointSize(10)
        font7.setBold(True)
        font7.setWeight(75)
        self.resolutioncombo.setFont(font7)
        self.resolutioncombo.setEditable(True)
        self.showwindowBtn = QPushButton(self.widget_6)
        self.showwindowBtn.setObjectName(u"showwindowBtn")
        self.showwindowBtn.setGeometry(QRect(240, 50, 111, 31))
        self.showwindowBtn.setFont(font5)
        self.showwindowBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.frame_6 = QFrame(self.widget_6)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setGeometry(QRect(21, 193, 341, 121))
        self.frame_6.setFrameShape(QFrame.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Raised)
        self.label_28 = QLabel(self.frame_6)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(10, -4, 71, 36))
        sizePolicy.setHeightForWidth(self.label_28.sizePolicy().hasHeightForWidth())
        self.label_28.setSizePolicy(sizePolicy)
        self.label_28.setFont(font)
        self.label_28.setTextFormat(Qt.AutoText)
        self.ptnchangeBtn = QPushButton(self.frame_6)
        self.ptnchangeBtn.setObjectName(u"ptnchangeBtn")
        self.ptnchangeBtn.setGeometry(QRect(267, 80, 51, 31))
        self.ptnchangeBtn.setFont(font6)
        self.ptnchangeBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.layoutWidget_4 = QWidget(self.frame_6)
        self.layoutWidget_4.setObjectName(u"layoutWidget_4")
        self.layoutWidget_4.setGeometry(QRect(15, 27, 311, 38))
        self.horizontalLayout_9 = QHBoxLayout(self.layoutWidget_4)
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(1, 0, 0, 0)
        self.win_all = QPushButton(self.layoutWidget_4)
        self.win_all.setObjectName(u"win_all")
        self.win_all.setEnabled(True)
        sizePolicy3 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.win_all.sizePolicy().hasHeightForWidth())
        self.win_all.setSizePolicy(sizePolicy3)
        self.win_all.setMinimumSize(QSize(34, 30))
        self.win_all.setMaximumSize(QSize(16777215, 16777215))
        self.win_all.setBaseSize(QSize(0, 0))
        font8 = QFont()
        font8.setFamily(u"Segoe UI")
        font8.setPointSize(8)
        font8.setBold(True)
        font8.setWeight(75)
        self.win_all.setFont(font8)
        self.win_all.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_all.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_all)

        self.win_red = QPushButton(self.layoutWidget_4)
        self.win_red.setObjectName(u"win_red")
        self.win_red.setMinimumSize(QSize(34, 30))
        self.win_red.setBaseSize(QSize(0, 0))
        self.win_red.setFont(font8)
        self.win_red.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_red.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_red)

        self.win_green = QPushButton(self.layoutWidget_4)
        self.win_green.setObjectName(u"win_green")
        self.win_green.setMinimumSize(QSize(34, 30))
        self.win_green.setBaseSize(QSize(0, 0))
        self.win_green.setFont(font8)
        self.win_green.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_green.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_green)

        self.win_blue = QPushButton(self.layoutWidget_4)
        self.win_blue.setObjectName(u"win_blue")
        self.win_blue.setMinimumSize(QSize(34, 30))
        self.win_blue.setBaseSize(QSize(0, 0))
        self.win_blue.setFont(font8)
        self.win_blue.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_blue.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_blue)

        self.win_cyan = QPushButton(self.layoutWidget_4)
        self.win_cyan.setObjectName(u"win_cyan")
        self.win_cyan.setMinimumSize(QSize(34, 30))
        self.win_cyan.setBaseSize(QSize(0, 0))
        self.win_cyan.setFont(font8)
        self.win_cyan.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_cyan.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_cyan)

        self.win_magen = QPushButton(self.layoutWidget_4)
        self.win_magen.setObjectName(u"win_magen")
        self.win_magen.setMinimumSize(QSize(34, 30))
        self.win_magen.setBaseSize(QSize(0, 0))
        self.win_magen.setFont(font8)
        self.win_magen.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_magen.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_magen)

        self.win_yellow = QPushButton(self.layoutWidget_4)
        self.win_yellow.setObjectName(u"win_yellow")
        self.win_yellow.setMinimumSize(QSize(34, 30))
        self.win_yellow.setBaseSize(QSize(0, 0))
        self.win_yellow.setFont(font8)
        self.win_yellow.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_yellow.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_yellow)

        self.win_white = QPushButton(self.layoutWidget_4)
        self.win_white.setObjectName(u"win_white")
        self.win_white.setMinimumSize(QSize(34, 30))
        self.win_white.setBaseSize(QSize(0, 0))
        self.win_white.setFont(font8)
        self.win_white.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_white.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_white)

        self.win_black = QPushButton(self.layoutWidget_4)
        self.win_black.setObjectName(u"win_black")
        self.win_black.setMinimumSize(QSize(34, 30))
        self.win_black.setBaseSize(QSize(0, 0))
        self.win_black.setFont(font8)
        self.win_black.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_black.setAutoDefault(False)

        self.horizontalLayout_9.addWidget(self.win_black)

        self.layoutWidget_5 = QWidget(self.frame_6)
        self.layoutWidget_5.setObjectName(u"layoutWidget_5")
        self.layoutWidget_5.setGeometry(QRect(20, 80, 248, 46))
        self.horizontalLayout_10 = QHBoxLayout(self.layoutWidget_5)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(5, 5, 5, 5)
        self.lineEdit_3 = QLineEdit(self.layoutWidget_5)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_3.setFont(font8)

        self.horizontalLayout_10.addWidget(self.lineEdit_3)

        self.lineEdit_4 = QLineEdit(self.layoutWidget_5)
        self.lineEdit_4.setObjectName(u"lineEdit_4")
        self.lineEdit_4.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_4.setFont(font8)

        self.horizontalLayout_10.addWidget(self.lineEdit_4)

        self.lineEdit_5 = QLineEdit(self.layoutWidget_5)
        self.lineEdit_5.setObjectName(u"lineEdit_5")
        self.lineEdit_5.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_5.setFont(font8)

        self.horizontalLayout_10.addWidget(self.lineEdit_5)

        self.sizeEdit = QLineEdit(self.layoutWidget_5)
        self.sizeEdit.setObjectName(u"sizeEdit")
        self.sizeEdit.setMaximumSize(QSize(16777215, 20))
        self.sizeEdit.setFont(font8)
        self.sizeEdit.setAutoFillBackground(False)
        self.sizeEdit.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.sizeEdit.setClearButtonEnabled(False)

        self.horizontalLayout_10.addWidget(self.sizeEdit)

        self.layoutWidget_6 = QWidget(self.frame_6)
        self.layoutWidget_6.setObjectName(u"layoutWidget_6")
        self.layoutWidget_6.setGeometry(QRect(20, 64, 231, 22))
        self.horizontalLayout_11 = QHBoxLayout(self.layoutWidget_6)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.redlabel = QLabel(self.layoutWidget_6)
        self.redlabel.setObjectName(u"redlabel")
        sizePolicy.setHeightForWidth(self.redlabel.sizePolicy().hasHeightForWidth())
        self.redlabel.setSizePolicy(sizePolicy)
        self.redlabel.setMinimumSize(QSize(0, 0))
        font9 = QFont()
        font9.setFamily(u"Segoe UI")
        font9.setPointSize(9)
        font9.setBold(True)
        font9.setUnderline(False)
        font9.setWeight(75)
        self.redlabel.setFont(font9)
        self.redlabel.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_11.addWidget(self.redlabel)

        self.greenlabel = QLabel(self.layoutWidget_6)
        self.greenlabel.setObjectName(u"greenlabel")
        sizePolicy.setHeightForWidth(self.greenlabel.sizePolicy().hasHeightForWidth())
        self.greenlabel.setSizePolicy(sizePolicy)
        self.greenlabel.setMinimumSize(QSize(0, 0))
        self.greenlabel.setFont(font9)
        self.greenlabel.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_11.addWidget(self.greenlabel)

        self.bluelabel = QLabel(self.layoutWidget_6)
        self.bluelabel.setObjectName(u"bluelabel")
        sizePolicy.setHeightForWidth(self.bluelabel.sizePolicy().hasHeightForWidth())
        self.bluelabel.setSizePolicy(sizePolicy)
        self.bluelabel.setMinimumSize(QSize(0, 0))
        self.bluelabel.setFont(font9)
        self.bluelabel.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_11.addWidget(self.bluelabel)

        self.sizelabel = QLabel(self.layoutWidget_6)
        self.sizelabel.setObjectName(u"sizelabel")
        sizePolicy.setHeightForWidth(self.sizelabel.sizePolicy().hasHeightForWidth())
        self.sizelabel.setSizePolicy(sizePolicy)
        self.sizelabel.setMinimumSize(QSize(0, 0))
        self.sizelabel.setFont(font9)
        self.sizelabel.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_11.addWidget(self.sizelabel)

        self.frame_7 = QFrame(self.widget_6)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setGeometry(QRect(20, 331, 341, 121))
        self.frame_7.setFrameShape(QFrame.StyledPanel)
        self.frame_7.setFrameShadow(QFrame.Raised)
        self.label_29 = QLabel(self.frame_7)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setGeometry(QRect(10, -4, 91, 36))
        sizePolicy.setHeightForWidth(self.label_29.sizePolicy().hasHeightForWidth())
        self.label_29.setSizePolicy(sizePolicy)
        self.label_29.setFont(font)
        self.label_29.setTextFormat(Qt.AutoText)
        self.layoutWidget_7 = QWidget(self.frame_7)
        self.layoutWidget_7.setObjectName(u"layoutWidget_7")
        self.layoutWidget_7.setGeometry(QRect(15, 27, 311, 38))
        self.horizontalLayout_12 = QHBoxLayout(self.layoutWidget_7)
        self.horizontalLayout_12.setSpacing(0)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(1, 0, 0, 0)
        self.win_all_2 = QPushButton(self.layoutWidget_7)
        self.win_all_2.setObjectName(u"win_all_2")
        self.win_all_2.setEnabled(True)
        sizePolicy3.setHeightForWidth(self.win_all_2.sizePolicy().hasHeightForWidth())
        self.win_all_2.setSizePolicy(sizePolicy3)
        self.win_all_2.setMinimumSize(QSize(34, 30))
        self.win_all_2.setMaximumSize(QSize(16777215, 16777215))
        self.win_all_2.setBaseSize(QSize(0, 0))
        self.win_all_2.setFont(font8)
        self.win_all_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_all_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_all_2)

        self.win_red_2 = QPushButton(self.layoutWidget_7)
        self.win_red_2.setObjectName(u"win_red_2")
        self.win_red_2.setMinimumSize(QSize(34, 30))
        self.win_red_2.setBaseSize(QSize(0, 0))
        self.win_red_2.setFont(font8)
        self.win_red_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_red_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_red_2)

        self.win_green_2 = QPushButton(self.layoutWidget_7)
        self.win_green_2.setObjectName(u"win_green_2")
        self.win_green_2.setMinimumSize(QSize(34, 30))
        self.win_green_2.setBaseSize(QSize(0, 0))
        self.win_green_2.setFont(font8)
        self.win_green_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_green_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_green_2)

        self.win_blue_2 = QPushButton(self.layoutWidget_7)
        self.win_blue_2.setObjectName(u"win_blue_2")
        self.win_blue_2.setMinimumSize(QSize(34, 30))
        self.win_blue_2.setBaseSize(QSize(0, 0))
        self.win_blue_2.setFont(font8)
        self.win_blue_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_blue_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_blue_2)

        self.win_cyan_2 = QPushButton(self.layoutWidget_7)
        self.win_cyan_2.setObjectName(u"win_cyan_2")
        self.win_cyan_2.setMinimumSize(QSize(34, 30))
        self.win_cyan_2.setBaseSize(QSize(0, 0))
        self.win_cyan_2.setFont(font8)
        self.win_cyan_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_cyan_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_cyan_2)

        self.win_magen_2 = QPushButton(self.layoutWidget_7)
        self.win_magen_2.setObjectName(u"win_magen_2")
        self.win_magen_2.setMinimumSize(QSize(34, 30))
        self.win_magen_2.setBaseSize(QSize(0, 0))
        self.win_magen_2.setFont(font8)
        self.win_magen_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_magen_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_magen_2)

        self.win_yellow_2 = QPushButton(self.layoutWidget_7)
        self.win_yellow_2.setObjectName(u"win_yellow_2")
        self.win_yellow_2.setMinimumSize(QSize(34, 30))
        self.win_yellow_2.setBaseSize(QSize(0, 0))
        self.win_yellow_2.setFont(font8)
        self.win_yellow_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_yellow_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_yellow_2)

        self.win_white_2 = QPushButton(self.layoutWidget_7)
        self.win_white_2.setObjectName(u"win_white_2")
        self.win_white_2.setMinimumSize(QSize(34, 30))
        self.win_white_2.setBaseSize(QSize(0, 0))
        self.win_white_2.setFont(font8)
        self.win_white_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_white_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_white_2)

        self.win_black_2 = QPushButton(self.layoutWidget_7)
        self.win_black_2.setObjectName(u"win_black_2")
        self.win_black_2.setMinimumSize(QSize(34, 30))
        self.win_black_2.setBaseSize(QSize(0, 0))
        self.win_black_2.setFont(font8)
        self.win_black_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.win_black_2.setAutoDefault(False)

        self.horizontalLayout_12.addWidget(self.win_black_2)

        self.layoutWidget_8 = QWidget(self.frame_7)
        self.layoutWidget_8.setObjectName(u"layoutWidget_8")
        self.layoutWidget_8.setGeometry(QRect(20, 80, 181, 46))
        self.horizontalLayout_13 = QHBoxLayout(self.layoutWidget_8)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.horizontalLayout_13.setContentsMargins(0, 5, 0, 5)
        self.lineEdit_7 = QLineEdit(self.layoutWidget_8)
        self.lineEdit_7.setObjectName(u"lineEdit_7")
        self.lineEdit_7.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_7.setFont(font8)

        self.horizontalLayout_13.addWidget(self.lineEdit_7)

        self.lineEdit_8 = QLineEdit(self.layoutWidget_8)
        self.lineEdit_8.setObjectName(u"lineEdit_8")
        self.lineEdit_8.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_8.setFont(font8)

        self.horizontalLayout_13.addWidget(self.lineEdit_8)

        self.lineEdit_9 = QLineEdit(self.layoutWidget_8)
        self.lineEdit_9.setObjectName(u"lineEdit_9")
        self.lineEdit_9.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_9.setFont(font8)

        self.horizontalLayout_13.addWidget(self.lineEdit_9)

        self.layoutWidget_9 = QWidget(self.frame_7)
        self.layoutWidget_9.setObjectName(u"layoutWidget_9")
        self.layoutWidget_9.setGeometry(QRect(20, 64, 181, 22))
        self.horizontalLayout_14 = QHBoxLayout(self.layoutWidget_9)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.horizontalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.redlabel_2 = QLabel(self.layoutWidget_9)
        self.redlabel_2.setObjectName(u"redlabel_2")
        sizePolicy.setHeightForWidth(self.redlabel_2.sizePolicy().hasHeightForWidth())
        self.redlabel_2.setSizePolicy(sizePolicy)
        self.redlabel_2.setMinimumSize(QSize(0, 0))
        self.redlabel_2.setFont(font9)
        self.redlabel_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_14.addWidget(self.redlabel_2)

        self.greenlabel_2 = QLabel(self.layoutWidget_9)
        self.greenlabel_2.setObjectName(u"greenlabel_2")
        sizePolicy.setHeightForWidth(self.greenlabel_2.sizePolicy().hasHeightForWidth())
        self.greenlabel_2.setSizePolicy(sizePolicy)
        self.greenlabel_2.setMinimumSize(QSize(0, 0))
        self.greenlabel_2.setFont(font9)
        self.greenlabel_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_14.addWidget(self.greenlabel_2)

        self.bluelabel_2 = QLabel(self.layoutWidget_9)
        self.bluelabel_2.setObjectName(u"bluelabel_2")
        sizePolicy.setHeightForWidth(self.bluelabel_2.sizePolicy().hasHeightForWidth())
        self.bluelabel_2.setSizePolicy(sizePolicy)
        self.bluelabel_2.setMinimumSize(QSize(0, 0))
        self.bluelabel_2.setFont(font9)
        self.bluelabel_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_14.addWidget(self.bluelabel_2)

        self.ptnchangeBtn_2 = QPushButton(self.frame_7)
        self.ptnchangeBtn_2.setObjectName(u"ptnchangeBtn_2")
        self.ptnchangeBtn_2.setGeometry(QRect(270, 80, 51, 31))
        self.ptnchangeBtn_2.setFont(font6)
        self.ptnchangeBtn_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.tvbox = QLabel(self.widget_6)
        self.tvbox.setObjectName(u"tvbox")
        self.tvbox.setGeometry(QRect(30, 101, 91, 91))
        self.tvbox.setPixmap(QPixmap(u":/etc/iconTV.png"))
        self.tvbox.setScaledContents(True)
        self.tvbox_2 = QLabel(self.widget_6)
        self.tvbox_2.setObjectName(u"tvbox_2")
        self.tvbox_2.setGeometry(QRect(150, 100, 91, 91))
        self.tvbox_2.setPixmap(QPixmap(u":/etc/iconTV.png"))
        self.tvbox_2.setScaledContents(True)
        self.backcolor = QLabel(self.widget_6)
        self.backcolor.setObjectName(u"backcolor")
        self.backcolor.setGeometry(QRect(155, 117, 81, 50))
        self.wincolor = QLabel(self.widget_6)
        self.wincolor.setObjectName(u"wincolor")
        self.wincolor.setGeometry(QRect(58, 134, 0, 0))
        self.label_30 = QLabel(self.widget_6)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setGeometry(QRect(40, 84, 71, 36))
        sizePolicy.setHeightForWidth(self.label_30.sizePolicy().hasHeightForWidth())
        self.label_30.setSizePolicy(sizePolicy)
        font10 = QFont()
        font10.setFamily(u"Segoe UI")
        font10.setPointSize(10)
        font10.setBold(False)
        font10.setUnderline(True)
        font10.setWeight(50)
        self.label_30.setFont(font10)
        self.label_30.setTextFormat(Qt.AutoText)
        self.label_31 = QLabel(self.widget_6)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setGeometry(QRect(150, 84, 91, 36))
        sizePolicy.setHeightForWidth(self.label_31.sizePolicy().hasHeightForWidth())
        self.label_31.setSizePolicy(sizePolicy)
        self.label_31.setFont(font10)
        self.label_31.setTextFormat(Qt.AutoText)
        self.tvbox_3 = QLabel(self.widget_6)
        self.tvbox_3.setObjectName(u"tvbox_3")
        self.tvbox_3.setGeometry(QRect(270, 99, 91, 91))
        self.tvbox_3.setPixmap(QPixmap(u":/etc/iconTV.png"))
        self.tvbox_3.setScaledContents(True)
        self.result = QLabel(self.widget_6)
        self.result.setObjectName(u"result")
        self.result.setGeometry(QRect(270, 83, 91, 36))
        sizePolicy.setHeightForWidth(self.result.sizePolicy().hasHeightForWidth())
        self.result.setSizePolicy(sizePolicy)
        self.result.setFont(font)
        self.result.setTextFormat(Qt.AutoText)
        self.totalbackcolor = QLabel(self.widget_6)
        self.totalbackcolor.setObjectName(u"totalbackcolor")
        self.totalbackcolor.setGeometry(QRect(275, 116, 81, 50))
        self.totalwincolor = QLabel(self.widget_6)
        self.totalwincolor.setObjectName(u"totalwincolor")
        self.totalwincolor.setGeometry(QRect(298, 131, 0, 0))
        self.tvbox.raise_()
        self.label_27.raise_()
        self.resolutioncombo.raise_()
        self.showwindowBtn.raise_()
        self.frame_6.raise_()
        self.frame_7.raise_()
        self.tvbox_2.raise_()
        self.backcolor.raise_()
        self.label_30.raise_()
        self.label_31.raise_()
        self.tvbox_3.raise_()
        self.result.raise_()
        self.totalbackcolor.raise_()
        self.totalwincolor.raise_()
        self.wincolor.raise_()
        self.pqmeasure = QWidget(self.widget_3)
        self.pqmeasure.setObjectName(u"pqmeasure")
        self.pqmeasure.setGeometry(QRect(398, 157, 611, 521))
        sizePolicy.setHeightForWidth(self.pqmeasure.sizePolicy().hasHeightForWidth())
        self.pqmeasure.setSizePolicy(sizePolicy)
        self.label_32 = QLabel(self.pqmeasure)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setGeometry(QRect(23, 3, 271, 36))
        sizePolicy.setHeightForWidth(self.label_32.sizePolicy().hasHeightForWidth())
        self.label_32.setSizePolicy(sizePolicy)
        self.label_32.setFont(font3)
        self.ammeasurepage = QCustomStackedWidget(self.pqmeasure)
        self.ammeasurepage.setObjectName(u"ammeasurepage")
        self.ammeasurepage.setEnabled(True)
        self.ammeasurepage.setGeometry(QRect(20, 83, 571, 431))
        self.ammeasurepage.setCursor(QCursor(Qt.PointingHandCursor))
        self.ammeasurepage.setMouseTracking(True)
        self.autopage = QWidget()
        self.autopage.setObjectName(u"autopage")
        self.allMeasureBtn = QPushButton(self.autopage)
        self.allMeasureBtn.setObjectName(u"allMeasureBtn")
        self.allMeasureBtn.setGeometry(QRect(100, 15, 191, 31))
        self.allMeasureBtn.setFont(font6)
        self.allMeasureBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.allStopBtn = QPushButton(self.autopage)
        self.allStopBtn.setObjectName(u"allStopBtn")
        self.allStopBtn.setGeometry(QRect(310, 15, 121, 31))
        self.allStopBtn.setFont(font6)
        self.allStopBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.frame_5 = QFrame(self.autopage)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setGeometry(QRect(24, 59, 521, 311))
        self.frame_5.setFrameShape(QFrame.StyledPanel)
        self.frame_5.setFrameShadow(QFrame.Raised)
        self.layoutWidget_10 = QWidget(self.frame_5)
        self.layoutWidget_10.setObjectName(u"layoutWidget_10")
        self.layoutWidget_10.setGeometry(QRect(20, 6, 209, 301))
        self.verticalLayout_8 = QVBoxLayout(self.layoutWidget_10)
        self.verticalLayout_8.setSpacing(6)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.checkBox_cr = QCheckBox(self.layoutWidget_10)
        self.checkBox_cr.setObjectName(u"checkBox_cr")
        sizePolicy4 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.checkBox_cr.sizePolicy().hasHeightForWidth())
        self.checkBox_cr.setSizePolicy(sizePolicy4)
        font11 = QFont()
        font11.setFamily(u"Arial Narrow")
        font11.setPointSize(12)
        font11.setBold(True)
        font11.setUnderline(True)
        font11.setWeight(75)
        self.checkBox_cr.setFont(font11)
        self.checkBox_cr.setCursor(QCursor(Qt.PointingHandCursor))
        self.checkBox_cr.setMouseTracking(False)
        self.checkBox_cr.setAcceptDrops(False)
        self.checkBox_cr.setAutoFillBackground(False)
        icon1 = QIcon()
        icon1.addFile(u":/etc/contrast_ratio.png", QSize(), QIcon.Normal, QIcon.Off)
        self.checkBox_cr.setIcon(icon1)
        self.checkBox_cr.setIconSize(QSize(55, 55))
        self.checkBox_cr.setChecked(True)

        self.verticalLayout_8.addWidget(self.checkBox_cr)

        self.checkBox_gamut = QCheckBox(self.layoutWidget_10)
        self.checkBox_gamut.setObjectName(u"checkBox_gamut")
        sizePolicy4.setHeightForWidth(self.checkBox_gamut.sizePolicy().hasHeightForWidth())
        self.checkBox_gamut.setSizePolicy(sizePolicy4)
        self.checkBox_gamut.setFont(font11)
        self.checkBox_gamut.setCursor(QCursor(Qt.PointingHandCursor))
        self.checkBox_gamut.setMouseTracking(False)
        self.checkBox_gamut.setAutoFillBackground(False)
        icon2 = QIcon()
        icon2.addFile(u":/etc/gamut.png", QSize(), QIcon.Normal, QIcon.Off)
        self.checkBox_gamut.setIcon(icon2)
        self.checkBox_gamut.setIconSize(QSize(55, 55))
        self.checkBox_gamut.setChecked(True)

        self.verticalLayout_8.addWidget(self.checkBox_gamut)

        self.checkBox_gamma = QCheckBox(self.layoutWidget_10)
        self.checkBox_gamma.setObjectName(u"checkBox_gamma")
        self.checkBox_gamma.setFont(font11)
        self.checkBox_gamma.setCursor(QCursor(Qt.PointingHandCursor))
        self.checkBox_gamma.setMouseTracking(False)
        self.checkBox_gamma.setAutoFillBackground(False)
        icon3 = QIcon()
        icon3.addFile(u":/etc/gamma.png", QSize(), QIcon.Normal, QIcon.Off)
        self.checkBox_gamma.setIcon(icon3)
        self.checkBox_gamma.setIconSize(QSize(55, 55))
        self.checkBox_gamma.setChecked(True)

        self.verticalLayout_8.addWidget(self.checkBox_gamma)

        self.checkBox_calman = QCheckBox(self.layoutWidget_10)
        self.checkBox_calman.setObjectName(u"checkBox_calman")
        self.checkBox_calman.setFont(font11)
        self.checkBox_calman.setCursor(QCursor(Qt.PointingHandCursor))
        self.checkBox_calman.setMouseTracking(False)
#if QT_CONFIG(statustip)
        self.checkBox_calman.setStatusTip(u"")
#endif // QT_CONFIG(statustip)
        self.checkBox_calman.setAutoFillBackground(False)
        icon4 = QIcon()
        icon4.addFile(u":/etc/calman.png", QSize(), QIcon.Normal, QIcon.Off)
        self.checkBox_calman.setIcon(icon4)
        self.checkBox_calman.setIconSize(QSize(50, 50))
        self.checkBox_calman.setChecked(True)
        self.checkBox_calman.setTristate(False)

        self.verticalLayout_8.addWidget(self.checkBox_calman)

        self.checkBox_apl = QCheckBox(self.layoutWidget_10)
        self.checkBox_apl.setObjectName(u"checkBox_apl")
        sizePolicy4.setHeightForWidth(self.checkBox_apl.sizePolicy().hasHeightForWidth())
        self.checkBox_apl.setSizePolicy(sizePolicy4)
        self.checkBox_apl.setFont(font11)
        self.checkBox_apl.setCursor(QCursor(Qt.PointingHandCursor))
        self.checkBox_apl.setMouseTracking(False)
        self.checkBox_apl.setAutoFillBackground(False)
        icon5 = QIcon()
        icon5.addFile(u":/etc/APL.png", QSize(), QIcon.Normal, QIcon.Off)
        self.checkBox_apl.setIcon(icon5)
        self.checkBox_apl.setIconSize(QSize(60, 60))
        self.checkBox_apl.setChecked(True)
        self.checkBox_apl.setTristate(False)

        self.verticalLayout_8.addWidget(self.checkBox_apl)

        self.label_25 = QLabel(self.frame_5)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setGeometry(QRect(209, 76, 301, 41))
        font12 = QFont()
        font12.setFamily(u"Arial Narrow")
        font12.setPointSize(10)
        font12.setBold(False)
        font12.setItalic(True)
        font12.setWeight(50)
        self.label_25.setFont(font12)
        self.label_35 = QLabel(self.frame_5)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setGeometry(QRect(209, 255, 301, 41))
        self.label_35.setFont(font12)
        self.label_34 = QLabel(self.frame_5)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setGeometry(QRect(209, 196, 291, 41))
        self.label_34.setFont(font12)
        self.label_24 = QLabel(self.frame_5)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setGeometry(QRect(209, 15, 301, 41))
        self.label_24.setFont(font12)
        self.label_26 = QLabel(self.frame_5)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setGeometry(QRect(208, 136, 311, 41))
        self.label_26.setFont(font12)
        self.uploadBtn = QPushButton(self.autopage)
        self.uploadBtn.setObjectName(u"uploadBtn")
        self.uploadBtn.setGeometry(QRect(88, 381, 371, 41))
        self.uploadBtn.setFont(font5)
        self.uploadBtn.setCursor(QCursor(Qt.PointingHandCursor))
        icon6 = QIcon()
        icon6.addFile(u":/icons/Icons/arrow-up-circle.png", QSize(), QIcon.Normal, QIcon.Off)
        self.uploadBtn.setIcon(icon6)
        self.uploadBtn.setIconSize(QSize(30, 30))
        self.ammeasurepage.addWidget(self.autopage)
        self.frame_5.raise_()
        self.allMeasureBtn.raise_()
        self.allStopBtn.raise_()
        self.uploadBtn.raise_()
        self.manpage = QWidget()
        self.manpage.setObjectName(u"manpage")
        self.tabWidget_2 = QTabWidget(self.manpage)
        self.tabWidget_2.setObjectName(u"tabWidget_2")
        self.tabWidget_2.setGeometry(QRect(14, 10, 541, 411))
        self.tabWidget_2.setFont(font5)
        self.tabWidget_2.setFocusPolicy(Qt.StrongFocus)
        self.tabWidget_2.setTabShape(QTabWidget.Triangular)
        self.tabWidget_2.setElideMode(Qt.ElideNone)
        self.tabWidget_2.setDocumentMode(True)
        self.tabWidget_2.setTabsClosable(False)
        self.tabWidget_2.setMovable(False)
        self.tabWidget_2.setTabBarAutoHide(False)
        self.basic = QWidget()
        self.basic.setObjectName(u"basic")
        self.label_23 = QLabel(self.basic)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setGeometry(QRect(60, 20, 91, 81))
        self.label_23.setPixmap(QPixmap(u":/etc/contrast_ratio.png"))
        self.label_23.setScaledContents(True)
        self.label_37 = QLabel(self.basic)
        self.label_37.setObjectName(u"label_37")
        self.label_37.setGeometry(QRect(160, 23, 301, 61))
        self.label_37.setFont(font12)
        self.label_38 = QLabel(self.basic)
        self.label_38.setObjectName(u"label_38")
        self.label_38.setGeometry(QRect(160, 0, 141, 61))
        font13 = QFont()
        font13.setFamily(u"Segoe UI")
        font13.setPointSize(12)
        font13.setBold(True)
        font13.setItalic(False)
        font13.setUnderline(True)
        font13.setWeight(75)
        self.label_38.setFont(font13)
        self.meas_cr = QPushButton(self.basic)
        self.meas_cr.setObjectName(u"meas_cr")
        self.meas_cr.setGeometry(QRect(160, 70, 101, 31))
        self.meas_cr.setFont(font6)
        self.meas_cr.setCursor(QCursor(Qt.PointingHandCursor))
        self.label_39 = QLabel(self.basic)
        self.label_39.setObjectName(u"label_39")
        self.label_39.setGeometry(QRect(60, 149, 91, 81))
        self.label_39.setPixmap(QPixmap(u":/etc/gamut.png"))
        self.label_39.setScaledContents(True)
        self.meas_gamut = QPushButton(self.basic)
        self.meas_gamut.setObjectName(u"meas_gamut")
        self.meas_gamut.setGeometry(QRect(161, 200, 101, 31))
        self.meas_gamut.setFont(font6)
        self.meas_gamut.setCursor(QCursor(Qt.PointingHandCursor))
        self.label_40 = QLabel(self.basic)
        self.label_40.setObjectName(u"label_40")
        self.label_40.setGeometry(QRect(161, 129, 81, 61))
        self.label_40.setFont(font13)
        self.label_41 = QLabel(self.basic)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setGeometry(QRect(161, 154, 301, 61))
        self.label_41.setFont(font12)
        self.label_42 = QLabel(self.basic)
        self.label_42.setObjectName(u"label_42")
        self.label_42.setGeometry(QRect(161, 259, 121, 61))
        self.label_42.setFont(font13)
        self.label_43 = QLabel(self.basic)
        self.label_43.setObjectName(u"label_43")
        self.label_43.setGeometry(QRect(60, 279, 91, 81))
        self.label_43.setPixmap(QPixmap(u":/etc/gamma.png"))
        self.label_43.setScaledContents(True)
        self.label_44 = QLabel(self.basic)
        self.label_44.setObjectName(u"label_44")
        self.label_44.setGeometry(QRect(161, 283, 301, 61))
        self.label_44.setFont(font12)
        self.meas_color = QPushButton(self.basic)
        self.meas_color.setObjectName(u"meas_color")
        self.meas_color.setGeometry(QRect(161, 330, 101, 31))
        self.meas_color.setFont(font6)
        self.meas_color.setCursor(QCursor(Qt.PointingHandCursor))
        self.meas_color.setStyleSheet(u"")
        self.tabWidget_2.addTab(self.basic, "")
        self.gamma = QWidget()
        self.gamma.setObjectName(u"gamma")
        self.radioButton_Gray = QRadioButton(self.gamma)
        self.radioButton_Gray.setObjectName(u"radioButton_Gray")
        self.radioButton_Gray.setGeometry(QRect(45, 15, 22, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_Gray.sizePolicy().hasHeightForWidth())
        self.radioButton_Gray.setSizePolicy(sizePolicy1)
        self.radioButton_Gray.setMaximumSize(QSize(22, 22))
        self.radioButton_Gray.setFont(font5)
        self.radioButton_Gray.setLayoutDirection(Qt.LeftToRight)
        self.radioButton_Gray.setChecked(False)
        self.radioButton_Red = QRadioButton(self.gamma)
        self.radioButton_Red.setObjectName(u"radioButton_Red")
        self.radioButton_Red.setGeometry(QRect(69, 15, 22, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_Red.sizePolicy().hasHeightForWidth())
        self.radioButton_Red.setSizePolicy(sizePolicy1)
        self.radioButton_Red.setMaximumSize(QSize(22, 22))
        self.radioButton_Red.setFont(font5)
        self.radioButton_Red.setStyleSheet(u"")
        self.radioButton_Red.setCheckable(True)
        self.radioButton_Red.setChecked(False)
        self.radioButton_Green = QRadioButton(self.gamma)
        self.radioButton_Green.setObjectName(u"radioButton_Green")
        self.radioButton_Green.setGeometry(QRect(93, 15, 22, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_Green.sizePolicy().hasHeightForWidth())
        self.radioButton_Green.setSizePolicy(sizePolicy1)
        self.radioButton_Green.setMaximumSize(QSize(22, 22))
        self.radioButton_Green.setFont(font5)
        self.radioButton_Blue = QRadioButton(self.gamma)
        self.radioButton_Blue.setObjectName(u"radioButton_Blue")
        self.radioButton_Blue.setGeometry(QRect(117, 15, 22, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_Blue.sizePolicy().hasHeightForWidth())
        self.radioButton_Blue.setSizePolicy(sizePolicy1)
        self.radioButton_Blue.setMaximumSize(QSize(22, 22))
        self.radioButton_Blue.setFont(font5)
        self.radioButton_Cyan = QRadioButton(self.gamma)
        self.radioButton_Cyan.setObjectName(u"radioButton_Cyan")
        self.radioButton_Cyan.setGeometry(QRect(141, 15, 22, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_Cyan.sizePolicy().hasHeightForWidth())
        self.radioButton_Cyan.setSizePolicy(sizePolicy1)
        self.radioButton_Cyan.setMaximumSize(QSize(22, 22))
        self.radioButton_Cyan.setFont(font5)
        self.radioButton_Cyan.setAutoFillBackground(False)
        self.radioButton_Magenta = QRadioButton(self.gamma)
        self.radioButton_Magenta.setObjectName(u"radioButton_Magenta")
        self.radioButton_Magenta.setGeometry(QRect(165, 15, 22, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_Magenta.sizePolicy().hasHeightForWidth())
        self.radioButton_Magenta.setSizePolicy(sizePolicy1)
        self.radioButton_Magenta.setMaximumSize(QSize(22, 22))
        self.radioButton_Magenta.setFont(font5)
        self.radioButton_Magenta.setAutoFillBackground(False)
        self.radioButton_Yellow = QRadioButton(self.gamma)
        self.radioButton_Yellow.setObjectName(u"radioButton_Yellow")
        self.radioButton_Yellow.setGeometry(QRect(189, 15, 22, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_Yellow.sizePolicy().hasHeightForWidth())
        self.radioButton_Yellow.setSizePolicy(sizePolicy1)
        self.radioButton_Yellow.setMaximumSize(QSize(22, 22))
        palette = QPalette()
        brush = QBrush(QColor(255, 255, 255, 255))
        brush.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Active, QPalette.WindowText, brush)
        brush1 = QBrush(QColor(255, 255, 0, 255))
        brush1.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Active, QPalette.Button, brush1)
        palette.setBrush(QPalette.Active, QPalette.Text, brush)
        palette.setBrush(QPalette.Active, QPalette.ButtonText, brush)
        palette.setBrush(QPalette.Active, QPalette.Base, brush1)
        palette.setBrush(QPalette.Active, QPalette.Window, brush1)
        palette.setBrush(QPalette.Inactive, QPalette.WindowText, brush)
        palette.setBrush(QPalette.Inactive, QPalette.Button, brush1)
        palette.setBrush(QPalette.Inactive, QPalette.Text, brush)
        palette.setBrush(QPalette.Inactive, QPalette.ButtonText, brush)
        palette.setBrush(QPalette.Inactive, QPalette.Base, brush1)
        palette.setBrush(QPalette.Inactive, QPalette.Window, brush1)
        palette.setBrush(QPalette.Disabled, QPalette.WindowText, brush)
        palette.setBrush(QPalette.Disabled, QPalette.Button, brush1)
        palette.setBrush(QPalette.Disabled, QPalette.Text, brush)
        palette.setBrush(QPalette.Disabled, QPalette.ButtonText, brush)
        palette.setBrush(QPalette.Disabled, QPalette.Base, brush1)
        palette.setBrush(QPalette.Disabled, QPalette.Window, brush1)
        self.radioButton_Yellow.setPalette(palette)
        font14 = QFont()
        font14.setFamily(u"Segoe UI")
        font14.setPointSize(9)
        font14.setBold(False)
        font14.setWeight(50)
        self.radioButton_Yellow.setFont(font14)
        self.radioButton_Yellow.setAutoFillBackground(False)
        self.radioButton_All = QRadioButton(self.gamma)
        self.radioButton_All.setObjectName(u"radioButton_All")
        self.radioButton_All.setGeometry(QRect(1, 15, 41, 20))
        sizePolicy1.setHeightForWidth(self.radioButton_All.sizePolicy().hasHeightForWidth())
        self.radioButton_All.setSizePolicy(sizePolicy1)
        self.radioButton_All.setFont(font5)
        self.radioButton_All.setFocusPolicy(Qt.StrongFocus)
        self.radioButton_All.setLayoutDirection(Qt.LeftToRight)
        self.radioButton_All.setCheckable(True)
        self.radioButton_All.setChecked(True)
        self.layoutWidget_13 = QWidget(self.gamma)
        self.layoutWidget_13.setObjectName(u"layoutWidget_13")
        self.layoutWidget_13.setGeometry(QRect(30, 83, 461, 31))
        self.horizontalLayout_2 = QHBoxLayout(self.layoutWidget_13)
        self.horizontalLayout_2.setSpacing(1)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gray_136 = QPushButton(self.layoutWidget_13)
        self.gray_136.setObjectName(u"gray_136")
        sizePolicy.setHeightForWidth(self.gray_136.sizePolicy().hasHeightForWidth())
        self.gray_136.setSizePolicy(sizePolicy)
        self.gray_136.setMinimumSize(QSize(0, 0))
        self.gray_136.setBaseSize(QSize(0, 0))
        font15 = QFont()
        font15.setFamily(u"Segoe UI")
        font15.setPointSize(9)
        font15.setBold(True)
        font15.setWeight(75)
        self.gray_136.setFont(font15)
        self.gray_136.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_136.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_136)

        self.gray_144 = QPushButton(self.layoutWidget_13)
        self.gray_144.setObjectName(u"gray_144")
        sizePolicy.setHeightForWidth(self.gray_144.sizePolicy().hasHeightForWidth())
        self.gray_144.setSizePolicy(sizePolicy)
        self.gray_144.setMinimumSize(QSize(0, 0))
        self.gray_144.setBaseSize(QSize(0, 0))
        self.gray_144.setFont(font15)
        self.gray_144.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_144.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_144)

        self.gray_152 = QPushButton(self.layoutWidget_13)
        self.gray_152.setObjectName(u"gray_152")
        sizePolicy.setHeightForWidth(self.gray_152.sizePolicy().hasHeightForWidth())
        self.gray_152.setSizePolicy(sizePolicy)
        self.gray_152.setMinimumSize(QSize(0, 0))
        self.gray_152.setBaseSize(QSize(0, 0))
        self.gray_152.setFont(font15)
        self.gray_152.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_152.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_152)

        self.gray_160 = QPushButton(self.layoutWidget_13)
        self.gray_160.setObjectName(u"gray_160")
        sizePolicy.setHeightForWidth(self.gray_160.sizePolicy().hasHeightForWidth())
        self.gray_160.setSizePolicy(sizePolicy)
        self.gray_160.setMinimumSize(QSize(0, 0))
        self.gray_160.setBaseSize(QSize(0, 0))
        self.gray_160.setFont(font15)
        self.gray_160.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_160.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_160)

        self.gray_168 = QPushButton(self.layoutWidget_13)
        self.gray_168.setObjectName(u"gray_168")
        sizePolicy.setHeightForWidth(self.gray_168.sizePolicy().hasHeightForWidth())
        self.gray_168.setSizePolicy(sizePolicy)
        self.gray_168.setMinimumSize(QSize(0, 0))
        self.gray_168.setBaseSize(QSize(0, 0))
        self.gray_168.setFont(font15)
        self.gray_168.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_168.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_168)

        self.gray_176 = QPushButton(self.layoutWidget_13)
        self.gray_176.setObjectName(u"gray_176")
        sizePolicy.setHeightForWidth(self.gray_176.sizePolicy().hasHeightForWidth())
        self.gray_176.setSizePolicy(sizePolicy)
        self.gray_176.setMinimumSize(QSize(0, 0))
        self.gray_176.setBaseSize(QSize(0, 0))
        self.gray_176.setFont(font15)
        self.gray_176.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_176.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_176)

        self.gray_184 = QPushButton(self.layoutWidget_13)
        self.gray_184.setObjectName(u"gray_184")
        sizePolicy.setHeightForWidth(self.gray_184.sizePolicy().hasHeightForWidth())
        self.gray_184.setSizePolicy(sizePolicy)
        self.gray_184.setMinimumSize(QSize(0, 0))
        self.gray_184.setBaseSize(QSize(0, 0))
        self.gray_184.setFont(font15)
        self.gray_184.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_184.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_184)

        self.gray_192 = QPushButton(self.layoutWidget_13)
        self.gray_192.setObjectName(u"gray_192")
        sizePolicy.setHeightForWidth(self.gray_192.sizePolicy().hasHeightForWidth())
        self.gray_192.setSizePolicy(sizePolicy)
        self.gray_192.setMinimumSize(QSize(0, 0))
        self.gray_192.setBaseSize(QSize(0, 0))
        self.gray_192.setFont(font15)
        self.gray_192.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_192.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_192)

        self.gray_200 = QPushButton(self.layoutWidget_13)
        self.gray_200.setObjectName(u"gray_200")
        sizePolicy.setHeightForWidth(self.gray_200.sizePolicy().hasHeightForWidth())
        self.gray_200.setSizePolicy(sizePolicy)
        self.gray_200.setMinimumSize(QSize(0, 0))
        self.gray_200.setBaseSize(QSize(0, 0))
        self.gray_200.setFont(font15)
        self.gray_200.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_200.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_200)

        self.gray_204 = QPushButton(self.layoutWidget_13)
        self.gray_204.setObjectName(u"gray_204")
        self.gray_204.setEnabled(True)
        sizePolicy.setHeightForWidth(self.gray_204.sizePolicy().hasHeightForWidth())
        self.gray_204.setSizePolicy(sizePolicy)
        self.gray_204.setMinimumSize(QSize(0, 0))
        self.gray_204.setBaseSize(QSize(0, 0))
        self.gray_204.setFont(font15)
        self.gray_204.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_204.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_204)

        self.gray_208 = QPushButton(self.layoutWidget_13)
        self.gray_208.setObjectName(u"gray_208")
        self.gray_208.setEnabled(True)
        sizePolicy.setHeightForWidth(self.gray_208.sizePolicy().hasHeightForWidth())
        self.gray_208.setSizePolicy(sizePolicy)
        self.gray_208.setMinimumSize(QSize(0, 0))
        self.gray_208.setBaseSize(QSize(0, 0))
        self.gray_208.setFont(font15)
        self.gray_208.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_208.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_208)

        self.gray_216 = QPushButton(self.layoutWidget_13)
        self.gray_216.setObjectName(u"gray_216")
        sizePolicy.setHeightForWidth(self.gray_216.sizePolicy().hasHeightForWidth())
        self.gray_216.setSizePolicy(sizePolicy)
        self.gray_216.setMinimumSize(QSize(0, 0))
        self.gray_216.setBaseSize(QSize(0, 0))
        self.gray_216.setFont(font15)
        self.gray_216.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_216.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_216)

        self.gray_224 = QPushButton(self.layoutWidget_13)
        self.gray_224.setObjectName(u"gray_224")
        sizePolicy.setHeightForWidth(self.gray_224.sizePolicy().hasHeightForWidth())
        self.gray_224.setSizePolicy(sizePolicy)
        self.gray_224.setMinimumSize(QSize(0, 0))
        self.gray_224.setBaseSize(QSize(0, 0))
        self.gray_224.setFont(font15)
        self.gray_224.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_224.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_224)

        self.gray_232 = QPushButton(self.layoutWidget_13)
        self.gray_232.setObjectName(u"gray_232")
        sizePolicy.setHeightForWidth(self.gray_232.sizePolicy().hasHeightForWidth())
        self.gray_232.setSizePolicy(sizePolicy)
        self.gray_232.setMinimumSize(QSize(0, 0))
        self.gray_232.setBaseSize(QSize(0, 0))
        self.gray_232.setFont(font15)
        self.gray_232.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_232.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_232)

        self.gray_240 = QPushButton(self.layoutWidget_13)
        self.gray_240.setObjectName(u"gray_240")
        sizePolicy.setHeightForWidth(self.gray_240.sizePolicy().hasHeightForWidth())
        self.gray_240.setSizePolicy(sizePolicy)
        self.gray_240.setMinimumSize(QSize(0, 0))
        self.gray_240.setBaseSize(QSize(0, 0))
        self.gray_240.setFont(font15)
        self.gray_240.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_240.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_240)

        self.gray_248 = QPushButton(self.layoutWidget_13)
        self.gray_248.setObjectName(u"gray_248")
        sizePolicy.setHeightForWidth(self.gray_248.sizePolicy().hasHeightForWidth())
        self.gray_248.setSizePolicy(sizePolicy)
        self.gray_248.setMinimumSize(QSize(0, 0))
        self.gray_248.setBaseSize(QSize(0, 0))
        self.gray_248.setFont(font15)
        self.gray_248.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_248.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_248)

        self.gray_255 = QPushButton(self.layoutWidget_13)
        self.gray_255.setObjectName(u"gray_255")
        sizePolicy.setHeightForWidth(self.gray_255.sizePolicy().hasHeightForWidth())
        self.gray_255.setSizePolicy(sizePolicy)
        self.gray_255.setMinimumSize(QSize(0, 0))
        self.gray_255.setBaseSize(QSize(0, 0))
        self.gray_255.setFont(font15)
        self.gray_255.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_255.setAutoDefault(False)

        self.horizontalLayout_2.addWidget(self.gray_255)

        self.layoutWidget1 = QWidget(self.gamma)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(30, 50, 461, 31))
        self.horizontalLayout = QHBoxLayout(self.layoutWidget1)
        self.horizontalLayout.setSpacing(1)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.gray_0 = QPushButton(self.layoutWidget1)
        self.gray_0.setObjectName(u"gray_0")
        sizePolicy.setHeightForWidth(self.gray_0.sizePolicy().hasHeightForWidth())
        self.gray_0.setSizePolicy(sizePolicy)
        self.gray_0.setMinimumSize(QSize(0, 0))
        self.gray_0.setBaseSize(QSize(0, 0))
        self.gray_0.setFont(font15)
        self.gray_0.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_0.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_0)

        self.gray_8 = QPushButton(self.layoutWidget1)
        self.gray_8.setObjectName(u"gray_8")
        sizePolicy.setHeightForWidth(self.gray_8.sizePolicy().hasHeightForWidth())
        self.gray_8.setSizePolicy(sizePolicy)
        self.gray_8.setMinimumSize(QSize(0, 0))
        self.gray_8.setBaseSize(QSize(0, 0))
        self.gray_8.setFont(font15)
        self.gray_8.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_8.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_8)

        self.gray_16 = QPushButton(self.layoutWidget1)
        self.gray_16.setObjectName(u"gray_16")
        sizePolicy.setHeightForWidth(self.gray_16.sizePolicy().hasHeightForWidth())
        self.gray_16.setSizePolicy(sizePolicy)
        self.gray_16.setMinimumSize(QSize(0, 0))
        self.gray_16.setBaseSize(QSize(0, 0))
        self.gray_16.setFont(font15)
        self.gray_16.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_16.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_16)

        self.gray_24 = QPushButton(self.layoutWidget1)
        self.gray_24.setObjectName(u"gray_24")
        sizePolicy.setHeightForWidth(self.gray_24.sizePolicy().hasHeightForWidth())
        self.gray_24.setSizePolicy(sizePolicy)
        self.gray_24.setMinimumSize(QSize(0, 0))
        self.gray_24.setBaseSize(QSize(0, 0))
        self.gray_24.setFont(font15)
        self.gray_24.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_24.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_24)

        self.gray_32 = QPushButton(self.layoutWidget1)
        self.gray_32.setObjectName(u"gray_32")
        sizePolicy.setHeightForWidth(self.gray_32.sizePolicy().hasHeightForWidth())
        self.gray_32.setSizePolicy(sizePolicy)
        self.gray_32.setMinimumSize(QSize(0, 0))
        self.gray_32.setBaseSize(QSize(0, 0))
        self.gray_32.setFont(font15)
        self.gray_32.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_32.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_32)

        self.gray_40 = QPushButton(self.layoutWidget1)
        self.gray_40.setObjectName(u"gray_40")
        sizePolicy.setHeightForWidth(self.gray_40.sizePolicy().hasHeightForWidth())
        self.gray_40.setSizePolicy(sizePolicy)
        self.gray_40.setMinimumSize(QSize(0, 0))
        self.gray_40.setBaseSize(QSize(0, 0))
        self.gray_40.setFont(font15)
        self.gray_40.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_40.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_40)

        self.gray_48 = QPushButton(self.layoutWidget1)
        self.gray_48.setObjectName(u"gray_48")
        sizePolicy.setHeightForWidth(self.gray_48.sizePolicy().hasHeightForWidth())
        self.gray_48.setSizePolicy(sizePolicy)
        self.gray_48.setMinimumSize(QSize(0, 0))
        self.gray_48.setBaseSize(QSize(0, 0))
        self.gray_48.setFont(font15)
        self.gray_48.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_48.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_48)

        self.gray_56 = QPushButton(self.layoutWidget1)
        self.gray_56.setObjectName(u"gray_56")
        sizePolicy.setHeightForWidth(self.gray_56.sizePolicy().hasHeightForWidth())
        self.gray_56.setSizePolicy(sizePolicy)
        self.gray_56.setMinimumSize(QSize(0, 0))
        self.gray_56.setBaseSize(QSize(0, 0))
        self.gray_56.setFont(font15)
        self.gray_56.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_56.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_56)

        self.gray_64 = QPushButton(self.layoutWidget1)
        self.gray_64.setObjectName(u"gray_64")
        sizePolicy.setHeightForWidth(self.gray_64.sizePolicy().hasHeightForWidth())
        self.gray_64.setSizePolicy(sizePolicy)
        self.gray_64.setMinimumSize(QSize(0, 0))
        self.gray_64.setBaseSize(QSize(0, 0))
        self.gray_64.setFont(font15)
        self.gray_64.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_64.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_64)

        self.gray_72 = QPushButton(self.layoutWidget1)
        self.gray_72.setObjectName(u"gray_72")
        sizePolicy.setHeightForWidth(self.gray_72.sizePolicy().hasHeightForWidth())
        self.gray_72.setSizePolicy(sizePolicy)
        self.gray_72.setMinimumSize(QSize(0, 0))
        self.gray_72.setBaseSize(QSize(0, 0))
        self.gray_72.setFont(font15)
        self.gray_72.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_72.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_72)

        self.gray_80 = QPushButton(self.layoutWidget1)
        self.gray_80.setObjectName(u"gray_80")
        sizePolicy.setHeightForWidth(self.gray_80.sizePolicy().hasHeightForWidth())
        self.gray_80.setSizePolicy(sizePolicy)
        self.gray_80.setMinimumSize(QSize(0, 0))
        self.gray_80.setBaseSize(QSize(0, 0))
        self.gray_80.setFont(font15)
        self.gray_80.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_80.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_80)

        self.gray_88 = QPushButton(self.layoutWidget1)
        self.gray_88.setObjectName(u"gray_88")
        sizePolicy.setHeightForWidth(self.gray_88.sizePolicy().hasHeightForWidth())
        self.gray_88.setSizePolicy(sizePolicy)
        self.gray_88.setMinimumSize(QSize(0, 0))
        self.gray_88.setBaseSize(QSize(0, 0))
        self.gray_88.setFont(font15)
        self.gray_88.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_88.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_88)

        self.gray_96 = QPushButton(self.layoutWidget1)
        self.gray_96.setObjectName(u"gray_96")
        sizePolicy.setHeightForWidth(self.gray_96.sizePolicy().hasHeightForWidth())
        self.gray_96.setSizePolicy(sizePolicy)
        self.gray_96.setMinimumSize(QSize(0, 0))
        self.gray_96.setBaseSize(QSize(0, 0))
        self.gray_96.setFont(font15)
        self.gray_96.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_96.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_96)

        self.gray_104 = QPushButton(self.layoutWidget1)
        self.gray_104.setObjectName(u"gray_104")
        sizePolicy.setHeightForWidth(self.gray_104.sizePolicy().hasHeightForWidth())
        self.gray_104.setSizePolicy(sizePolicy)
        self.gray_104.setMinimumSize(QSize(0, 0))
        self.gray_104.setBaseSize(QSize(0, 0))
        self.gray_104.setFont(font15)
        self.gray_104.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_104.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_104)

        self.gray_112 = QPushButton(self.layoutWidget1)
        self.gray_112.setObjectName(u"gray_112")
        sizePolicy.setHeightForWidth(self.gray_112.sizePolicy().hasHeightForWidth())
        self.gray_112.setSizePolicy(sizePolicy)
        self.gray_112.setMinimumSize(QSize(0, 0))
        self.gray_112.setBaseSize(QSize(0, 0))
        self.gray_112.setFont(font15)
        self.gray_112.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_112.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_112)

        self.gray_120 = QPushButton(self.layoutWidget1)
        self.gray_120.setObjectName(u"gray_120")
        sizePolicy.setHeightForWidth(self.gray_120.sizePolicy().hasHeightForWidth())
        self.gray_120.setSizePolicy(sizePolicy)
        self.gray_120.setMinimumSize(QSize(0, 0))
        self.gray_120.setBaseSize(QSize(0, 0))
        self.gray_120.setFont(font15)
        self.gray_120.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_120.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_120)

        self.gray_128 = QPushButton(self.layoutWidget1)
        self.gray_128.setObjectName(u"gray_128")
        sizePolicy.setHeightForWidth(self.gray_128.sizePolicy().hasHeightForWidth())
        self.gray_128.setSizePolicy(sizePolicy)
        self.gray_128.setMinimumSize(QSize(0, 0))
        self.gray_128.setBaseSize(QSize(0, 0))
        self.gray_128.setFont(font15)
        self.gray_128.setCursor(QCursor(Qt.PointingHandCursor))
        self.gray_128.setAutoDefault(False)

        self.horizontalLayout.addWidget(self.gray_128)

        self.lineEdit_gmastep = QLineEdit(self.gamma)
        self.lineEdit_gmastep.setObjectName(u"lineEdit_gmastep")
        self.lineEdit_gmastep.setEnabled(True)
        self.lineEdit_gmastep.setGeometry(QRect(278, 14, 51, 20))
        self.lineEdit_gmastep.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_gmastep.setFont(font7)
        self.lineEdit_gmastep.setAlignment(Qt.AlignCenter)
        self.label_gmaStep = QLabel(self.gamma)
        self.label_gmaStep.setObjectName(u"label_gmaStep")
        self.label_gmaStep.setGeometry(QRect(227, 12, 51, 23))
        self.label_gmaStep.setFont(font5)
        self.label_gmaStep.setAlignment(Qt.AlignCenter)
        self.label_gmawinsize = QLabel(self.gamma)
        self.label_gmawinsize.setObjectName(u"label_gmawinsize")
        self.label_gmawinsize.setGeometry(QRect(337, 12, 131, 23))
        self.label_gmawinsize.setFont(font5)
        self.label_gmawinsize.setAlignment(Qt.AlignCenter)
        self.lineEdit_gmaboxsize = QLineEdit(self.gamma)
        self.lineEdit_gmaboxsize.setObjectName(u"lineEdit_gmaboxsize")
        self.lineEdit_gmaboxsize.setGeometry(QRect(469, 15, 51, 20))
        self.lineEdit_gmaboxsize.setMaximumSize(QSize(16777215, 20))
        self.lineEdit_gmaboxsize.setFont(font7)
        self.lineEdit_gmaboxsize.setAlignment(Qt.AlignCenter)
        self.btn_gmaStart = QPushButton(self.gamma)
        self.btn_gmaStart.setObjectName(u"btn_gmaStart")
        self.btn_gmaStart.setGeometry(QRect(145, 350, 101, 31))
        self.btn_gmaStart.setFont(font6)
        self.btn_gmaStart.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_gmaStop = QPushButton(self.gamma)
        self.btn_gmaStop.setObjectName(u"btn_gmaStop")
        self.btn_gmaStop.setGeometry(QRect(266, 350, 101, 31))
        self.btn_gmaStop.setFont(font6)
        self.btn_gmaStop.setCursor(QCursor(Qt.PointingHandCursor))
        self.label_45 = QLabel(self.gamma)
        self.label_45.setObjectName(u"label_45")
        self.label_45.setGeometry(QRect(40, 140, 211, 181))
        self.label_45.setPixmap(QPixmap(u":/etc/gamma.png"))
        self.label_45.setScaledContents(True)
        self.label_46 = QLabel(self.gamma)
        self.label_46.setObjectName(u"label_46")
        self.label_46.setGeometry(QRect(270, 140, 211, 181))
        self.label_46.setPixmap(QPixmap(u":/etc/gamma.png"))
        self.label_46.setScaledContents(True)
        self.tabWidget_2.addTab(self.gamma, "")
        self.calman = QWidget()
        self.calman.setObjectName(u"calman")
        self.tabWidget_2.addTab(self.calman, "")
        self.apl = QWidget()
        self.apl.setObjectName(u"apl")
        self.tabWidget_2.addTab(self.apl, "")
        self.fixedgamma = QWidget()
        self.fixedgamma.setObjectName(u"fixedgamma")
        self.tabWidget_2.addTab(self.fixedgamma, "")
        self.periodicmeas = QWidget()
        self.periodicmeas.setObjectName(u"periodicmeas")
        self.tabWidget_2.addTab(self.periodicmeas, "")
        self.ammeasurepage.addWidget(self.manpage)
        self.label_36 = QLabel(self.pqmeasure)
        self.label_36.setObjectName(u"label_36")
        self.label_36.setGeometry(QRect(250, 41, 341, 41))
        font16 = QFont()
        font16.setFamily(u"Arial Narrow")
        font16.setPointSize(13)
        font16.setBold(True)
        font16.setItalic(True)
        font16.setWeight(75)
        self.label_36.setFont(font16)
        self.label_36.setCursor(QCursor(Qt.ArrowCursor))
        self.manualBtn = QPushButton(self.pqmeasure)
        self.manualBtn.setObjectName(u"manualBtn")
        self.manualBtn.setGeometry(QRect(136, 42, 100, 41))
        font17 = QFont()
        font17.setFamily(u"Segoe UI")
        font17.setPointSize(13)
        font17.setBold(True)
        font17.setWeight(75)
        self.manualBtn.setFont(font17)
        self.manualBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.manualBtn.setStyleSheet(u"")
        icon7 = QIcon()
        icon7.addFile(u":/icons/Icons/toggle-left.png", QSize(), QIcon.Normal, QIcon.Off)
        self.manualBtn.setIcon(icon7)
        self.manualBtn.setIconSize(QSize(24, 24))
        self.manualBtn.setAutoDefault(False)
        self.autoBtn = QPushButton(self.pqmeasure)
        self.autoBtn.setObjectName(u"autoBtn")
        self.autoBtn.setGeometry(QRect(30, 42, 100, 41))
        self.autoBtn.setFont(font17)
        self.autoBtn.setCursor(QCursor(Qt.PointingHandCursor))
        self.autoBtn.setStyleSheet(u"background-color: #1b1b27;\n"
"")
        self.autoBtn.setIcon(icon7)
        self.autoBtn.setIconSize(QSize(24, 24))
        self.autoBtn.setAutoDefault(False)
        self.label_32.raise_()
        self.label_36.raise_()
        self.manualBtn.raise_()
        self.autoBtn.raise_()
        self.ammeasurepage.raise_()
        self.reportWidget = QWidget(self.widget_3)
        self.reportWidget.setObjectName(u"reportWidget")
        self.reportWidget.setGeometry(QRect(1020, 2, 651, 851))
        self.tableWidget = QTableWidget(self.reportWidget)
        if (self.tableWidget.columnCount() < 18):
            self.tableWidget.setColumnCount(18)
        font18 = QFont()
        font18.setBold(True)
        font18.setWeight(75)
        __qtablewidgetitem = QTableWidgetItem()
        __qtablewidgetitem.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        __qtablewidgetitem1.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        __qtablewidgetitem2.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        __qtablewidgetitem3.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        __qtablewidgetitem4.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        __qtablewidgetitem5.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(5, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        __qtablewidgetitem6.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(6, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        __qtablewidgetitem7.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(7, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        __qtablewidgetitem8.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(8, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        __qtablewidgetitem9.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(9, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        __qtablewidgetitem10.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(10, __qtablewidgetitem10)
        __qtablewidgetitem11 = QTableWidgetItem()
        __qtablewidgetitem11.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(11, __qtablewidgetitem11)
        __qtablewidgetitem12 = QTableWidgetItem()
        __qtablewidgetitem12.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(12, __qtablewidgetitem12)
        __qtablewidgetitem13 = QTableWidgetItem()
        __qtablewidgetitem13.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(13, __qtablewidgetitem13)
        __qtablewidgetitem14 = QTableWidgetItem()
        __qtablewidgetitem14.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(14, __qtablewidgetitem14)
        __qtablewidgetitem15 = QTableWidgetItem()
        __qtablewidgetitem15.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(15, __qtablewidgetitem15)
        __qtablewidgetitem16 = QTableWidgetItem()
        __qtablewidgetitem16.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(16, __qtablewidgetitem16)
        __qtablewidgetitem17 = QTableWidgetItem()
        __qtablewidgetitem17.setFont(font18);
        self.tableWidget.setHorizontalHeaderItem(17, __qtablewidgetitem17)
        if (self.tableWidget.rowCount() < 250):
            self.tableWidget.setRowCount(250)
        font19 = QFont()
        font19.setFamily(u"Segoe UI")
        font19.setBold(True)
        font19.setWeight(75)
        __qtablewidgetitem18 = QTableWidgetItem()
        __qtablewidgetitem18.setFont(font19);
        self.tableWidget.setItem(0, 17, __qtablewidgetitem18)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(10, 61, 621, 781))
        font20 = QFont()
        font20.setFamily(u"Segoe UI")
        self.tableWidget.setFont(font20)
        self.tableWidget.setFrameShape(QFrame.StyledPanel)
        self.tableWidget.setFrameShadow(QFrame.Sunken)
        self.tableWidget.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.tableWidget.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        self.tableWidget.setAutoScroll(True)
        self.tableWidget.setAlternatingRowColors(False)
        self.tableWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.tableWidget.setTextElideMode(Qt.ElideRight)
        self.tableWidget.setVerticalScrollMode(QAbstractItemView.ScrollPerItem)
        self.tableWidget.setShowGrid(True)
        self.tableWidget.setGridStyle(Qt.SolidLine)
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setWordWrap(True)
        self.tableWidget.setCornerButtonEnabled(False)
        self.tableWidget.setRowCount(250)
        self.tableWidget.horizontalHeader().setVisible(True)
        self.tableWidget.horizontalHeader().setCascadingSectionResizes(False)
        self.tableWidget.horizontalHeader().setDefaultSectionSize(70)
        self.tableWidget.horizontalHeader().setHighlightSections(True)
        self.tableWidget.verticalHeader().setVisible(True)
        self.tableWidget.verticalHeader().setDefaultSectionSize(23)
        self.btn_report = QPushButton(self.reportWidget)
        self.btn_report.setObjectName(u"btn_report")
        self.btn_report.setGeometry(QRect(29, 18, 141, 31))
        self.btn_report.setFont(font5)
        self.mesWidget = QWidget(self.widget_3)
        self.mesWidget.setObjectName(u"mesWidget")
        self.mesWidget.setGeometry(QRect(399, 690, 611, 161))
        self.layoutWidget_11 = QWidget(self.mesWidget)
        self.layoutWidget_11.setObjectName(u"layoutWidget_11")
        self.layoutWidget_11.setGeometry(QRect(23, 8, 141, 142))
        self.verticalLayout_11 = QVBoxLayout(self.layoutWidget_11)
        self.verticalLayout_11.setSpacing(6)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.label_7 = QLabel(self.layoutWidget_11)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setFont(font6)
        self.label_7.setAlignment(Qt.AlignCenter)

        self.verticalLayout_11.addWidget(self.label_7)

        self.label_67 = QLabel(self.layoutWidget_11)
        self.label_67.setObjectName(u"label_67")
        self.label_67.setFont(font6)
        self.label_67.setAlignment(Qt.AlignCenter)

        self.verticalLayout_11.addWidget(self.label_67)

        self.label_68 = QLabel(self.layoutWidget_11)
        self.label_68.setObjectName(u"label_68")
        self.label_68.setFont(font6)
        self.label_68.setAlignment(Qt.AlignCenter)

        self.verticalLayout_11.addWidget(self.label_68)

        self.label_69 = QLabel(self.layoutWidget_11)
        self.label_69.setObjectName(u"label_69")
        self.label_69.setFont(font6)
        self.label_69.setAlignment(Qt.AlignCenter)

        self.verticalLayout_11.addWidget(self.label_69)

        self.label_70 = QLabel(self.layoutWidget_11)
        self.label_70.setObjectName(u"label_70")
        self.label_70.setFont(font6)
        self.label_70.setAlignment(Qt.AlignCenter)

        self.verticalLayout_11.addWidget(self.label_70)

        self.layoutWidget_12 = QWidget(self.mesWidget)
        self.layoutWidget_12.setObjectName(u"layoutWidget_12")
        self.layoutWidget_12.setGeometry(QRect(169, 8, 121, 141))
        self.verticalLayout_12 = QVBoxLayout(self.layoutWidget_12)
        self.verticalLayout_12.setSpacing(6)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.lineEdit_nit = QLineEdit(self.layoutWidget_12)
        self.lineEdit_nit.setObjectName(u"lineEdit_nit")
        sizePolicy.setHeightForWidth(self.lineEdit_nit.sizePolicy().hasHeightForWidth())
        self.lineEdit_nit.setSizePolicy(sizePolicy)
        self.lineEdit_nit.setFont(font7)
        self.lineEdit_nit.setReadOnly(True)

        self.verticalLayout_12.addWidget(self.lineEdit_nit)

        self.lineEdit_xy = QLineEdit(self.layoutWidget_12)
        self.lineEdit_xy.setObjectName(u"lineEdit_xy")
        sizePolicy.setHeightForWidth(self.lineEdit_xy.sizePolicy().hasHeightForWidth())
        self.lineEdit_xy.setSizePolicy(sizePolicy)
        self.lineEdit_xy.setFont(font7)
        self.lineEdit_xy.setReadOnly(True)

        self.verticalLayout_12.addWidget(self.lineEdit_xy)

        self.lineEdit_uv = QLineEdit(self.layoutWidget_12)
        self.lineEdit_uv.setObjectName(u"lineEdit_uv")
        sizePolicy.setHeightForWidth(self.lineEdit_uv.sizePolicy().hasHeightForWidth())
        self.lineEdit_uv.setSizePolicy(sizePolicy)
        self.lineEdit_uv.setFont(font7)
        self.lineEdit_uv.setReadOnly(True)

        self.verticalLayout_12.addWidget(self.lineEdit_uv)

        self.lineEdit_cct = QLineEdit(self.layoutWidget_12)
        self.lineEdit_cct.setObjectName(u"lineEdit_cct")
        sizePolicy.setHeightForWidth(self.lineEdit_cct.sizePolicy().hasHeightForWidth())
        self.lineEdit_cct.setSizePolicy(sizePolicy)
        self.lineEdit_cct.setFont(font7)
        self.lineEdit_cct.setReadOnly(True)

        self.verticalLayout_12.addWidget(self.lineEdit_cct)

        self.lineEdit_duv = QLineEdit(self.layoutWidget_12)
        self.lineEdit_duv.setObjectName(u"lineEdit_duv")
        sizePolicy.setHeightForWidth(self.lineEdit_duv.sizePolicy().hasHeightForWidth())
        self.lineEdit_duv.setSizePolicy(sizePolicy)
        self.lineEdit_duv.setFont(font7)
        self.lineEdit_duv.setReadOnly(True)

        self.verticalLayout_12.addWidget(self.lineEdit_duv)

        self.progress = QTextEdit(self.mesWidget)
        self.progress.setObjectName(u"progress")
        self.progress.setGeometry(QRect(310, 66, 291, 81))
        self.progress.setFont(font20)
        self.progress.setLineWidth(1)
        self.progress.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.progress.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        self.progress.setTabChangesFocus(False)
        self.progress.setReadOnly(False)
        self.procress_mea = QPushButton(self.mesWidget)
        self.procress_mea.setObjectName(u"procress_mea")
        self.procress_mea.setGeometry(QRect(310, 20, 121, 31))
        self.procress_mea.setFont(font5)

        self.retranslateUi(Form)

        self.tabWidget.setCurrentIndex(1)
        self.win_all.setDefault(False)
        self.win_red.setDefault(False)
        self.win_green.setDefault(False)
        self.win_blue.setDefault(False)
        self.win_cyan.setDefault(False)
        self.win_magen.setDefault(False)
        self.win_yellow.setDefault(False)
        self.win_white.setDefault(False)
        self.win_black.setDefault(False)
        self.win_all_2.setDefault(False)
        self.win_red_2.setDefault(False)
        self.win_green_2.setDefault(False)
        self.win_blue_2.setDefault(False)
        self.win_cyan_2.setDefault(False)
        self.win_magen_2.setDefault(False)
        self.win_yellow_2.setDefault(False)
        self.win_white_2.setDefault(False)
        self.win_black_2.setDefault(False)
        self.ammeasurepage.setCurrentIndex(0)
        self.tabWidget_2.setCurrentIndex(0)
        self.gray_136.setDefault(False)
        self.gray_144.setDefault(False)
        self.gray_152.setDefault(False)
        self.gray_160.setDefault(False)
        self.gray_168.setDefault(False)
        self.gray_176.setDefault(False)
        self.gray_184.setDefault(False)
        self.gray_192.setDefault(False)
        self.gray_200.setDefault(False)
        self.gray_204.setDefault(False)
        self.gray_208.setDefault(False)
        self.gray_216.setDefault(False)
        self.gray_224.setDefault(False)
        self.gray_232.setDefault(False)
        self.gray_240.setDefault(False)
        self.gray_248.setDefault(False)
        self.gray_255.setDefault(False)
        self.gray_0.setDefault(False)
        self.gray_8.setDefault(False)
        self.gray_16.setDefault(False)
        self.gray_24.setDefault(False)
        self.gray_32.setDefault(False)
        self.gray_40.setDefault(False)
        self.gray_48.setDefault(False)
        self.gray_56.setDefault(False)
        self.gray_64.setDefault(False)
        self.gray_72.setDefault(False)
        self.gray_80.setDefault(False)
        self.gray_88.setDefault(False)
        self.gray_96.setDefault(False)
        self.gray_104.setDefault(False)
        self.gray_112.setDefault(False)
        self.gray_120.setDefault(False)
        self.gray_128.setDefault(False)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label_11.setText(QCoreApplication.translate("Form", u"Model Name", None))
        self.label_12.setText(QCoreApplication.translate("Form", u"Panel", None))
        self.label_14.setText(QCoreApplication.translate("Form", u"Event", None))
        self.label_18.setText(QCoreApplication.translate("Form", u"Site", None))
        self.label_19.setText(QCoreApplication.translate("Form", u"LED Rank", None))
        self.label_10.setText(QCoreApplication.translate("Form", u"Model Year", None))
        self.label_16.setText(QCoreApplication.translate("Form", u"Dev.Grade", None))
        self.label_13.setText(QCoreApplication.translate("Form", u"BLU Type", None))
        self.comboBox_2.setItemText(0, QCoreApplication.translate("Form", u"Model", None))

#if QT_CONFIG(statustip)
        self.comboBox_2.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.comboBox_2.setCurrentText(QCoreApplication.translate("Form", u"Model", None))
        self.comboBox_3.setItemText(0, QCoreApplication.translate("Form", u"Maker", None))

#if QT_CONFIG(statustip)
        self.comboBox_3.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.comboBox_5.setItemText(0, QCoreApplication.translate("Form", u"PP/DV/PV", None))

#if QT_CONFIG(statustip)
        self.comboBox_5.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.comboBox_9.setItemText(0, QCoreApplication.translate("Form", u"HQ/GZ/IN", None))

#if QT_CONFIG(statustip)
        self.comboBox_9.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.comboBox_8.setItemText(0, QCoreApplication.translate("Form", u"A/B/C/D/E", None))

#if QT_CONFIG(statustip)
        self.comboBox_8.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.comboBox.setItemText(0, QCoreApplication.translate("Form", u"Model Year", None))

#if QT_CONFIG(statustip)
        self.comboBox.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.comboBox_6.setItemText(0, QCoreApplication.translate("Form", u"C_MO", None))

#if QT_CONFIG(statustip)
        self.comboBox_6.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.comboBox_4.setItemText(0, QCoreApplication.translate("Form", u"Edge/Direct", None))

#if QT_CONFIG(statustip)
        self.comboBox_4.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.label_15.setText(QCoreApplication.translate("Form", u"1. Base Infomation", None))
        self.showModelFormBtn.setText(QCoreApplication.translate("Form", u"New", None))
        self.connectBtn_2.setText(QCoreApplication.translate("Form", u"Connect", None))
        self.label_20.setText("")
        self.disconnectBtn_2.setText(QCoreApplication.translate("Form", u"DisConnect", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("Form", u"CA-410", None))
        self.ca310connBtn.setText(QCoreApplication.translate("Form", u"Connect", None))
        self.ca310discBtn.setText(QCoreApplication.translate("Form", u"DisConnect", None))
        self.label_8.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("Form", u"CA-310", None))
        self.connectBtn_3.setText(QCoreApplication.translate("Form", u"Connect", None))
        self.label_21.setText("")
        self.disconnectBtn_3.setText(QCoreApplication.translate("Form", u"DisConnect", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), QCoreApplication.translate("Form", u"CMH505", None))
        self.connectBtn_4.setText(QCoreApplication.translate("Form", u"Connect", None))
        self.disconnectBtn_4.setText(QCoreApplication.translate("Form", u"DisConnect", None))
        self.label_22.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), QCoreApplication.translate("Form", u"CS2000", None))
        self.disconnectBtn_5.setText(QCoreApplication.translate("Form", u"DisConnect", None))
        self.connectBtn_5.setText(QCoreApplication.translate("Form", u"Connect", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_5), QCoreApplication.translate("Form", u"SR3", None))
        self.label_17.setText(QCoreApplication.translate("Form", u"2. Select and Connet with Intrument", None))
        self.label_27.setText(QCoreApplication.translate("Form", u"3. Patten Generator (HDMI)", None))
        self.resolutioncombo.setItemText(0, QCoreApplication.translate("Form", u"1920x1080", None))
        self.resolutioncombo.setItemText(1, QCoreApplication.translate("Form", u"3840x2160", None))
        self.resolutioncombo.setItemText(2, QCoreApplication.translate("Form", u"3440x1440", None))

#if QT_CONFIG(statustip)
        self.resolutioncombo.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.resolutioncombo.setCurrentText(QCoreApplication.translate("Form", u"1920x1080", None))
        self.showwindowBtn.setText(QCoreApplication.translate("Form", u"Run Window", None))
        self.label_28.setText(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\">Window</p></body></html>", None))
        self.ptnchangeBtn.setText(QCoreApplication.translate("Form", u"Go!!", None))
        self.win_all.setText(QCoreApplication.translate("Form", u"All", None))
        self.win_red.setText(QCoreApplication.translate("Form", u"R", None))
        self.win_green.setText(QCoreApplication.translate("Form", u"G", None))
        self.win_blue.setText(QCoreApplication.translate("Form", u"B", None))
        self.win_cyan.setText(QCoreApplication.translate("Form", u"C", None))
        self.win_magen.setText(QCoreApplication.translate("Form", u"M", None))
        self.win_yellow.setText(QCoreApplication.translate("Form", u"Y", None))
        self.win_white.setText(QCoreApplication.translate("Form", u"W", None))
        self.win_black.setText(QCoreApplication.translate("Form", u"Bk", None))
        self.lineEdit_3.setText(QCoreApplication.translate("Form", u"255", None))
        self.lineEdit_4.setText(QCoreApplication.translate("Form", u"255", None))
        self.lineEdit_5.setText(QCoreApplication.translate("Form", u"255", None))
        self.sizeEdit.setInputMask("")
        self.sizeEdit.setText(QCoreApplication.translate("Form", u"0", None))
        self.redlabel.setText(QCoreApplication.translate("Form", u"R(All)", None))
        self.greenlabel.setText(QCoreApplication.translate("Form", u"G", None))
        self.bluelabel.setText(QCoreApplication.translate("Form", u"B", None))
        self.sizelabel.setText(QCoreApplication.translate("Form", u"Size", None))
        self.label_29.setText(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\">Backgroud</p></body></html>", None))
        self.win_all_2.setText(QCoreApplication.translate("Form", u"All", None))
        self.win_red_2.setText(QCoreApplication.translate("Form", u"R", None))
        self.win_green_2.setText(QCoreApplication.translate("Form", u"G", None))
        self.win_blue_2.setText(QCoreApplication.translate("Form", u"B", None))
        self.win_cyan_2.setText(QCoreApplication.translate("Form", u"C", None))
        self.win_magen_2.setText(QCoreApplication.translate("Form", u"M", None))
        self.win_yellow_2.setText(QCoreApplication.translate("Form", u"Y", None))
        self.win_white_2.setText(QCoreApplication.translate("Form", u"W", None))
        self.win_black_2.setText(QCoreApplication.translate("Form", u"Bk", None))
        self.lineEdit_7.setText(QCoreApplication.translate("Form", u"0", None))
        self.lineEdit_8.setText(QCoreApplication.translate("Form", u"0", None))
        self.lineEdit_9.setText(QCoreApplication.translate("Form", u"0", None))
        self.redlabel_2.setText(QCoreApplication.translate("Form", u"R(All)", None))
        self.greenlabel_2.setText(QCoreApplication.translate("Form", u"G", None))
        self.bluelabel_2.setText(QCoreApplication.translate("Form", u"B", None))
        self.ptnchangeBtn_2.setText(QCoreApplication.translate("Form", u"Go!!", None))
        self.tvbox.setText("")
        self.tvbox_2.setText("")
        self.backcolor.setText("")
        self.wincolor.setText("")
        self.label_30.setText(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\">Window</p></body></html>", None))
        self.label_31.setText(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\">Background</p></body></html>", None))
        self.tvbox_3.setText("")
        self.result.setText(QCoreApplication.translate("Form", u"<html><head/><body><p align=\"center\">Result</p></body></html>", None))
        self.totalbackcolor.setText("")
        self.totalwincolor.setText("")
        self.label_32.setText(QCoreApplication.translate("Form", u"4. Picture Quality Measure", None))
        self.allMeasureBtn.setText(QCoreApplication.translate("Form", u"All Measure", None))
        self.allStopBtn.setText(QCoreApplication.translate("Form", u"All Stop", None))
#if QT_CONFIG(statustip)
        self.checkBox_cr.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.checkBox_cr.setText(QCoreApplication.translate("Form", u"Contrast Ratio", None))
        self.checkBox_gamut.setText(QCoreApplication.translate("Form", u"Gamut", None))
        self.checkBox_gamma.setText(QCoreApplication.translate("Form", u"Gamma Curve", None))
        self.checkBox_calman.setText(QCoreApplication.translate("Form", u"Calman", None))
#if QT_CONFIG(statustip)
        self.checkBox_apl.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.checkBox_apl.setText(QCoreApplication.translate("Form", u"APL", None))
        self.label_25.setText(QCoreApplication.translate("Form", u"Measure the color coordinates of red, green, and blue.", None))
        self.label_35.setText(QCoreApplication.translate("Form", u"Measure the peak luminance as a function of APL box size.", None))
        self.label_34.setText(QCoreApplication.translate("Form", u"Measures calman.", None))
        self.label_24.setText(QCoreApplication.translate("Form", u"Measure the brightness of Full White&Black. Calculates ratio!!", None))
        self.label_26.setText(QCoreApplication.translate("Form", u"Measures brightness from 0 to 255 levels for each pattern.", None))
        self.uploadBtn.setText(QCoreApplication.translate("Form", u" Save & Upload Data to DB (Extracting Excel)", None))
        self.label_23.setText("")
        self.label_37.setText(QCoreApplication.translate("Form", u"Measure the brightness of Full White&Black. Calculates ratio!!", None))
        self.label_38.setText(QCoreApplication.translate("Form", u"Contrast Ratio", None))
        self.meas_cr.setText(QCoreApplication.translate("Form", u"Measure", None))
        self.label_39.setText("")
        self.meas_gamut.setText(QCoreApplication.translate("Form", u"Measure", None))
        self.label_40.setText(QCoreApplication.translate("Form", u"Gamut", None))
        self.label_41.setText(QCoreApplication.translate("Form", u"Measure the color coordinates of red, green, and blue.", None))
        self.label_42.setText(QCoreApplication.translate("Form", u"Color Sweep", None))
        self.label_43.setText("")
        self.label_44.setText(QCoreApplication.translate("Form", u"Measure the color coordinates of red, green, and blue.", None))
        self.meas_color.setText(QCoreApplication.translate("Form", u"Measure", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.basic), QCoreApplication.translate("Form", u"Basic", None))
        self.radioButton_Gray.setText("")
        self.radioButton_Red.setText("")
        self.radioButton_Green.setText("")
        self.radioButton_Blue.setText("")
        self.radioButton_Cyan.setText("")
        self.radioButton_Magenta.setText("")
        self.radioButton_Yellow.setText("")
        self.radioButton_All.setText(QCoreApplication.translate("Form", u"All", None))
        self.gray_136.setText(QCoreApplication.translate("Form", u"136", None))
        self.gray_144.setText(QCoreApplication.translate("Form", u"144", None))
        self.gray_152.setText(QCoreApplication.translate("Form", u"152", None))
        self.gray_160.setText(QCoreApplication.translate("Form", u"160", None))
        self.gray_168.setText(QCoreApplication.translate("Form", u"168", None))
        self.gray_176.setText(QCoreApplication.translate("Form", u"176", None))
        self.gray_184.setText(QCoreApplication.translate("Form", u"184", None))
        self.gray_192.setText(QCoreApplication.translate("Form", u"192", None))
        self.gray_200.setText(QCoreApplication.translate("Form", u"200", None))
        self.gray_204.setText(QCoreApplication.translate("Form", u"204", None))
        self.gray_208.setText(QCoreApplication.translate("Form", u"208", None))
        self.gray_216.setText(QCoreApplication.translate("Form", u"216", None))
        self.gray_224.setText(QCoreApplication.translate("Form", u"224", None))
        self.gray_232.setText(QCoreApplication.translate("Form", u"232", None))
        self.gray_240.setText(QCoreApplication.translate("Form", u"240", None))
        self.gray_248.setText(QCoreApplication.translate("Form", u"248", None))
        self.gray_255.setText(QCoreApplication.translate("Form", u"255", None))
        self.gray_0.setText(QCoreApplication.translate("Form", u"0", None))
        self.gray_8.setText(QCoreApplication.translate("Form", u"8", None))
        self.gray_16.setText(QCoreApplication.translate("Form", u"16", None))
        self.gray_24.setText(QCoreApplication.translate("Form", u"24", None))
        self.gray_32.setText(QCoreApplication.translate("Form", u"32", None))
        self.gray_40.setText(QCoreApplication.translate("Form", u"40", None))
        self.gray_48.setText(QCoreApplication.translate("Form", u"48", None))
        self.gray_56.setText(QCoreApplication.translate("Form", u"56", None))
        self.gray_64.setText(QCoreApplication.translate("Form", u"64", None))
        self.gray_72.setText(QCoreApplication.translate("Form", u"72", None))
        self.gray_80.setText(QCoreApplication.translate("Form", u"80", None))
        self.gray_88.setText(QCoreApplication.translate("Form", u"88", None))
        self.gray_96.setText(QCoreApplication.translate("Form", u"96", None))
        self.gray_104.setText(QCoreApplication.translate("Form", u"104", None))
        self.gray_112.setText(QCoreApplication.translate("Form", u"112", None))
        self.gray_120.setText(QCoreApplication.translate("Form", u"120", None))
        self.gray_128.setText(QCoreApplication.translate("Form", u"128", None))
        self.lineEdit_gmastep.setText(QCoreApplication.translate("Form", u"32", None))
        self.label_gmaStep.setText(QCoreApplication.translate("Form", u"Step :", None))
        self.label_gmawinsize.setText(QCoreApplication.translate("Form", u"Window Size(%) :", None))
        self.lineEdit_gmaboxsize.setText(QCoreApplication.translate("Form", u"80", None))
        self.btn_gmaStart.setText(QCoreApplication.translate("Form", u"Measure", None))
        self.btn_gmaStop.setText(QCoreApplication.translate("Form", u"stop", None))
        self.label_45.setText("")
        self.label_46.setText("")
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.gamma), QCoreApplication.translate("Form", u"Gamma", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.calman), QCoreApplication.translate("Form", u"Calman", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.apl), QCoreApplication.translate("Form", u"APL", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.fixedgamma), QCoreApplication.translate("Form", u"Fixed Gamma", None))
        self.tabWidget_2.setTabText(self.tabWidget_2.indexOf(self.periodicmeas), QCoreApplication.translate("Form", u"Preriodic Meas.", None))
        self.label_36.setText(QCoreApplication.translate("Form", u"Select Automatic or Manual measurement mode", None))
        self.manualBtn.setText(QCoreApplication.translate("Form", u"Manual", None))
        self.autoBtn.setText(QCoreApplication.translate("Form", u"Auto", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Form", u"Test", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Form", u"Lv", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("Form", u"CIE_x", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("Form", u"CIE_y", None));
        ___qtablewidgetitem4 = self.tableWidget.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("Form", u"CCT", None));
        ___qtablewidgetitem5 = self.tableWidget.horizontalHeaderItem(5)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("Form", u"duv", None));
        ___qtablewidgetitem6 = self.tableWidget.horizontalHeaderItem(6)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("Form", u"u`", None));
        ___qtablewidgetitem7 = self.tableWidget.horizontalHeaderItem(7)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("Form", u"v`", None));
        ___qtablewidgetitem8 = self.tableWidget.horizontalHeaderItem(8)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("Form", u"X", None));
        ___qtablewidgetitem9 = self.tableWidget.horizontalHeaderItem(9)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("Form", u"Y", None));
        ___qtablewidgetitem10 = self.tableWidget.horizontalHeaderItem(10)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("Form", u"Z", None));
        ___qtablewidgetitem11 = self.tableWidget.horizontalHeaderItem(11)
        ___qtablewidgetitem11.setText(QCoreApplication.translate("Form", u"Pattern(window)", None));
        ___qtablewidgetitem12 = self.tableWidget.horizontalHeaderItem(12)
        ___qtablewidgetitem12.setText(QCoreApplication.translate("Form", u"Pattern(bg)", None));
        ___qtablewidgetitem13 = self.tableWidget.horizontalHeaderItem(13)
        ___qtablewidgetitem13.setText(QCoreApplication.translate("Form", u"GrayLevel:Window", None));
        ___qtablewidgetitem14 = self.tableWidget.horizontalHeaderItem(14)
        ___qtablewidgetitem14.setText(QCoreApplication.translate("Form", u"GrayLevel:Background", None));
        ___qtablewidgetitem15 = self.tableWidget.horizontalHeaderItem(15)
        ___qtablewidgetitem15.setText(QCoreApplication.translate("Form", u"windowSize", None));
        ___qtablewidgetitem16 = self.tableWidget.horizontalHeaderItem(16)
        ___qtablewidgetitem16.setText(QCoreApplication.translate("Form", u"Meas. Device", None));
        ___qtablewidgetitem17 = self.tableWidget.horizontalHeaderItem(17)
        ___qtablewidgetitem17.setText(QCoreApplication.translate("Form", u"Date", None));

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)

        self.btn_report.setText(QCoreApplication.translate("Form", u"Show Report", None))
        self.label_7.setText(QCoreApplication.translate("Form", u"Luminance(nit)", None))
        self.label_67.setText(QCoreApplication.translate("Form", u"CIE x,y", None))
        self.label_68.setText(QCoreApplication.translate("Form", u"CIE u`,v`", None))
        self.label_69.setText(QCoreApplication.translate("Form", u"CCT(K)", None))
        self.label_70.setText(QCoreApplication.translate("Form", u"duv", None))
#if QT_CONFIG(statustip)
        self.lineEdit_nit.setStatusTip("")
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(statustip)
        self.lineEdit_xy.setStatusTip("")
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(statustip)
        self.lineEdit_uv.setStatusTip("")
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(statustip)
        self.lineEdit_cct.setStatusTip("")
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(statustip)
        self.lineEdit_duv.setStatusTip("")
#endif // QT_CONFIG(statustip)
        self.progress.setHtml(QCoreApplication.translate("Form", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt; font-weight:600;\">Status....</span></p></body></html>", None))
        self.procress_mea.setText(QCoreApplication.translate("Form", u"Measure", None))
    # retranslateUi

