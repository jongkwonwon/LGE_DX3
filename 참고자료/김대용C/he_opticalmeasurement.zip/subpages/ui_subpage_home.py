# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'subpages_hometSfwYv.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import picture_rc

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1693, 963)
        Form.setStyleSheet(u"")
        self.label = QLabel(Form)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 0, 1693, 963))
        self.label.setStyleSheet(u"lbl_title {\n"
"color:rgb(255, 255, 255);\n"
"}")
        self.label.setPixmap(QPixmap(u":/etc/Home_Image.png"))
        self.label.setAlignment(Qt.AlignJustify|Qt.AlignVCenter)
        self.label_2 = QLabel(Form)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(10, 10, 1081, 811))
        self.label_2.setStyleSheet(u"lbl_title {\n"
"color:rgb(255, 255, 255);\n"
"}")
        self.label_2.setAlignment(Qt.AlignJustify|Qt.AlignVCenter)
        self.lbl_title = QLabel(Form)
        self.lbl_title.setObjectName(u"lbl_title")
        self.lbl_title.setGeometry(QRect(600, 120, 581, 91))
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(25)
        font.setBold(True)
        font.setWeight(75)
        self.lbl_title.setFont(font)
        self.lbl_title.setStyleSheet(u"QLabel {color : white; }")
        self.lbl_title.setAlignment(Qt.AlignCenter)
        self.lbl_title.setWordWrap(True)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label.setText("")
        self.label_2.setText("")
        self.lbl_title.setText(QCoreApplication.translate("Form", u"HE Auto-Optical-Test Program", None))
    # retranslateUi

