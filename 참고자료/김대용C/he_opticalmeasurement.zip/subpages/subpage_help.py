import os
from PySide2.QtWidgets import QApplication 
import sys
sys.path.insert(0,'subpages')
from ui_subpage_help import *

class Widget_help(QWidget):
    def __init__(self, parent=None):
        #super(self.__class__,self).__init__(parent)
        QWidget.__init__(self)
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.show()


if __name__ == '__main__':
	app = QApplication(sys.argv)
	w = Widget_help()
	w.show()
	sys.exit(app.exec_())
