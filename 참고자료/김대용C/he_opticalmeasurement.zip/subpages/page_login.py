import os
import sys
sys.path.insert(0,'subpages')
from ui_login_UI_KIL import *

class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        #super(self.__class__,self).__init__(parent)
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.show()
        
        #################################################################
        #User Action에 대한 함수 설정
        #################################################################
        self.ui.btn_login.clicked.connect(self.printConnect)
        #self.ui.serialcntBtn.clicked.connect(self.Serial_Connect)
        
    def printConnect(self):
        userid=self.ui.txt_userid.text()
        if userid.strip() == "" or userid == "0":
         QMessageBox.warning(self, "경고", "아이디를 입력하세요.")       
        else:
         userpassword=self.ui.txt_userpw.text()
        QMessageBox.warning(self, "경고", "패스워드를 입력하세요.")
        
       


if __name__ == '__main__':
	app = QApplication(sys.argv)
	w = MainWindow()
	w.show()
	sys.exit(app.exec_())
