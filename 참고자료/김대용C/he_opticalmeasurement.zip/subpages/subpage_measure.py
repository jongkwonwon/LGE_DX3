import os
from PySide2.QtWidgets import QApplication
import sys

sys.path.insert(0, 'subpages')
sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
from ui_subpage_measure import *
from Custom_Widgets.Widgets import *
from modules.pattern import *
from modules.color_name import *
from modules.ui_measure_report import *

########################################################################
# IMPORT SERIALTOOLS
import serial.tools.list_ports
import time
from datetime import datetime
import serial

ser = serial.Serial()


########################################################################

class Widget_measure(QWidget):
    today = datetime.today()
    i = 0
    s = 0
    k = []
    step = []
    button_list = []
    def __init__(self, parent=None):
        # super(self.__class__,self).__init__(parent)
        QWidget.__init__(self)
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.dui = Ui_Dialog()
        self.rui = Ui_report_Dialog()


        # # APPLY JSON STYLESHEET
        # ########################################################################
        loadJsonStyle(self, self.ui, jsonFiles={
            # "../json/style_measure.json" # measure 단독 실행- 개발 단계
            "json/style_measure.json"  # main 실행
        })
        # ########################################################################

        self.show()

        ########################################################################
        # COLOR PATTERN SETTING (CLICK EVENT)
        ########################################################################
        self.ui.showwindowBtn.clicked.connect(self.openWindow)
        self.ui.ptnchangeBtn.clicked.connect(self.changeColor)
        self.ui.ptnchangeBtn_2.clicked.connect(self.changeColor)
        self.ui.win_all.clicked.connect(self.allSelectFunction)
        self.ui.win_red.clicked.connect(self.redSelectFunction)
        self.ui.win_green.clicked.connect(self.greenSelectFunction)
        self.ui.win_blue.clicked.connect(self.blueSelectFunction)
        self.ui.win_cyan.clicked.connect(self.cyanSelectFunction)
        self.ui.win_magen.clicked.connect(self.magentaSelectFunction)
        self.ui.win_yellow.clicked.connect(self.yellowSelectFunction)
        self.ui.win_white.clicked.connect(self.whiteSelectFunction)
        self.ui.win_black.clicked.connect(self.blackSelectFunction)
        self.ui.win_all_2.clicked.connect(self.allSelectFunction2)
        self.ui.win_red_2.clicked.connect(self.redSelectFunction2)
        self.ui.win_green_2.clicked.connect(self.greenSelectFunction2)
        self.ui.win_blue_2.clicked.connect(self.blueSelectFunction2)
        self.ui.win_cyan_2.clicked.connect(self.cyanSelectFunction2)
        self.ui.win_magen_2.clicked.connect(self.magentaSelectFunction2)
        self.ui.win_yellow_2.clicked.connect(self.yellowSelectFunction2)
        self.ui.win_white_2.clicked.connect(self.whiteSelectFunction2)
        self.ui.win_black_2.clicked.connect(self.blackSelectFunction2)
        self.ui.lineEdit_3.returnPressed.connect(self.changeColor)
        self.ui.lineEdit_4.returnPressed.connect(self.changeColor)
        self.ui.lineEdit_5.returnPressed.connect(self.changeColor)
        self.ui.sizeEdit.returnPressed.connect(self.changeColor)
        self.ui.lineEdit_7.returnPressed.connect(self.changeColor)
        self.ui.lineEdit_8.returnPressed.connect(self.changeColor)
        self.ui.lineEdit_9.returnPressed.connect(self.changeColor)
        ########################################################################
        ########################################################################
        # SERIAL COMM (CLICK EVENT)
        ########################################################################
        self.ui.ca310connBtn.clicked.connect(self.ca310Connect)
        self.ui.ca310discBtn.clicked.connect(self.ca310Disconnect)
        ########################################################################
        # MEASUREMENT (CLICK EVENT)
        ########################################################################
        self.ui.procress_mea.clicked.connect(self.measure_normal)
        self.ui.meas_cr.clicked.connect(self.measure_CR)
        self.ui.meas_gamut.clicked.connect(self.measure_gamut)
        # self.ui.meas_color.clicked.connect(self.measure_colorsweep) #spec 확정시 Active화 진행 예정
        self.ui.btn_gmaStart.clicked.connect(self.measure_gma)

        ########################################################################
        # PQ REPORT  (CLICK EVENT)
        ########################################################################
        self.ui.btn_report.clicked.connect(self.report_Window)

    ########################################################################
    # COLOR COORDINATE DEFINITION
    ########################################################################
    def allSelectFunction(self):
        self.ui.lineEdit_4.setText(self.ui.lineEdit_3.text())
        self.ui.lineEdit_5.setText(self.ui.lineEdit_3.text())

    def allSelectFunction2(self):
        self.ui.lineEdit_8.setText(self.ui.lineEdit_7.text())
        self.ui.lineEdit_9.setText(self.ui.lineEdit_7.text())

    def redSelectFunction(self):
        self.ui.lineEdit_3.setText("255")
        self.ui.lineEdit_4.setText("0")
        self.ui.lineEdit_5.setText("0")

    def redSelectFunction2(self):
        self.ui.lineEdit_7.setText("255")
        self.ui.lineEdit_8.setText("0")
        self.ui.lineEdit_9.setText("0")

    def greenSelectFunction(self):
        self.ui.lineEdit_3.setText("0")
        self.ui.lineEdit_4.setText("255")
        self.ui.lineEdit_5.setText("0")

    def greenSelectFunction2(self):
        self.ui.lineEdit_7.setText("0")
        self.ui.lineEdit_8.setText("255")
        self.ui.lineEdit_9.setText("0")

    def blueSelectFunction(self):
        self.ui.lineEdit_3.setText("0")
        self.ui.lineEdit_4.setText("0")
        self.ui.lineEdit_5.setText("255")

    def blueSelectFunction2(self):
        self.ui.lineEdit_7.setText("0")
        self.ui.lineEdit_8.setText("0")
        self.ui.lineEdit_9.setText("255")

    def cyanSelectFunction(self):
        self.ui.lineEdit_3.setText("0")
        self.ui.lineEdit_4.setText("255")
        self.ui.lineEdit_5.setText("255")

    def cyanSelectFunction2(self):
        self.ui.lineEdit_7.setText("0")
        self.ui.lineEdit_8.setText("255")
        self.ui.lineEdit_9.setText("255")

    def magentaSelectFunction(self):
        self.ui.lineEdit_3.setText("255")
        self.ui.lineEdit_4.setText("0")
        self.ui.lineEdit_5.setText("255")

    def magentaSelectFunction2(self):
        self.ui.lineEdit_7.setText("255")
        self.ui.lineEdit_8.setText("0")
        self.ui.lineEdit_9.setText("255")

    def yellowSelectFunction(self):
        self.ui.lineEdit_3.setText("255")
        self.ui.lineEdit_4.setText("255")
        self.ui.lineEdit_5.setText("0")

    def yellowSelectFunction2(self):
        self.ui.lineEdit_7.setText("255")
        self.ui.lineEdit_8.setText("255")
        self.ui.lineEdit_9.setText("0")

    def whiteSelectFunction(self):
        self.ui.lineEdit_3.setText("255")
        self.ui.lineEdit_4.setText("255")
        self.ui.lineEdit_5.setText("255")

    def whiteSelectFunction2(self):
        self.ui.lineEdit_7.setText("255")
        self.ui.lineEdit_8.setText("255")
        self.ui.lineEdit_9.setText("255")

    def blackSelectFunction(self):
        self.ui.lineEdit_3.setText("0")
        self.ui.lineEdit_4.setText("0")
        self.ui.lineEdit_5.setText("0")

    def blackSelectFunction2(self):
        self.ui.lineEdit_7.setText("0")
        self.ui.lineEdit_8.setText("0")
        self.ui.lineEdit_9.setText("0")

    ########################################################################
    ## PATTERN WINDOW
    ########################################################################

    def openWindow(self):
        self.dialog = QtWidgets.QDialog()
        self.dui.setupUi(self.dialog)

        resolution = self.ui.resolutioncombo.currentText()
        hor = int(resolution[0:4])
        ver = int(resolution[5:])
        self.dialog.setGeometry(0, 0, hor, ver)

        x_geo_FullBtn = int(hor / 2 - 130)
        y_geo_FullBtn = int(ver / 2 - 65)
        self.dui.FullBtn.move(x_geo_FullBtn, y_geo_FullBtn)

        self.dialog.showNormal()
        self.i += 1
        self.changeColor()
        self.dui.FullBtn.clicked.connect(self.changeFullscreen)

    def report_Window(self):
        self.report_dialog = QtWidgets.QDialog()
        self.rui.setupUi(self.report_dialog)
        # resolution = self.ui.resolutioncombo.currentText()
        # hor = int(resolution[0:4])
        # ver = int(resolution[5:])
        # self.report_dialog.setGeometry(0, 0, hor, ver)

        self.report_dialog.showNormal()
    def changeFullscreen(self):
        if self.dialog.windowState() & QtCore.Qt.WindowFullScreen:
            self.dialog.showNormal()
        else:
            self.dialog.showFullScreen()
            self.dui.FullBtn.hide()

    def changeColor(self):
        if self.i == 0:
            self.openWindow()
        else:
            resolution = self.ui.resolutioncombo.currentText()
            size_ratio = self.ui.sizeEdit.text()
            size = int(size_ratio) / 100
            hor = int(resolution[0:4])
            ver = int(resolution[5:])
            hor_width = int(size * hor)
            ver_height = int(size * ver)
            self.dui.windowbox.resize(hor_width, ver_height)
            x_geo = int((hor - hor_width) / 2)
            y_geo = int((ver - ver_height) / 2)
            self.dui.windowbox.move(x_geo, y_geo)

            if (int(size_ratio) > 0) & (int(size_ratio) < 100):
                self.ui.wincolor.resize(35, 20)
                self.ui.totalwincolor.resize(35, 20)
                self.ui.wincolor.move(58, 134)
                self.ui.totalwincolor.move(298, 131)
            elif int(size_ratio) == 0:
                self.ui.wincolor.resize(0, 0)
                self.ui.totalwincolor.resize(0, 0)
                self.ui.wincolor.move(68, 133)
                self.ui.totalwincolor.move(309, 132)
            else:
                self.ui.wincolor.resize(81, 50)
                self.ui.totalwincolor.resize(81, 50)
                self.ui.wincolor.move(35, 118)
                self.ui.totalwincolor.move(275, 116)

            self.ui.backcolor.setStyleSheet(
                "background-color : rgb(" + self.ui.lineEdit_7.text() + "," + self.ui.lineEdit_8.text() + "," + self.ui.lineEdit_9.text() + ")")
            self.ui.totalbackcolor.setStyleSheet(
                "background-color : rgb(" + self.ui.lineEdit_7.text() + "," + self.ui.lineEdit_8.text() + "," + self.ui.lineEdit_9.text() + ")")
            self.ui.wincolor.setStyleSheet(
                "background-color : rgb(" + self.ui.lineEdit_3.text() + "," + self.ui.lineEdit_4.text() + "," + self.ui.lineEdit_5.text() + ")")
            self.ui.totalwincolor.setStyleSheet(
                "background-color : rgb(" + self.ui.lineEdit_3.text() + "," + self.ui.lineEdit_4.text() + "," + self.ui.lineEdit_5.text() + ")")
            self.dialog.setStyleSheet(
                "#windowbox{background-color : rgb(" + self.ui.lineEdit_3.text() + "," + self.ui.lineEdit_4.text() + "," + self.ui.lineEdit_5.text() + ")}"
                "#Dialog{background-color : rgb(" + self.ui.lineEdit_7.text() + "," + self.ui.lineEdit_8.text() + "," + self.ui.lineEdit_9.text() + ")}"
                "#FullBtn{color:white; background-color: rgb(128,60,20)}")

            self.repaint()
            self.dialog.repaint()

    ########################################################################
    # MEASURE DEFINTION (CLICK EVENT)
    ########################################################################

    def measure_normal(self):
        self.measure()

    def measure_CR(self):
        self.ui.tableWidget.clearContents()
        self.s = 0
        # white 측정
        self.whiteSelectFunction2()
        self.ui.sizeEdit.setText("0")
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        # black 측정
        self.blackSelectFunction2()
        self.changeColor()
        time.sleep(0.3)
        self.measure()

    def measure_gamut(self):
        self.redSelectFunction2()  # Red
        self.ui.sizeEdit.setText("0")
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.greenSelectFunction2()
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.blueSelectFunction2()
        self.changeColor()
        time.sleep(0.3)
        self.measure()

    def measure_colorsweep(self):
        self.ui.tableWidget.clearContents()
        self.s = 0
        self.whiteSelectFunction2()  # White
        time.sleep(0.3)
        self.measure()
        self.redSelectFunction2()  # Red
        self.ui.sizeEdit.setText("0")
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.greenSelectFunction2()  # Green
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.blueSelectFunction2()  # Blue
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.yellowSelectFunction2()  # Yellow
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.magentaSelectFunction2()  # Magenta
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.cyanSelectFunction2()  # Cyan
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        self.blackSelectFunction2()  # Black
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        # colorsweep Graygamma
        for l in range(0, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText(str(l))
                self.ui.lineEdit_8.setText(str(l))
                self.ui.lineEdit_9.setText(str(l))
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.whiteSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # Red Sweep
        for l in range(0, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText(str(l))
                self.ui.lineEdit_8.setText("255")
                self.ui.lineEdit_9.setText("255")
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.whiteSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # Green Sweep
        for l in range(0, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText("255")
                self.ui.lineEdit_8.setText(str(l))
                self.ui.lineEdit_9.setText("255")
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.whiteSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # Blue Sweep
        for l in range(0, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText("255")
                self.ui.lineEdit_8.setText("255")
                self.ui.lineEdit_9.setText(str(l))
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.whiteSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # Red gamma
        self.ui.lineEdit_7.setText("16")
        self.ui.lineEdit_8.setText("0")
        self.ui.lineEdit_9.setText("0")
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        for l in range(32, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText(str(l))
                self.ui.lineEdit_8.setText("0")
                self.ui.lineEdit_9.setText("0")
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.redSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # Green gamma
        self.ui.lineEdit_7.setText("0")
        self.ui.lineEdit_8.setText("16")
        self.ui.lineEdit_9.setText("0")
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        for l in range(32, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText("0")
                self.ui.lineEdit_8.setText(str(l))
                self.ui.lineEdit_9.setText("0")
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.greenSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # Blue gamma
        self.ui.lineEdit_7.setText("0")
        self.ui.lineEdit_8.setText("0")
        self.ui.lineEdit_9.setText("16")
        self.changeColor()
        time.sleep(0.3)
        self.measure()
        for l in range(32, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText("0")
                self.ui.lineEdit_8.setText("0")
                self.ui.lineEdit_9.setText(str(l))
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.blueSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # R/G Sweep
        for l in range(0, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText(str(l))
                self.ui.lineEdit_8.setText(str(l))
                self.ui.lineEdit_9.setText("255")
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.whiteSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # R/B Sweep
        for l in range(0, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText(str(l))
                self.ui.lineEdit_8.setText("255")
                self.ui.lineEdit_9.setText(str(l))
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.whiteSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure()
        # G/B Sweep
        for l in range(0, 257, 32):
            if l <= 254:
                self.ui.lineEdit_7.setText("255")
                self.ui.lineEdit_8.setText(str(l))
                self.ui.lineEdit_9.setText(str(l))
                self.changeColor()
                time.sleep(0.3)
                self.measure()
            elif l == 256:
                self.whiteSelectFunction2()
                self.changeColor()
                time.sleep(0.3)
                self.measure() #

    def gamma_step(self): #measure gamma step setting
        step = list(range(0, 256, int(self.ui.lineEdit_gmastep.text())))
        if 204 not in step:
            step.append(204)
        if 255 not in step:
            step.append(255)
        self.step = sorted(step)
        self.ref_Step = [0, 8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96,
                         104, 112, 120, 128, 136, 144, 152, 160, 168, 176,
                         184, 192, 200, 204, 208, 216, 224, 232, 240, 248, 255]
        self.btn_Step = [x for x in self.ref_Step if x not in self.step]
        self.button_list = ["gray_" + str(step) for step in self.btn_Step]
        print(self.button_list)

    def btn_change_color(self):
        for i, button in self.btn_Step:
            button.setStyleSheet("background-color: #1b1b27" "color:#1b1b27")
            button.setEnabled(False)
    def white_gma(self): #white gamma
        for l in self.step:
            self.ui.lineEdit_3.setText(str(l))
            self.ui.lineEdit_4.setText(str(l))
            self.ui.lineEdit_5.setText(str(l))
            self.changeColor()
            time.sleep(0.3)
            self.measure()
    def red_gma(self): #red gamma
        for l in self.step:
            self.ui.lineEdit_3.setText(str(l))
            self.ui.lineEdit_4.setText("0")
            self.ui.lineEdit_5.setText("0")
            self.changeColor()
            time.sleep(0.3)
            self.measure()
    def green_gma(self):     # Green gamma
        for l in self.step:
            self.ui.lineEdit_3.setText("0")
            self.ui.lineEdit_4.setText(str(l))
            self.ui.lineEdit_5.setText("0")
            self.changeColor()
            time.sleep(0.3)
            self.measure()
    def blue_gma(self):    # Blue gamma
        for l in self.step:
            self.ui.lineEdit_3.setText("0")
            self.ui.lineEdit_4.setText("0")
            self.ui.lineEdit_5.setText(str(l))
            self.changeColor()
            time.sleep(0.3)
            self.measure()
    def cyan_gma(self):     # Cyan gamma
        for l in self.step:
            self.ui.lineEdit_3.setText("0")
            self.ui.lineEdit_4.setText(str(l))
            self.ui.lineEdit_5.setText(str(l))
            self.changeColor()
            time.sleep(0.3)
            self.measure()
    def magenta_gma(self): # Magenta gamma
        for l in self.step:
            self.ui.lineEdit_3.setText(str(l))
            self.ui.lineEdit_4.setText("0")
            self.ui.lineEdit_5.setText(str(l))
            self.changeColor()
            time.sleep(0.3)
            self.measure()
    def yellow_gma(self): # Yellow gamma
        for l in self.step:
            self.ui.lineEdit_3.setText(str(l))
            self.ui.lineEdit_4.setText(str(l))
            self.ui.lineEdit_5.setText("0")
            self.changeColor()
            time.sleep(0.3)
            self.measure()

    def measure_gma(self): #measure gamma
        self.ui.sizeEdit.setText(self.ui.lineEdit_gmaboxsize.text())
        self.blackSelectFunction2()  # LCD 기준, OLED는 WHITE로 조건부 셋업 코딩 예정
        self.gamma_step()
        self.btn_change_color()
        if self.ui.radioButton_All.isChecked():
            self.ui.tableWidget.clearContents()
            self.s = 0
            self.white_gma()
            self.red_gma()
            self.green_gma()
            self.blue_gma()
            self.cyan_gma()
            self.magenta_gma()
            self.yellow_gma()
            self.ui.progress.append("complete")
        elif self.ui.radioButton_Gray.isChecked():
            self.white_gma()
            self.ui.progress.append("complete")
        elif self.ui.radioButton_Red.isChecked():
            self.red_gma()
            self.ui.progress.append("complete")
        elif self.ui.radioButton_Green.isChecked():
            self.green_gma()
            self.ui.progress.append("complete")
        elif self.ui.radioButton_Blue.isChecked():
            self.blue_gma()
            self.ui.progress.append("complete")
        elif self.ui.radioButton_Cyan.isChecked():
            self.cyan_gma()
            self.ui.progress.append("complete")
        elif self.ui.radioButton_Magenta.isChecked():
            self.magenta_gma()
            self.ui.progress.append("complete")
        elif self.ui.radioButton_Yellow.isChecked():
            self.yellow_gma()
            self.ui.progress.append("complete")

    def measure(self):
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        self.k = [0, 1]
        for j in self.k:
            measure_mode = "MDS," + str(j) + "\r"
            ser.write(measure_mode.encode())
            out = ser.read_until(b'\r')
            # print(out)
            ser.write("MES\r".encode())
            out = ser.read_until(b'\r').decode()
            # print(out)
            # print("MDS,"+str(j))
            self.ui.tableWidget.setItem(self.s, 0, QTableWidgetItem(str(self.today.strftime('%Y-%m-%d %H:%M'))))
            self.ui.tableWidget.setItem(self.s, 1, QTableWidgetItem("CA310"))  # CA310
            self.ui.tableWidget.setItem(self.s, 2, QTableWidgetItem("Manual"))
            # PTN WINDOW/BACKGROUND COLOR NAME =====
            if int(self.ui.sizeEdit.text()) > 0:
                self.ui.tableWidget.setItem(self.s, 13,
                                            QTableWidgetItem(str(convert_rgb_to_names((self.ui.lineEdit_3.text(),
                                                                                       self.ui.lineEdit_4.text(),
                                                                                       self.ui.lineEdit_5.text())))[14:]))
            else:
                self.ui.tableWidget.setItem(self.s, 13, QTableWidgetItem("-"))
            if int(self.ui.sizeEdit.text()) < 100:
                self.ui.tableWidget.setItem(self.s, 14,
                                            QTableWidgetItem(str(convert_rgb_to_names((self.ui.lineEdit_7.text(),
                                                                                       self.ui.lineEdit_8.text(),
                                                                                       self.ui.lineEdit_9.text())))[14:]))
            else:
                self.ui.tableWidget.setItem(self.s, 14, QTableWidgetItem("-"))
            #=================================================
            if self.ui.sizeEdit.text() == "0":
                self.ui.tableWidget.setItem(self.s, 15, QTableWidgetItem("na"))
            else:
                self.ui.tableWidget.setItem(self.s, 15, QTableWidgetItem(
                    "(" + self.ui.lineEdit_3.text() + "," + self.ui.lineEdit_4.text()
                    + "," + self.ui.lineEdit_5.text() + ")"))
            self.ui.tableWidget.setItem(self.s, 16, QTableWidgetItem(
                "(" + self.ui.lineEdit_7.text() + "," + self.ui.lineEdit_8.text()
                + "," + self.ui.lineEdit_9.text() + ")"))
            self.ui.tableWidget.setItem(self.s, 17, QTableWidgetItem(self.ui.sizeEdit.text()))

            if j == 0:  # mds, 0 모드 측정
                x, y, lv = str(out)[8:].split(';')
                self.ui.tableWidget.setItem(self.s, 3, QTableWidgetItem(lv))
                self.ui.tableWidget.setItem(self.s, 4, QTableWidgetItem(x))
                self.ui.tableWidget.setItem(self.s, 5, QTableWidgetItem(y))
                self.ui.lineEdit_nit.setText(lv)
                self.ui.lineEdit_xy.setText(x + " / " + y)
                x = int(x) / 10000
                y = int(y) / 10000
                # u`v` 계산
                u = str(int((4 * x) / (-2 * x + 12 * y + 3) * 10000))  # u` 계산
                v = str(int((9 * y) / (-2 * x + 12 * y + 3) * 10000))  # v' 계산
                self.ui.tableWidget.setItem(self.s, 8, QTableWidgetItem(u))
                self.ui.tableWidget.setItem(self.s, 9, QTableWidgetItem(v))
                self.ui.lineEdit_uv.setText(u + " / " + v)
                # XYZ 삼자극치 계산
                Y = round(float(lv), 2)
                X = str(round((x * Y) / y, 2))
                Z = str(round(((1 - x - y) * Y) / y, 2))
                self.ui.tableWidget.setItem(self.s, 10, QTableWidgetItem(X))
                self.ui.tableWidget.setItem(self.s, 11, QTableWidgetItem(str(Y)))
                self.ui.tableWidget.setItem(self.s, 12, QTableWidgetItem(Z))
            elif j == 1:  # mds, 1모드 측정
                if len(str(out)) > 20:
                    cct, duv, lv2 = str(out)[8:].split(';')
                else:
                    cct, duv = "na", "na"  # Black PTN CCT, duv 측정 불가에 따른 조정
                self.ui.tableWidget.setItem(self.s, 6, QTableWidgetItem(cct))
                self.ui.tableWidget.setItem(self.s, 7, QTableWidgetItem(duv))
                self.ui.lineEdit_cct.setText(cct)
                self.ui.lineEdit_duv.setText(duv)
                self.s += 1

    ########################################################################
    # Measurement Connection (CLICK EVENT)
    ########################################################################
    def ca310Connect(self):
        if not ser.isOpen():
            ser.port = 'COM3'
            ser.baudrate = 38400
            ser.parity = serial.PARITY_EVEN
            ser.stopbits = serial.STOPBITS_TWO
            ser.bytesize = serial.SEVENBITS
            ser.timeout = None
            ser.open()
            ser.write(("COM,1\r\n").encode())
            time.sleep(0.15)
            ser.write(("MDS,0\r\n").encode())
            out = ser.read_until(b'\r').decode()
            print(out)
            if not out == "":
                self.ui.progress.setText("CA310 Connected")
            else:
                self.ui.progress.setText("Try again")
                ser.close()
        else:
            self.ui.progress.setText("Already Connected")
            ser.write("COM,1\r\n".encode())

    def ca310Disconnect(self):
        ser.write("COM,0\r".encode())
        # time.sleep(0.2)
        out = ser.read_until(b'\r').decode()
        print(out)
        ser.close()
        self.ui.progress.setText("Your connection disconnected")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = Widget_measure()
    w.show()
    sys.exit(app.exec_())
